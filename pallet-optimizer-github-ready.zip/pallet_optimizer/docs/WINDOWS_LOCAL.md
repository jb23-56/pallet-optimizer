# PalletOptimizer para Windows

## Uso local sin conexión

La edición de escritorio se distribuye como un único ejecutable portátil de 64 bits: `PalletOptimizer-1.0.0-Windows-Portable.exe`. No requiere instalar un servidor, abrir un navegador ni disponer de conexión a Internet para calcular paletas, planificar contenedores, importar archivos locales o generar informes.

| Aspecto | Comportamiento |
| --- | --- |
| Sistema compatible | Windows de 64 bits |
| Instalación | No necesaria; se ejecuta directamente el archivo `.exe` |
| Conexión | No es necesaria para el uso normal |
| Datos de trabajo | Se guardan automáticamente en el almacenamiento local del perfil de Windows |
| Informes | PDF y Excel se generan localmente desde la pestaña **Descarga informe** |

## Apertura inicial

Copie el ejecutable a una carpeta local de confianza, por ejemplo `Documentos\PalletOptimizer`, y ejecútelo con doble clic. Si Windows muestra una advertencia de reputación al tratarse de una aplicación sin firma de código, revise que el archivo provenga de la entrega autorizada antes de continuar. La aplicación abre una ventana propia y puede utilizarse sin conexión.

> Los perfiles de envío, las dimensiones, las restricciones de manejo, las listas de producto y las preferencias operativas se recuperan automáticamente al volver a abrir la aplicación en la misma cuenta de Windows. Los resultados de cálculo no se restauran; deben recalcularse para que correspondan a los datos guardados.

## Actualización y respaldo operativo

Para actualizar la aplicación, cierre PalletOptimizer y reemplace el ejecutable anterior por la nueva versión. La configuración local permanece asociada al perfil de Windows, por lo que conviene abrir la nueva versión y comprobar un perfil o una lista importante antes de eliminar el archivo anterior.

Antes de un cambio de equipo o una actualización importante, genere también los informes de los planes activos en **Excel** y **PDF**. Estos archivos constituyen un respaldo operativo y compartible de la distribución calculada. La exportación de un archivo de respaldo restaurable de toda la configuración será una mejora posterior.

## Generación técnica

El empaquetado utiliza Electron y electron-builder. Electron abre la aplicación compilada dentro de un contenedor de escritorio aislado; electron-builder admite la creación de ejecutables portátiles e instaladores para Windows.[1]

| Comando | Resultado |
| --- | --- |
| `pnpm run desktop:dev` | Abre la versión de escritorio conectada al servidor local de desarrollo. |
| `pnpm run desktop:package` | Construye el directorio ejecutable de Windows para pruebas. |
| `pnpm run desktop:dist` | Genera el ejecutable portátil de Windows de 64 bits en `release/`. |

## Referencias

[1]: https://www.electron.build/docs/ "electron-builder: documentación de distribución"
