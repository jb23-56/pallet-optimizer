# Dossier de continuidad para IA — PalletOptimizer

> **Propósito.** Este documento permite retomar el desarrollo de PalletOptimizer sin reconstruir el contexto de las conversaciones previas. Resume el producto, las decisiones aceptadas, el estado de código, las validaciones y el método de trabajo recomendado.

| Campo | Estado actual |
| --- | --- |
| Producto | **PalletOptimizer**, estación de planificación de paletas, cajas y contenedores. |
| Proyecto | `/home/ubuntu/pallet_optimizer` |
| Rama y punto de partida | `main`, checkpoint **`2fb4e66d`** |
| Sitio publicado | `https://palletopt-t5gydwzm.manus.space` |
| Previsualización de desarrollo | `https://3000-id5uimow05l5sttpn4129-f2803112.us1.manus.computer` |
| Tecnología | React 19, TypeScript, Vite 7, Tailwind CSS 4, Canvas 2D, `xlsx`, `jsPDF`, `jspdf-autotable`, Electron y electron-builder. |
| Idioma de interfaz | Español. |
| Plataforma local solicitada | Windows de 64 bits, uso sin Internet. |

## 1. Qué es el producto

PalletOptimizer calcula cómo acomodar cajas en paletas y cómo distribuir después esas paletas o cajas sueltas dentro de contenedores o vehículos. Está pensado para una operación logística que **fabrica bases de paleta a medida**, no para una operación restringida a medidas estándar.

La aplicación resuelve tres niveles de planificación. El primero calcula una sola referencia de caja en una paleta. El segundo combina diferentes SKU en una misma paleta y crea más paletas cuando la primera ya no admite carga. El tercero sitúa paletas o cajas individuales de listas importadas en un contenedor o perfil de transporte. El resultado incluye una visualización 3D de inspección y exportaciones en PDF y Excel.

## 2. Requisitos y decisiones confirmadas con el usuario

| Área | Decisión implementada |
| --- | --- |
| Altura de carga | La altura máxima depende del destino. Los perfiles de referencia aplican 2,393 mm para contenedor y 2,400 mm para camión; la altura de la base se descuenta antes de acomodar cajas. |
| Paletas | Largo, ancho, altura total, altura de base y peso máximo son editables. La aplicación recomienda bases cuando la caja no cabe o cuando hay alternativas más eficientes. |
| Maniobrabilidad | Por defecto, el recomendador prioriza lados de hasta **1,700 mm** para montacargas pequeño y transpaleta. La opción `Permitir bases ampliadas` expone alternativas mayores con aviso. |
| Mezcla de SKU | Se pueden añadir múltiples tipos de cajas, cantidades y restricciones. Cuando una paleta no admite más carga, se crea otra para el excedente. |
| Física de apilado | Ninguna caja elevada puede quedar suspendida. La huella debe tener apoyo continuo de cajas inferiores que permitan apilar. |
| Fabricación de base | Cada paleta mixta reduce su base a la menor huella viable, con 50 mm de holgura por lado y redondeo a 50 mm. Si la carga necesita toda la base, se conserva completa. |
| Transporte | Existen cuatro equipos estándar y perfiles de envío personalizados con largo, ancho, altura, peso y nota operativa. Los personalizados aparecen como destino y como contenedor. |
| Listas de producto | Se importan CSV/XLSX. En contenedores, una lista se procesa como **cajas sueltas individuales**, no como seis tipos agregados ni como paletas forzadas. |
| Visualización | La vista de paleta permite giro únicamente horizontal. La vista de contenedor ofrece cámaras frontal, lateral, superior e isométrica, zoom con botones y rueda, etiquetas visibles y métricas de altura/centro de gravedad. |
| Informes | La pestaña antes llamada “Comparar” se llama **Descarga informe** y centraliza PDF y Excel. |
| Escritorio | Se añadió una edición Electron para Windows x64, sin necesidad de servidor ni Internet. |
| Persistencia | Se guardan automáticamente ajustes y datos de trabajo locales entre sesiones. |

## 3. Flujo operativo que debe conservarse

La navegación principal tiene cinco etapas: **Productos**, **Paleta simple**, **Mezcla de cajas**, **Contenedores** y **Descarga informe**. El destino se configura antes de la etapa activa y siempre debe afectar recomendaciones, límites de altura, contenedor y exportaciones.

```text
Definir destino y maniobra
        │
        ├─ Productos → importar/editar lista → mezcla, simple o cajas sueltas
        ├─ Paleta simple → calcular capacidad y número de paletas
        ├─ Mezcla de cajas → validar apoyo y fabricar bases mínimas
        ├─ Contenedores → cargar paletas o cajas individuales
        └─ Descarga informe → PDF y Excel consolidados
```

La aplicación debe seguir mostrando la acción actual, el siguiente paso y las métricas críticas. Evitar modificar la navegación en una mejora puntual sin comprobar que este flujo permanece legible.

## 4. Arquitectura del código

| Ruta | Responsabilidad | Notas de continuidad |
| --- | --- | --- |
| `client/src/App.tsx` | Estado central, navegación, formularios, controladores de cálculo, perfiles personalizados, persistencia y exportaciones. | Es el archivo principal y grande. Mantiene el estado de la aplicación en cliente; evitar convertirlo en un contenedor aún mayor sin separar una unidad funcional clara. |
| `client/src/lib/palletCalculator.ts` | Motor de paleta simple y mezcla de SKU. | Contiene orientación, peso, número de paletas, apoyo físico, optimización de base y recomendaciones. |
| `client/src/lib/containerCalculator.ts` | Distribución de paletas y cajas sueltas en contenedores. | Contiene métricas de uso, altura y centro de gravedad. |
| `client/src/lib/productList.ts` | Importación/exportación de listas y conversión a `MixedBoxItem`. | Es la entrada correcta para CSV/XLSX de productos. |
| `client/src/lib/logisticsPdf.ts` | PDF del plan logístico. | Incluye destino, bases, distribución SKU, alertas y anexo de envío cuando existe. |
| `client/src/lib/logisticsExcel.ts` | Libro Excel de seis hojas. | Hojas: `Resumen`, `Paletas`, `Cajas`, `SKU`, `Envío`, `Alertas`. |
| `client/src/components/PalletVisualization3D.tsx` | Lienzo Canvas para inspección de una paleta. | Solo giro horizontal; no reintroducir inclinación vertical. |
| `client/src/components/ContainerVisualization3D.tsx` | Lienzo Canvas de contenedor. | Tiene vistas predefinidas, zoom, filtrado de oclusión y etiquetas. |
| `client/src/components/ProductListPanel.tsx` | Interfaz de listas, edición, importación y acciones de uso. | Mantener la elección de usar la lista en mezcla, simple o contenedor. |
| `client/src/index.css` | Sistema de diseño industrial, retícula y jerarquía. | El comentario superior recuerda la filosofía visual. |
| `desktop/main.cjs` | Ventana Electron de producción/desarrollo. | `contextIsolation: true`, `nodeIntegration: false`, `sandbox: true`. Mantener estos límites. |
| `package.json` | Scripts web y de escritorio, configuración de electron-builder. | Usar los scripts existentes; no introducir un servidor para el ejecutable local. |
| `docs/WINDOWS_LOCAL.md` | Manual de uso y actualización para Windows. | Actualizarlo si cambia el formato de distribución, los datos persistidos o la copia de seguridad. |

## 5. Modelo de datos y contratos clave

| Tipo o contrato | Ubicación | Finalidad |
| --- | --- | --- |
| `BoxDimensions` | `palletCalculator.ts` | Largo, ancho, alto y peso de una caja. |
| `BoxHandlingOptions` | `palletCalculator.ts` | `canStack`, `allowHorizontalRotation`, `allowVerticalRotation`. |
| `PalletDimensions` | `palletCalculator.ts` | Largo, ancho, altura, altura de base y peso máximo de la paleta. |
| `MixedBoxItem` | `palletCalculator.ts` | SKU con dimensiones, cantidad y restricciones para mezcla. |
| `MixedBoxPlacement` | `palletCalculator.ts` | Posición física orientada de una caja dentro de la paleta. |
| `MixedBoxResult` | `palletCalculator.ts` | Resultado de mezcla, paletas, excedentes y métricas. |
| `FabricatedPalletDimensions` | `palletCalculator.ts` | Base realmente fabricada, huella y ahorro de material. |
| `ContainerSpec` | `containerCalculator.ts` | Dimensiones internas, peso máximo y nota de un contenedor/vehículo. |
| `ContainerLoadResult` | `containerCalculator.ts` | Plan de carga de paletas y métricas de transporte. |
| `LooseContainerLoadResult` | `containerCalculator.ts` | Plan de carga de cajas individuales provenientes de lista. |
| `ProductListItem` | `productList.ts` | Producto importado/editable, extendiendo el modelo de mezcla. |
| `ShippingProfile` | `App.tsx` | Perfil editable de envío con `id`, etiqueta, dimensiones internas, peso y nota. |
| `LocalWorkspace` | `App.tsx` | Conjunto de datos persistidos en `localStorage`. |

### Perfiles de envío

`DEFAULT_FINAL_TRANSPORT_PROFILES` conserva dos referencias: `container` y `truck`. Los perfiles creados por el usuario tienen `isCustom: true` y usan el prefijo `custom-` en el identificador. Para poder utilizarlos en el módulo de Contenedores, `App.tsx` los transforma en `ContainerSpec` con el prefijo `profile-`.

> Al tocar la lógica de perfiles, comprobar en una misma sesión: selector de destino, altura aplicada, recomendaciones de paleta, selector de contenedor, cálculo de contenedor, PDF y Excel. No basta con validar solo el formulario.

### Persistencia local

La clave de almacenamiento es `palletoptimizer.workspace.v1`. Se persisten la pestaña activa, caja simple, restricciones, base, destino, perfiles personalizados, maniobrabilidad, SKU de mezcla, lista de productos y fuente/especificación de contenedor.

No se guardan los resultados `simpleResult`, `mixedResult`, `containerResult` ni `looseContainerResult`: se deben recalcular al abrir la aplicación para evitar planos derivados de datos ya modificados. Si se implementa un espacio de trabajo restaurable completo, deberá incluir número de versión, validación de esquema y una experiencia visible de importar/exportar.

## 6. Invariantes de cálculo que no deben romperse

1. **Altura.** Ninguna disposición puede rebasar la altura final permitida después de descontar la base de la paleta.
2. **Peso.** El peso por paleta y por contenedor respeta sus límites configurados.
3. **Apoyo físico.** Una caja con `y` superior a la altura de base debe descansar sobre superficies compatibles y con cobertura continua de la huella. No admitir cajas “flotando”.
4. **Restricciones SKU.** Las opciones de apilado y rotación deben controlar la selección de orientación y soporte.
5. **Excedentes.** La mezcla debe generar nuevas paletas para las cajas no ubicables, y mostrar el motivo de excedente sin perder cantidades.
6. **Base fabricada.** La reducción se evalúa por paleta de mezcla y se transfiere con sus dimensiones reales al módulo de contenedores.
7. **Cajas de lista.** La opción de lista para Contenedores debe generar una entrada física por cada cantidad de producto, no una entrada por SKU.
8. **Etiquetas 3D.** Solo deben mostrarse las caras visibles o la unidad seleccionada; no reintroducir etiquetas a través de caras ocultas.

## 7. Diseño y experiencia

La dirección aprobada es **Technical Logistics SaaS / Modernismo Industrial Funcional**, refinada como un **flujo blanco, amplio y guiado por pasos**. Debe sentirse como una estación de planificación de almacén, no como un formulario SaaS genérico ni como un panel técnico saturado.

| Regla visual | Aplicación obligatoria |
| --- | --- |
| Azul operativo | Reservarlo para navegación seleccionada, cálculo/aplicación, medida decisiva y recomendación principal. |
| Neutros fríos | Usarlos para estructura pasiva, bordes, subtítulos y opciones secundarias. |
| Retícula de pallet | Es el motivo de marca: repetirlo en lienzo vacío, recomendaciones y áreas de resumen. |
| Tipografía | Monoespaciada/tabular para etapas, SKU, unidades y métricas; sans compacta para explicaciones. Se usan fuentes del sistema para el modo sin conexión. |
| Jerarquía | La pantalla debe revelar primero paso actual, entrada requerida, base recomendada, acción principal y estado del plan. |
| Flujo guiado | Productos abre por defecto con una tabla de SKU; Mezcla prioriza sus filas editables y deja destino/configuración como contexto secundario plegable. |
| Densidad técnica | Usar monoespaciada solo en medidas, SKU, unidades, etapas y métricas; títulos e instrucciones emplean una lectura humana, espaciosa y breve. |
| Interacciones | Animaciones cortas, reversibles y no intrusivas; respetar `prefers-reduced-motion`. |

Las decisiones completas se mantienen en `ideas.md`. Si una futura IA cambia estilos, debe leer ese archivo antes de editar componentes o CSS y añadir decisiones relevantes a la sección `Style Decisions`.

## 8. Exportaciones y resultado operativo

### PDF

El PDF contiene resumen ejecutivo, destino final, límite de altura, maniobrabilidad, base configurada y fabricada, ahorro, distribución SKU, especificaciones de manejo, advertencias y anexo del plan de contenedor cuando se ha calculado. Para perfiles personalizados se muestra la referencia física interna y el peso máximo.

Se corrigió el espaciado bajo la descripción del destino para que la línea física de perfiles personalizados no se superponga con la sección `Fabricación por paleta`. Al modificar esa sección, generar un PDF de prueba y revisarlo visualmente.

### Excel

El libro tiene seis hojas: `Resumen`, `Paletas`, `Cajas`, `SKU`, `Envío` y `Alertas`. La hoja `Cajas` tiene una fila por colocación física de caja, de modo que permite reconstruir el plan sin depender del Canvas. La hoja `Envío` anexa el contenedor si se calculó desde la mezcla.

## 9. Aplicación local de Windows

La aplicación se envuelve con Electron porque el proyecto es estrictamente cliente y no necesita backend para operar localmente. En producción, `desktop/main.cjs` carga `dist/index.html`; en desarrollo, carga Vite desde `http://127.0.0.1:3000`.

| Comando | Uso |
| --- | --- |
| `pnpm run dev` | Desarrollo web con Vite. |
| `pnpm run check` | TypeScript sin emisión. |
| `pnpm run build` | Compilación Vite web. |
| `pnpm run desktop:dev` | Vite + Electron para desarrollo de escritorio. |
| `pnpm run desktop:package` | Directorio Windows sin empaquetar para pruebas. |
| `pnpm run desktop:dist` | Ejecutable portátil de Windows x64 dentro de `release/`. |
| `node scripts/validate-supported-stacking.mjs` | Validación de apoyo, base fabricada y maniobrabilidad. |
| `node scripts/validate-logistics-excel.mjs` | Validación de estructura y contenido de Excel. |

El ejecutable actual se generó con éxito como `PalletOptimizer-1.0.0-Windows-Portable.exe`. Durante la última generación se registró el hash SHA-256:

```text
13173ba870c80ac1538c7c79e512b9309ee87c2f8db29bfd487b4803eaf3eea9
```

El artefacto debe copiarse fuera del directorio del proyecto antes de guardar un checkpoint. `release/`, `dist/` y `node_modules/` están excluidos en `.gitignore` para no afectar el despliegue web ni crear checkpoints enormes. La generación del binario fue validada desde Linux; la apertura final y el aviso de seguridad de Windows se deben comprobar en un equipo Windows real antes de una distribución masiva.

## 10. Validación realizada

| Escenario | Resultado conocido |
| --- | --- |
| TypeScript | `pnpm run check` terminó sin errores. |
| Compilación Vite | `pnpm run build` terminó correctamente. Se mantiene una advertencia de paquete JavaScript superior a 500 kB. |
| Apoyo físico | `validate-supported-stacking.mjs` valida que no haya cajas suspendidas, que las bases fabricadas contengan la carga y que el modo ampliado se comporte correctamente. |
| Base fabricada | Casos de carga reducida y carga completa validados. |
| Maniobrabilidad | Las recomendaciones no superan 1,700 mm por lado con límite activo; aparece alternativa ampliada al habilitarla. |
| Perfil personalizado | Alta, edición/eliminación, selección de destino, mezcla, contenedor, PDF y Excel validados en un perfil de 7,000 × 2,300 × 2,400 mm y 12,000 kg. |
| PDF | Informe de perfil personalizado revisado visualmente tras corregir el espaciado. |
| Excel | Seis hojas, cajas por posición y anexo de envío validados. |
| Persistencia | Se creó un perfil, se recargó la aplicación y el perfil/destino reapareció desde `localStorage`. |
| Ejecutable Windows | `pnpm run desktop:dist` finalizó correctamente y produjo el `.exe` portátil x64. |
| Interfaz | Se revisó la pantalla principal tras el refinamiento visual de instrumentos, retícula y recomendación prioritaria. |

## 11. Riesgos, advertencias y detalles de entorno

| Riesgo o detalle | Tratamiento recomendado |
| --- | --- |
| Logs históricos | `.manus-logs` contiene antiguos errores de instalación y una antigua referencia faltante a `logisticsExcel`. No asumir que siguen vigentes: la última compilación es correcta. |
| Advertencia de bundle | Vite informa un bundle mayor de 500 kB por bibliotecas de exportación/render. Es una mejora de rendimiento, no un bloqueo. Considerar importaciones dinámicas para PDF/Excel si se prioriza la carga inicial. |
| Instalación de Electron | pnpm puede mostrar `ERR_PNPM_IGNORED_BUILDS` por `electron-winstaller`. En el entorno anterior se resolvió con `pnpm approve-builds --all` y `pnpm rebuild electron`. Solo hacerlo con dependencias revisadas. |
| Fuentes | No reintroducir Google Fonts si el requisito sin conexión se mantiene. `index.css` usa Segoe UI/Aptos y Cascadia Mono/Consolas como familias locales. |
| Seguridad Electron | No habilitar `nodeIntegration` para “facilitar” funciones. Si se añaden operaciones con archivos, crear un `preload` mínimo y exponer solo métodos concretos mediante IPC. |
| Evidencia de usuario | No fabricar reseñas, calificaciones ni testimonios ficticios. |
| Publicación web | Los checkpoints publican automáticamente el sitio. Guardar solo después de compilar y probar el flujo alterado. |

## 12. Mejoras pendientes priorizadas

| Prioridad | Mejora | Motivo y alcance sugerido |
| --- | --- | --- |
| Alta | Respaldo/restauración de espacio de trabajo | Añadir exportación/importación JSON versionada para perfiles, lista, mezcla y ajustes. Complementa `localStorage` al cambiar de equipo. |
| Alta | Prueba en Windows real | Abrir el `.exe`, importar Excel, calcular mezcla, exportar PDF/Excel y confirmar que los datos persisten tras cerrar/abrir. |
| Media | Icono y firma de código | Preparar `.ico` propio y un certificado de firma para reducir advertencias de Windows en distribución externa. |
| Media | Alertas de estabilidad | Añadir umbrales configurables para desviación de centro de gravedad, distribución de peso y altura crítica. |
| Media | Costeo logístico | Añadir costo por base fabricada, manipulación, paleta y transporte, exportable en los informes. |
| Media | Optimización del bundle | Cargar `xlsx`, `jsPDF` y `html2canvas` bajo demanda para reducir el primer render. |
| Baja | Impresión por área operativa | Vista impresa separada para fabricación, almacén y despacho. |
| Baja | Identidad en informes | Campos de empresa, logotipo y responsable en PDF/Excel. |

## 13. Procedimiento obligatorio para una futura IA

1. Leer primero `ideas.md`, este archivo y las secciones relevantes de `todo.md`.
2. Ejecutar `git status --short`; no sobrescribir trabajo no confirmado.
3. Inspeccionar el componente/motor específico antes de editar. Los cálculos no deben modificarse para resolver solo una apariencia visual.
4. Antes de tocar paletizado, correr `node scripts/validate-supported-stacking.mjs`; repetirlo después de cada cambio de algoritmo.
5. Antes de modificar exportaciones, generar una mezcla y validar PDF/Excel, incluida la existencia de plan de contenedor si corresponde.
6. Antes de entregar, ejecutar `pnpm run check && pnpm run build`; para cambios de escritorio, añadir `pnpm run desktop:dist`.
7. Si se cambia la interfaz, revisar visualmente la pantalla pertinente y actualizar `ideas.md` con decisiones permanentes.
8. Guardar un checkpoint descriptivo solo cuando la validación sea satisfactoria. El sitio web se publica automáticamente al guardar.

## 14. Prompt de reanudación sugerido

```text
Continúa el proyecto PalletOptimizer en /home/ubuntu/pallet_optimizer.

Lee primero docs/CONTINUIDAD_IA.md, ideas.md y todo.md. Parte del checkpoint 2fb4e66d.
La aplicación es React/TypeScript/Vite y también se empaqueta para Windows x64 con Electron.

Respeta estos invariantes: no cajas suspendidas; límites de altura/peso por destino; perfiles personalizados deben fluir hacia recomendaciones, contenedores y exportaciones; las listas se cargan como cajas individuales; las bases fabricadas se calculan por paleta; la paleta 3D rota solo en horizontal; PDF y Excel se originan en Descarga informe.

Conserva el estilo Technical Logistics SaaS / Modernismo Industrial Funcional con el flujo blanco y guiado ya aplicado. Productos debe abrir con la tabla de SKU y Mezcla debe priorizar sus filas editables; el destino queda como resumen plegable. Reserva el azul cielo para identidad, navegación activa, cálculo y recomendación seleccionada; usa retícula, medidas y neutros fríos únicamente donde aporten lectura logística. No reintroduzcas fuentes remotas porque existe requisito de uso local sin conexión.

Antes de cambios de algoritmo, ejecuta scripts/validate-supported-stacking.mjs. Antes de entregar, ejecuta pnpm run check y pnpm run build. Si cambias la edición local de Windows, ejecuta pnpm run desktop:dist y deja los artefactos fuera del proyecto.
```

## 15. Referencias internas

- Dirección visual: [`ideas.md`](../ideas.md)
- Registro completo de tareas y validaciones: [`todo.md`](../todo.md)
- Manual local de Windows: [`WINDOWS_LOCAL.md`](WINDOWS_LOCAL.md)
- Configuración de empaquetado: [`package.json`](../package.json)
- Motor de paletizado: [`palletCalculator.ts`](../client/src/lib/palletCalculator.ts)
- Motor de contenedores: [`containerCalculator.ts`](../client/src/lib/containerCalculator.ts)
- Punto de entrada de escritorio: [`desktop/main.cjs`](../desktop/main.cjs)
