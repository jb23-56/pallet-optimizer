// Estilo: Modernismo Industrial Funcional; configuración explícita y determinista para que el artefacto de producción sea localizable por el despliegue.
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  // Rutas relativas para que funcione tanto en el dominio raíz como bajo GitHub Pages.
  base: './',
  root: 'client',
  plugins: [react(), tailwindcss()],
  build: {
    // El root de Vite es client; el despliegue espera dist en la raíz del proyecto.
    outDir: '../dist',
    emptyOutDir: true,
  },
  server: {
    host: '0.0.0.0',
    port: 3000,
    allowedHosts: true,
  },
})
