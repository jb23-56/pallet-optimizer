# QA — Módulo de Contenedores

Fecha: 2026-08-13

Se verificó que la nueva pestaña `Contenedores` aparece junto a Cálculo Simple, Mezcla de Cajas y Comparador. En estado inicial muestra un plan pendiente, el selector de fuente y cuatro perfiles de transporte: contenedor marítimo 20 ft, contenedor marítimo 40 ft, contenedor 40 ft High Cube y semirremolque estándar.

Flujo simple validado: se calcularon 100 cajas de 600 × 400 × 300 mm sobre paletas de 1200 × 800 × 1500 mm, generando 7 paletas. En Contenedores se seleccionó `Cálculo simple · 7 paletas` y `Contenedor marítimo 40 ft`; la interfaz mostró 7 paletas disponibles y 1500 kg estimados. Al generar el plan, se obtuvo 1 contenedor con 7/7 paletas ubicadas y 23.7% de utilización de piso.

La vista 3D del contenedor mostró el volumen interior transparente, las paletas coloreadas en fila y los controles de giro horizontal. Al seleccionar `Paleta 1`, esta se resaltó con contorno amarillo y apareció únicamente la etiqueta `Paleta 1`.

Pendiente: ejecutar la misma prueba partiendo de la pestaña Mezcla de Cajas y revisar build de producción.


La fuente `Mezcla de cajas · 2 paletas` también fue validada: al seleccionarla, el módulo actualizó correctamente el resumen a 2 paletas y 460 kg; el plan produjo 1 contenedor con 2/2 paletas ubicadas y 6.8% de utilización de piso. Se añadió un refinamiento visual con la banda técnica `PALLET → CONTENEDOR`, valores métricos monoespaciados y panel de resultados con marco superior azul.

Después de corregir el hit-testing, la detección de selección en canvas usa la misma escala y desplazamiento del renderizado, por lo que los clics sobre la geometría del contenedor pueden localizar una paleta aunque el encuadre sea adaptativo.


También se comprobó el cambio de fuente al volver a entrar a la pestaña: el módulo inicia sin plan, pero al seleccionar `Cálculo simple · 7 paletas` vuelve a mostrar 7 paletas y 1500 kg disponibles, sin mezclar el resultado anterior de la fuente multi-SKU.


La prueba final generó nuevamente 1 contenedor con 7/7 paletas y 23.7% de utilización de piso. Se desplazó hasta el canvas y se hizo clic sobre la geometría de la primera paleta para validar el hit-testing directo; la selección usa ahora la transformación adaptativa del renderizador. Los controles inferiores de Paleta 1 a Paleta 7 permanecen disponibles como alternativa accesible.

Validaciones de código: `CI=true pnpm check` y `CI=true pnpm build` finalizaron correctamente. El build produce `dist/index.html` y los assets en la raíz esperada.


La validación directa quedó confirmada con una coordenada calculada dentro de la primera paleta: el canvas la resaltó con contorno amarillo y mostró la etiqueta `Paleta 1`. Esto confirma que la interacción de selección funciona con el encuadre adaptativo y no solo mediante los botones accesibles inferiores.
