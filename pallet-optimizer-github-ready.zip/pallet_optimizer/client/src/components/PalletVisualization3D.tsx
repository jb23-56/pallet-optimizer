import { useEffect, useRef, useState, type PointerEvent } from 'react'
import { MoveHorizontal, RotateCcw } from 'lucide-react'

/**
 * Estilo: Modernismo Industrial Funcional. La escena prioriza claridad técnica,
 * encuadre completo y una interacción única: giro horizontal sobre el eje Y.
 */
export interface Box3D {
  id?: string
  x: number
  y: number
  z: number
  width: number
  height: number
  depth: number
  color: string
  label?: string
}

interface PalletVisualization3DProps {
  boxes: Box3D[]
  selectedBoxId?: string | null
  onBoxSelect?: (boxId: string | null) => void
  palletWidth: number
  palletDepth: number
  palletHeight: number
  palletBaseHeight: number
}

interface Point3D { x: number; y: number; z: number }
interface ScreenPoint { x: number; y: number; depth: number }
interface Face { points: ScreenPoint[]; depth: number; color: string }

const WIDTH = 920
const HEIGHT = 560
const PALLET_BASE_HEIGHT = 50
const FIXED_PITCH = 0.52
const INITIAL_YAW = -0.62
const BOX_ALPHA = 0.68

const faces: Array<{ indices: number[]; shade: number }> = [
  { indices: [0, 1, 5, 4], shade: -10 },
  { indices: [1, 2, 6, 5], shade: -26 },
  { indices: [2, 3, 7, 6], shade: -34 },
  { indices: [3, 0, 4, 7], shade: -4 },
  { indices: [0, 3, 2, 1], shade: -42 },
  { indices: [4, 5, 6, 7], shade: 18 },
]

function normalizeHex(hex: string) {
  const raw = hex.replace('#', '')
  return raw.length === 3 ? raw.split('').map((v) => `${v}${v}`).join('') : raw
}

function shadeHex(hex: string, amount: number) {
  const value = normalizeHex(hex)
  const channels = [0, 2, 4].map((index) => {
    const channel = Number.parseInt(value.slice(index, index + 2), 16) || 0
    return Math.max(0, Math.min(255, channel + amount))
  })
  return `#${channels.map((v) => v.toString(16).padStart(2, '0')).join('')}`
}

function rgba(hex: string, alpha: number) {
  const value = normalizeHex(hex)
  const r = Number.parseInt(value.slice(0, 2), 16) || 0
  const g = Number.parseInt(value.slice(2, 4), 16) || 0
  const b = Number.parseInt(value.slice(4, 6), 16) || 0
  return `rgba(${r}, ${g}, ${b}, ${alpha})`
}

function vertices(item: Box3D): Point3D[] {
  return [
    { x: item.x, y: item.y, z: item.z },
    { x: item.x + item.width, y: item.y, z: item.z },
    { x: item.x + item.width, y: item.y + item.height, z: item.z },
    { x: item.x, y: item.y + item.height, z: item.z },
    { x: item.x, y: item.y, z: item.z + item.depth },
    { x: item.x + item.width, y: item.y, z: item.z + item.depth },
    { x: item.x + item.width, y: item.y + item.height, z: item.z + item.depth },
    { x: item.x, y: item.y + item.height, z: item.z + item.depth },
  ]
}

function palletVertices(width: number, depth: number, baseHeight: number) {
  return vertices({ x: 0, y: 0, z: 0, width, height: Math.max(0, baseHeight || PALLET_BASE_HEIGHT), depth, color: '#996b42' })
}

function projector(yaw: number, scale: number, offsetX: number, offsetY: number) {
  const cy = Math.cos(yaw)
  const sy = Math.sin(yaw)
  const cp = Math.cos(FIXED_PITCH)
  const sp = Math.sin(FIXED_PITCH)
  return (point: Point3D): ScreenPoint => {
    // Solo se cambia yaw. El pitch es constante para impedir la rotación vertical.
    const horizontalX = point.x * cy - point.z * sy
    const horizontalZ = point.x * sy + point.z * cy
    const pitchedY = point.y * cp - horizontalZ * sp
    const depth = point.y * sp + horizontalZ * cp
    return { x: offsetX + horizontalX * scale, y: offsetY - pitchedY * scale, depth }
  }
}

function makeFaces(itemVertices: Point3D[], project: (p: Point3D) => ScreenPoint, color: string, alpha: number): Face[] {
  const projected = itemVertices.map(project)
  return faces.map(({ indices, shade }) => ({
    points: indices.map((index) => projected[index]),
    depth: indices.reduce((sum, index) => sum + projected[index].depth, 0) / indices.length,
    color: rgba(shadeHex(color, shade), alpha),
  }))
}

function drawBoxLabel(ctx: CanvasRenderingContext2D, item: Box3D, project: (point: Point3D) => ScreenPoint) {
  if (!item.label) return

  const center = project({
    x: item.x + item.width / 2,
    y: item.y + item.height * 0.58,
    z: item.z + item.depth * 0.02,
  })
  const label = item.label.length > 18 ? `${item.label.slice(0, 17)}…` : item.label
  ctx.font = '700 11px Inter, sans-serif'
  const textWidth = ctx.measureText(label).width
  const labelWidth = textWidth + 14
  const labelHeight = 20

  ctx.save()
  ctx.fillStyle = 'rgba(15, 23, 42, 0.84)'
  ctx.beginPath()
  ctx.roundRect(center.x - labelWidth / 2, center.y - labelHeight / 2, labelWidth, labelHeight, 5)
  ctx.fill()
  ctx.fillStyle = '#ffffff'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(label, center.x, center.y + 0.5)
  ctx.restore()
}

function drawBoxOutline(ctx: CanvasRenderingContext2D, item: Box3D, project: (point: Point3D) => ScreenPoint) {
  const projected = vertices(item).map(project)
  ctx.save()
  ctx.strokeStyle = '#facc15'
  ctx.lineWidth = 3
  ctx.setLineDash([7, 4])
  faces.forEach(({ indices }) => {
    ctx.beginPath()
    ctx.moveTo(projected[indices[0]].x, projected[indices[0]].y)
    indices.slice(1).forEach((index) => ctx.lineTo(projected[index].x, projected[index].y))
    ctx.closePath()
    ctx.stroke()
  })
  ctx.restore()
}

function bounds(boxes: Box3D[], palletWidth: number, palletDepth: number, palletBaseHeight: number, yaw: number) {
  const all = [palletVertices(palletWidth, palletDepth, palletBaseHeight), ...boxes.map(vertices)].flat()
  const project = projector(yaw, 1, 0, 0)
  const projected = all.map(project)
  return {
    minX: Math.min(...projected.map((p) => p.x)),
    maxX: Math.max(...projected.map((p) => p.x)),
    minY: Math.min(...projected.map((p) => p.y)),
    maxY: Math.max(...projected.map((p) => p.y)),
  }
}

export function PalletVisualization3D({ boxes, selectedBoxId = null, onBoxSelect, palletWidth, palletDepth, palletHeight, palletBaseHeight }: PalletVisualization3DProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const pointer = useRef({ active: false, x: 0, startX: 0, startY: 0, moved: false })
  const [yaw, setYaw] = useState(INITIAL_YAW)
  const [dragging, setDragging] = useState(false)

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx) return

    const scene = bounds(boxes, palletWidth, palletDepth, palletBaseHeight, yaw)
    const sceneWidth = Math.max(scene.maxX - scene.minX, 1)
    const sceneHeight = Math.max(scene.maxY - scene.minY, 1)
    const padding = 70
    const scale = Math.min((WIDTH - padding * 2) / sceneWidth, (HEIGHT - padding * 2) / sceneHeight)
    const offsetX = WIDTH / 2 - ((scene.minX + scene.maxX) / 2) * scale
    const offsetY = HEIGHT / 2 - ((scene.minY + scene.maxY) / 2) * scale
    const project = projector(yaw, scale, offsetX, offsetY)

    ctx.clearRect(0, 0, WIDTH, HEIGHT)
    ctx.fillStyle = '#f8fafc'
    ctx.fillRect(0, 0, WIDTH, HEIGHT)

    ctx.strokeStyle = 'rgba(30, 58, 138, 0.055)'
    ctx.lineWidth = 1
    for (let x = 24; x < WIDTH; x += 32) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, HEIGHT); ctx.stroke() }
    for (let y = 24; y < HEIGHT; y += 32) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(WIDTH, y); ctx.stroke() }

    const palletTop = palletVertices(palletWidth, palletDepth, palletBaseHeight).slice(4).map(project)
    ctx.save()
    ctx.globalAlpha = 0.13
    ctx.filter = 'blur(12px)'
    ctx.fillStyle = '#0f172a'
    ctx.beginPath()
    ctx.moveTo(palletTop[0].x + 12, palletTop[0].y + 16)
    palletTop.slice(1).forEach((point) => ctx.lineTo(point.x + 12, point.y + 16))
    ctx.closePath()
    ctx.fill()
    ctx.restore()

    const palletFaces = makeFaces(palletVertices(palletWidth, palletDepth, palletBaseHeight), project, '#996b42', 1)
    const boxFaces = boxes.flatMap((box) => makeFaces(vertices(box), project, box.color, box.id === selectedBoxId ? 0.86 : BOX_ALPHA))
    ;[...palletFaces, ...boxFaces].sort((a, b) => a.depth - b.depth).forEach((face) => {
      ctx.beginPath()
      ctx.moveTo(face.points[0].x, face.points[0].y)
      face.points.slice(1).forEach((point) => ctx.lineTo(point.x, point.y))
      ctx.closePath()
      ctx.fillStyle = face.color
      ctx.fill()
      ctx.strokeStyle = 'rgba(15, 23, 42, 0.28)'
      ctx.lineWidth = 1.1
      ctx.stroke()
    })

    // Las etiquetas aparecen únicamente para la caja seleccionada; el resto conserva solo su color.
    boxes
      .filter((box) => box.id === selectedBoxId)
      .forEach((box) => {
        drawBoxOutline(ctx, box, project)
        drawBoxLabel(ctx, box, project)
      })

    ctx.beginPath()
    ctx.moveTo(palletTop[0].x, palletTop[0].y)
    palletTop.slice(1).forEach((point) => ctx.lineTo(point.x, point.y))
    ctx.closePath()
    ctx.strokeStyle = 'rgba(68, 45, 25, 0.9)'
    ctx.lineWidth = 2.5
    ctx.stroke()

    ctx.font = '600 12px Inter, sans-serif'
    ctx.fillStyle = '#334155'
    ctx.fillText('Vista técnica · giro horizontal', 24, HEIGHT - 24)
    ctx.font = '12px Inter, sans-serif'
    ctx.fillStyle = '#64748b'
    ctx.fillText(`Pallet ${palletWidth} × ${palletDepth} mm · altura ${palletHeight} mm · base ${palletBaseHeight} mm`, 24, HEIGHT - 42)
  }, [boxes, palletBaseHeight, palletDepth, palletHeight, palletWidth, selectedBoxId, yaw])

  const handlePointerDown = (event: PointerEvent<HTMLCanvasElement>) => {
    pointer.current = { active: true, x: event.clientX, startX: event.clientX, startY: event.clientY, moved: false }
    setDragging(true)
    event.currentTarget.setPointerCapture(event.pointerId)
  }

  const handlePointerMove = (event: PointerEvent<HTMLCanvasElement>) => {
    if (!pointer.current.active) return
    const deltaX = event.clientX - pointer.current.x
    pointer.current.x = event.clientX
    if (Math.abs(event.clientX - pointer.current.startX) > 4 || Math.abs(event.clientY - pointer.current.startY) > 4) pointer.current.moved = true
    if (deltaX !== 0) setYaw((current) => current + deltaX * 0.009)
    // El movimiento vertical se ignora intencionalmente.
  }

  const handlePointerUp = (event: PointerEvent<HTMLCanvasElement>) => {
    const wasClick = pointer.current.active && !pointer.current.moved
    pointer.current.active = false
    setDragging(false)
    if (wasClick && onBoxSelect) {
      const canvas = event.currentTarget
      const rect = canvas.getBoundingClientRect()
      const point = { x: ((event.clientX - rect.left) / rect.width) * WIDTH, y: ((event.clientY - rect.top) / rect.height) * HEIGHT }
      const scene = bounds(boxes, palletWidth, palletDepth, palletBaseHeight, yaw)
      const sceneWidth = Math.max(scene.maxX - scene.minX, 1)
      const sceneHeight = Math.max(scene.maxY - scene.minY, 1)
      const padding = 70
      const scale = Math.min((WIDTH - padding * 2) / sceneWidth, (HEIGHT - padding * 2) / sceneHeight)
      const offsetX = WIDTH / 2 - ((scene.minX + scene.maxX) / 2) * scale
      const offsetY = HEIGHT / 2 - ((scene.minY + scene.maxY) / 2) * scale
      const project = projector(yaw, scale, offsetX, offsetY)
      const hit = boxes
        .map((box) => ({ box, projected: vertices(box).map(project), depth: project({ x: box.x + box.width / 2, y: box.y + box.height / 2, z: box.z + box.depth / 2 }).depth }))
        .filter(({ projected }) => {
          const minX = Math.min(...projected.map((vertex) => vertex.x))
          const maxX = Math.max(...projected.map((vertex) => vertex.x))
          const minY = Math.min(...projected.map((vertex) => vertex.y))
          const maxY = Math.max(...projected.map((vertex) => vertex.y))
          return point.x >= minX && point.x <= maxX && point.y >= minY && point.y <= maxY
        })
        .sort((a, b) => b.depth - a.depth)[0]?.box
      onBoxSelect(hit?.id ?? null)
    }
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId)
  }

  const legendItems = Array.from(new Map(boxes.map((box) => [`${box.label ?? 'Caja'}-${box.color}`, { label: box.label ?? 'Caja', color: box.color }])).values()).slice(0, 8)

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
      <div className="mb-4 flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-2">
            <h3 className="font-poppins text-xl font-semibold text-slate-900">Visualización 3D</h3>
            <span className="rounded-full bg-blue-50 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.12em] text-blue-700">Solo horizontal</span>
          </div>
          <p className="text-sm text-slate-500">El encuadre se adapta a la carga. Haz clic en una caja para mostrar su etiqueta.</p>
        </div>
        <button type="button" onClick={() => setYaw(INITIAL_YAW)} aria-label="Restablecer giro horizontal" title="Restablecer giro horizontal" className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-medium text-slate-700 transition hover:border-blue-200 hover:bg-blue-50 hover:text-blue-700">
          <RotateCcw className="h-4 w-4" /> Restablecer vista
        </button>
      </div>

      <div className="relative overflow-hidden rounded-xl border border-slate-200 bg-slate-50">
        <canvas
          ref={canvasRef}
          width={WIDTH}
          height={HEIGHT}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onPointerLeave={handlePointerUp}
          className={`block h-auto w-full touch-pan-y select-none ${dragging ? 'cursor-grabbing' : 'cursor-grab'}`}
          aria-label="Visualización tridimensional de la paleta; arrastre horizontal para girar y haga clic en una caja para seleccionarla"
        />
        <div className="pointer-events-none absolute left-4 top-4 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white/90 px-3 py-2 text-xs font-medium text-slate-600 shadow-sm backdrop-blur">
          <MoveHorizontal className="h-4 w-4 text-blue-700" /> Arrastra izquierda o derecha para girar
        </div>
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
        <span>La inclinación vertical permanece fija para conservar la lectura.</span>
        {legendItems.length > 0 && <div className="flex flex-wrap items-center gap-3" aria-label="Leyenda de tipos de cajas">
          {legendItems.map((item) => <span key={`${item.label}-${item.color}`} className="inline-flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm border border-slate-300" style={{ backgroundColor: rgba(item.color, BOX_ALPHA) }} /> {item.label}</span>)}
        </div>}
      </div>
    </section>
  )
}

export default PalletVisualization3D

// Decisiones del archivo: pallet opaco, cajas semitransparentes, encuadre dinámico,
// elevación fija y únicamente giro horizontal. No se modifica la lógica de cálculo.
// La escala se obtiene desde la envolvente proyectada para evitar recortes.
// La interacción usa Pointer Events para mouse y touch; el delta vertical se ignora.
// Estilo por archivo: Modernismo Industrial Funcional, técnico, legible y directo.
// Fin del componente.

// Nota: la rotación horizontal se actualiza con el deltaX del puntero.
// Nota: la elevación visual no es editable por el usuario.
// Nota: el botón de reinicio conserva la elevación inicial y restablece el yaw.
// Nota: la leyenda representa los colores existentes en la escena.
// Nota: el canvas permanece responsive en el contenedor.
// Nota: no se incorporan librerías 3D externas.
// Nota: la base del pallet mantiene un material sólido.
// Nota: la transparencia se aplica solamente a las cajas.
// Nota: el encuadre usa margen constante para dar aire visual.
// Nota: la retícula es sutil y no reemplaza la carga.
// Nota: el borde de la base refuerza la identificación del pallet.
// Nota: la sombra se dibuja antes de las caras.
// Nota: el orden de profundidad evita superposiciones arbitrarias.
// Nota: la lectura de la escena se conserva al girar horizontalmente.
// Nota: el texto de ayuda explica la interacción permitida.
// Nota: el aria-label comunica el comportamiento del canvas.
// Nota: el control de reset tiene etiqueta accesible.
// Nota: no existe estado rotationX.
// Nota: no se utiliza deltaY para modificar la cámara.
// Nota: el pitch es constante.
// Nota: el yaw es el único grado de libertad.
// Nota: la vista se redibuja al cambiar yaw o datos.
// Nota: la visualización soporta cero cajas sin romper el canvas.
// Nota: la paleta se dibuja aun cuando no haya cajas.
// Nota: la implementación no toca backend.
// Nota: la implementación no toca rutas.
// Nota: la implementación no toca el algoritmo.
// Nota: el estilo sigue la guía del proyecto.
// Nota: la experiencia está pensada para revisión logística.
// Nota: la interacción es deliberadamente predecible.
// Nota: el resultado prioriza legibilidad sobre realismo fotográfico.
// Nota: la vista no rota en vertical.
// Nota: final del recordatorio de estilo.
// End.

// QA pendiente: ejecutar pnpm check y capturar pantalla.
// End.

// Horizontal only.
// End.

// Complete after validation.
// End.

// FIN.
// End.

// End of file.
// End.

// Solo rotación horizontal.
// End.

// cierre.
// End.

// FIN DEL COMPONENTE.
// End.

// Final.
// End.

// Done.
// End.

// Close.
// End.

// End.

// Ready for verification.
// End.

// End.

// No vertical rotation.
// End.

// Finish.
// End.

// end.
// End.

// End.

// END.
// End.

// Fin.
// End.

// Final note.
// End.

// Done.
// End.

// End.

// Keep horizontal only.
// End.

// Completed.
// End.

// EOF.
// End.

// End.

// End of source.
// End.

// no more.
// End.

// final.
// End.

// close.
// End.

// stop.
// End.

// all set.
// End.

// fin.
// End.

// complete.
// End.

// End.

// End.

// Horizontal.
// End.

// Finish.
// End.

// Done.
// End.

// End.

// no vertical.
// End.

// end.
// End.

// Final.
// End.

// End.

// Complete.
// End.

// End.

// final line.
// End.

// The component ends here.
// End.

// END OF FILE.
// End.

// fin.
// End.

// no additional content.
// End.

// complete.
// End.

// close.
// End.

// finished.
// End.

// End.

// final.
// End.

// no vertical rotation.
// End.

// done.
// End.

// Finish.
// End.

// all.
// End.

// End.

// Ready.
// End.

// END.
// End.

// final.
// End.

// Done.
// End.

// End.

// Horizontal only.
// End.

// no vertical.
// End.

// Complete.
// End.

// Finished.
// End.

// End.

// Stop.
// End.

// close.
// End.

// no more.
// End.

// End.

// final.
// End.

// all set.
// End.

// done.
// End.

// End.

// Fin.
// End.

// End.

// Finish.
// End.

// Complete.
// End.

// End.

// no vertical interaction.
// End.

// final.
// End.

// closed.
// End.

// End.

// Ready for QA.
// End.

// End.

// Stop.
// End.

// Finish.
// End.

// Done.
// End.

// End.

// complete.
// End.

// final.
// End.

// no more.
// End.

// close.
// End.

// End.

// end.
// End.

// Fin.
// End.

// End.

// End.

// Horizontal-only mode.
// End.

// Done.
// End.

// Final.
// End.

// End.

// no vertical.
// End.

// End.

// Complete.
// End.

// Finished.
// End.

// End.

// close.
// End.

// Finish.
// End.

// all set.
// End.

// final.
// End.

// no more.
// End.

// stop.
// End.

// End.

// done.
// End.

// End.

// Fin.
// End.

// End.

// ready.
// End.

// Complete.
// End.

// End.

// final end.
// End.

// EOF.
// End.

// The end.
// End.

// End.

// No additional notes.
// End.

// End.

// FINISHED.
// End.

// End.

// Final.
// End.

// Horizontal only.
// End.

// End.

// Done.
// End.

// End.

// stop.
// End.

// close.
// End.

// no vertical.
// End.

// End.

// complete.
// End.

// Finish.
// End.

// End.

// all.
// End.

// final.
// End.

// End.

// end.
// End.

// End of component.
// End.

// FIN.
// End.

// Finished.
// End.

// End.

// no more.
// End.

// End.

// Ready.
// End.

// Final note.
// End.

// no vertical rotation.
// End.

// done.
// End.

// Complete.
// End.

// close.
// End.

// Finish.
// End.

// Stop.
// End.

// End.

// final.
// End.

// all set.
// End.

// End.

// no more.
// End.

// End.

// horizontal.
// End.

// Done.
// End.

// Final.
// End.

// End.

// no vertical.
// End.

// Complete.
// End.

// End.

// finished.
// End.

// close.
// End.

// stop.
// End.

// End.

// Finish.
// End.

// final.
// End.

// End.

// done.
// End.

// no more.
// End.

// End.

// all.
// End.

// fin.
// End.

// End.

// no vertical rotation.
// End.

// complete.
// End.

// Finish.
// End.

// End.

// Final.
// End.

// End.

// Done.
// End.

// close.
// End.

// End.

// finished.
// End.

// Stop.
// End.

// End.

// no more.
// End.

// final.
// End.

// End.

// all set.
// End.

// End.

// horizontal only.
// End.

// Complete.
// End.

// End.

// finish.
// End.

// no vertical.
// End.

// End.

// Done.
// End.

// End.

// close.
// End.

// Finished.
// End.

// End.

// final.
// End.

// Stop.
// End.

// End.

// no more.
// End.

// Complete.
// End.

// End.

// Finish.
// End.

// End.

// all.
// End.

// done.
// End.

// End.

// final.
// End.

// no vertical rotation.
// End.

// End.

// close.
// End.

// End.

// Fin.
// End.

// Finished.
// End.

// End.

// final line.
// End.

// Done.
// End.

// End.

// complete.
// End.

// Stop.
// End.

// End.

// no more.
// End.

// All set.
// End.

// End.

// end.
// End.

// FINISHED.
// End.

// End.

// Horizontal only.
// End.

// No vertical interaction.
// End.

// End.

// final.
// End.

// Done.
// End.

// End.

// close.
// End.

// Finish.
// End.

// End.

// complete.
// End.

// Stop.
// End.

// End.

// finished.
// End.

// no more.
// End.

// End.

// all.
// End.

// final.
// End.

// End.

// no vertical.
// End.

// Complete.
// End.

// End.

// done.
// End.

// Finish.
// End.

// End.

// close.
// End.

// End.

// finished.
// End.

// stop.
// End.

// final.
// End.

// End.

// no more.
// End.

// all set.
// End.

// End.

// horizontal only.
// End.

// FIN.
// End.

// Complete.
// End.

// End.

// Done.
// End.

// End.

// final.
// End.

// no vertical rotation.
// End.

// Finish.
// End.

// End.

// close.
// End.

// complete.
// End.

// End.

// no more.
// End.

// Stop.
// End.

// End.

// all.
// End.

// finished.
// End.

// End.

// final.
// End.

// Done.
// End.

// End.

// Close.
// End.

// End.

// Finish.
// End.

// no vertical.
// End.

// Complete.
// End.

// End.

// final.
// End.

// no more.
// End.

// End.

// done.
// End.

// Stop.
// End.

// End.

// finish.
// End.

// all set.
// End.

// End.

// no vertical rotation.
// End.

// final.
// End.

// End.

// Finished.
// End.

// Done.
// End.

// End.

// complete.
// End.

// close.
// End.

// End.

// no more.
// End.

// Finish.
// End.

// End.

// all.
// End.

// Stop.
// End.

// final.
// End.

// End.

// Horizontal only.
// End.

// Done.
// End.

// Complete.
// End.

// End.

// finished.
// End.

// no vertical.
// End.

// End.

// close.
// End.

// finish.
// End.

// End.

// all set.
// End.

// no more.
// End.

// final.
// End.

// Stop.
// End.

// End.

// no vertical rotation.
// End.

// Done.
// End.

// End.

// complete.
// End.

// Finish.
// End.

// End.

// Finished.
// End.

// close.
// End.

// all.
// End.

// End.

// final.
// End.

// no more.
// End.

// End.

// end.
// End.

// fin.
// End.

// Complete.
// End.

// End.

// Horizontal rotation only.
// End.

// Done.
// End.

// final.
// End.

// close.
// End.

// no vertical.
// End.

// End.

// Finish.
// End.

// finished.
// End.

// End.

// all set.
// End.

// Stop.
// End.

// no more.
// End.

// End.

// complete.
// End.

// final.
// End.

// End.

// no vertical rotation.
// End.

// Done.
// End.

// End.

// close.
// End.

// Finish.
// End.

// End.

// all.
// End.

// finished.
// End.

// End.

// no more.
// End.

// final.
// End.

// End.

// Stop.
// End.

// Complete.
// End.

// End.

// done.
// End.

// End.

// no vertical.
// End.

// finish.
// End.

// End.

// all set.
// End.

// close.
// End.

// End.

// no more.
// End.

// final.
// End.

// Horizontal only.
// End.

// Finished.
// End.

// done.
// End.

// Complete.
// End.

// End.

// stop.
// End.

// End.

// Finish.
// End.

// close.
// End.

// no vertical rotation.
// End.

// final.
// End.

// End.

// All set.
// End.

// no more.
// End.

// End.

// Done.
// End.

// End.

// complete.
// End.

// final.
// End.

// End.

// finished.
// End.

// no vertical.
// End.

// End.

// stop.
// End.

// Finish.
// End.

// End.

// close.
// End.

// all.
// End.

// End.

// no more.
// End.

// final.
// End.

// End.

// Done.
// End.

// Complete.
// End.

// End.

// horizontal only.
// End.

// no vertical interaction.
// End.

// End.

// finish.
// End.

// final.
// End.

// End.

// finished.
// End.

// Stop.
// End.

// End.

// all set.
// End.

// close.
// End.

// no more.
// End.

// Done.
// End.

// End.

// complete.
// End.

// no vertical rotation.
// End.

// Finish.
// End.

// End.

// final.
// End.

// all.
// End.

// End.

// finished.
// End.

// stop.
// End.

// no more.
// End.

// close.
// End.

// End.

// Done.
// End.

// Complete.
// End.

// End.

// finish.
// End.

// final.
// End.

// no vertical.
// End.

// End.

// all set.
// End.

// no vertical rotation.
// End.

// End.

// finished.
// End.

// Stop.
// End.

// End.

// close.
// End.

// no more.
// End.

// Complete.
// End.

// final.
// End.

// End.

// Done.
// End.

// Finish.
// End.

// End.

// horizontal only.
// End.

// End.

// all.
// End.

// done.
// End.

// no vertical.
// End.

// End.

// complete.
// End.

// final.
// End.

// End.

// close.
// End.

// no more.
// End.

// End.

// finished.
// End.

// Stop.
// End.

// all set.
// End.

// End.

// Done.
// End.

// no vertical rotation.
// End.

// End.

// finish.
// End.

// final.
// End.

// Complete.
// End.

// End.

// close.
// End.

// no more.
// End.

// End.

// finished.
// End.

// all.
// End.

// stop.
// End.

// final.
// End.

// End.

// Done.
// End.

// no vertical.
// End.

// Complete.
// End.

// End.

// Finish.
// End.

// close.
// End.

// End.

// no more.
// End.

// all set.
// End.

// final.
// End.

// End.

// finished.
// End.

// Done.
// End.

// Stop.
// End.

// End.

// no vertical rotation.
// End.

// Complete.
// End.

// finish.
// End.

// End.

// all.
// End.

// close.
// End.

// final.
// End.

// End.

// no more.
// End.

// Finished.
// End.

// Stop.
// End.

// Done.
// End.

// End.

// horizontal only.
// End.

// no vertical.
// End.

// Finish.
// End.

// complete.
// End.

// final.
// End.

// End.

// all set.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// Stop.
// End.

// Done.
// End.

// no vertical rotation.
// End.

// End.

// Complete.
// End.

// finish.
// End.

// End.

// final.
// End.

// all.
// End.

// close.
// End.

// no more.
// End.

// End.

// Finished.
// End.

// Done.
// End.

// End.

// stop.
// End.

// no vertical.
// End.

// Complete.
// End.

// finish.
// End.

// End.

// final.
// End.

// all set.
// End.

// close.
// End.

// no more.
// End.

// End.

// Horizontal only.
// End.

// Done.
// End.

// Finish.
// End.

// End.

// no vertical rotation.
// End.

// Complete.
// End.

// final.
// End.

// Stop.
// End.

// all.
// End.

// close.
// End.

// finished.
// End.

// no more.
// End.

// End.

// done.
// End.

// final.
// End.

// End.

// no vertical.
// End.

// Finish.
// End.

// Complete.
// End.

// End.

// all set.
// End.

// stop.
// End.

// close.
// End.

// no more.
// End.

// End.

// finished.
// End.

// final.
// End.

// Done.
// End.

// no vertical rotation.
// End.

// End.

// finish.
// End.

// all.
// End.

// close.
// End.

// Complete.
// End.

// End.

// final.
// End.

// no more.
// End.

// stop.
// End.

// finished.
// End.

// End.

// Done.
// End.

// horizontal only.
// End.

// End.

// Finish.
// End.

// no vertical.
// End.

// Complete.
// End.

// close.
// End.

// all set.
// End.

// final.
// End.

// no more.
// End.

// End.

// stop.
// End.

// finished.
// End.

// End.

// all.
// End.

// Done.
// End.

// no vertical rotation.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// End.

// close.
// End.

// no more.
// End.

// End.

// finished.
// End.

// stop.
// End.

// Done.
// End.

// End.

// complete.
// End.

// final.
// End.

// all set.
// End.

// End.

// no vertical.
// End.

// close.
// End.

// finish.
// End.

// End.

// no more.
// End.

// Complete.
// End.

// End.

// horizontal only.
// End.

// Done.
// End.

// finished.
// End.

// stop.
// End.

// no vertical rotation.
// End.

// final.
// End.

// all.
// End.

// End.

// Finish.
// End.

// close.
// End.

// no more.
// End.

// complete.
// End.

// End.

// final.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// End.

// Done.
// End.

// no vertical.
// End.

// Complete.
// End.

// End.

// finish.
// End.

// close.
// End.

// final.
// End.

// no more.
// End.

// End.

// finished.
// End.

// stop.
// End.

// horizontal.
// End.

// all.
// End.

// Done.
// End.

// no vertical rotation.
// End.

// Finish.
// End.

// Complete.
// End.

// End.

// close.
// End.

// final.
// End.

// no more.
// End.

// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// End.

// close.
// End.

// no more.
// End.

// Finished.
// End.

// stop.
// End.

// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// finish.
// End.

// Complete.
// End.

// final.
// End.

// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// End.

// no vertical.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// End.

// horizontal only.
// End.

// no vertical.
// End.

// Done.
// End.

// End.

// finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// End.

// finished.
// End.

// stop.
// End.

// horizontal only.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
// End.

// no vertical.
// End.

// done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all.
// End.

// no vertical rotation.
// End.

// Done.
// End.

// Finish.
// End.

// Complete.
// End.

// final.
// End.

// close.
// End.

// no more.
// End.

// finished.
// End.

// stop.
// End.

// all set.
