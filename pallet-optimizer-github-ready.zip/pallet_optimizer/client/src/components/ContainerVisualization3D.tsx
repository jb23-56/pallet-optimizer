// Estilo: Modernismo Industrial Funcional; escena longitudinal de carga, estructura metálica translúcida y etiquetas operativas sobre caras visibles.
/* Estilo: Plano de Carga Guiado; lectura y acciones se presentan tras el plan de carga, antes de la escena, mientras los controles de cámara permanecen como instrumentos compactos. */
import { ChevronDown, ChevronUp, Eye, EyeOff, GitCompare, Hand, MoveHorizontal, RotateCcw, RotateCw, Ruler, Truck, ZoomIn, ZoomOut } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import type { ContainerLoadMetrics, ContainerLooseBoxPlacement, ContainerPalletPlacement, ContainerSpec } from '../lib/containerCalculator'

export type ManualCargoAdjustment = {
  x: number
  y: number
  z: number
  placedLength: number
  placedWidth: number
}

interface ContainerVisualization3DProps {
  container: ContainerSpec
  pallets: ContainerPalletPlacement[]
  boxes?: ContainerLooseBoxPlacement[]
  originalPallets?: ContainerPalletPlacement[]
  originalBoxes?: ContainerLooseBoxPlacement[]
  loadMetrics?: ContainerLoadMetrics
  selectedPalletId?: string | null
  onPalletSelect?: (palletId: string | null) => void
  selectedBoxId?: string | null
  onBoxSelect?: (boxId: string | null) => void
  onCargoAdjust?: (cargoId: string, adjustment: ManualCargoAdjustment) => void
}

interface Point3D { x: number; y: number; z: number }
interface ScreenPoint { x: number; y: number; depth: number }
interface Face { points: ScreenPoint[]; depth: number; color: string }
interface DimensionLabelArea { x: number; y: number; width: number; height: number }
interface DimensionLabelOffset { x: number; y: number }

type SceneCargo = ContainerPalletPlacement | ContainerLooseBoxPlacement
type CameraView = 'front' | 'side' | 'top' | 'isometric'

const WIDTH = 1200
const HEIGHT = 620
const FIXED_PITCH = 0.34
const INITIAL_YAW = -0.3
const CAMERA_VIEWS: Record<CameraView, { label: string; yaw: number; pitch: number }> = {
  front: { label: 'Frontal', yaw: 0, pitch: 0 },
  side: { label: 'Lateral', yaw: Math.PI / 2, pitch: 0 },
  top: { label: 'Superior', yaw: 0, pitch: 0 },
  isometric: { label: 'Isométrica', yaw: INITIAL_YAW, pitch: FIXED_PITCH },
}
const faces: Array<{ indices: number[]; shade: number }> = [
  { indices: [0, 1, 5, 4], shade: -8 },
  { indices: [1, 2, 6, 5], shade: -24 },
  { indices: [2, 3, 7, 6], shade: 18 },
  { indices: [3, 0, 4, 7], shade: -4 },
  { indices: [0, 3, 2, 1], shade: -36 },
  { indices: [4, 5, 6, 7], shade: 6 },
]

function normalizeHex(hex: string) {
  const raw = hex.replace('#', '')
  return raw.length === 3 ? raw.split('').map((v) => `${v}${v}`).join('') : raw
}

function shadeHex(hex: string, amount: number) {
  const value = normalizeHex(hex)
  const channels = [0, 2, 4].map((index) => {
    const channel = Number.parseInt(value.slice(index, index + 2), 16) || 0
    return Math.max(0, Math.min(255, channel + amount))
  })
  return `#${channels.map((v) => v.toString(16).padStart(2, '0')).join('')}`
}

function rgba(hex: string, alpha: number) {
  const value = normalizeHex(hex)
  const r = Number.parseInt(value.slice(0, 2), 16) || 0
  const g = Number.parseInt(value.slice(2, 4), 16) || 0
  const b = Number.parseInt(value.slice(4, 6), 16) || 0
  return `rgba(${r}, ${g}, ${b}, ${alpha})`
}

function vertices(item: { x: number; y: number; z: number; width: number; height: number; depth: number }): Point3D[] {
  return [
    { x: item.x, y: item.y, z: item.z }, { x: item.x + item.width, y: item.y, z: item.z },
    { x: item.x + item.width, y: item.y + item.height, z: item.z }, { x: item.x, y: item.y + item.height, z: item.z },
    { x: item.x, y: item.y, z: item.z + item.depth }, { x: item.x + item.width, y: item.y, z: item.z + item.depth },
    { x: item.x + item.width, y: item.y + item.height, z: item.z + item.depth }, { x: item.x, y: item.y + item.height, z: item.z + item.depth },
  ]
}

function cargoGeometry(item: SceneCargo) {
  const height = 'placedHeight' in item ? item.placedHeight : item.height
  return { x: item.x, y: item.y, z: item.z, width: item.placedLength, height, depth: item.placedWidth }
}

function cargoOverlaps(first: SceneCargo, second: SceneCargo) {
  const a = cargoGeometry(first)
  const b = cargoGeometry(second)
  return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y && a.z < b.z + b.depth && a.z + a.depth > b.z
}

function isInsideContainer(item: SceneCargo, container: ContainerSpec) {
  const geometry = cargoGeometry(item)
  return geometry.x >= 0 && geometry.y >= 0 && geometry.z >= 0 && geometry.x + geometry.width <= container.length && geometry.y + geometry.height <= container.height && geometry.z + geometry.depth <= container.width
}

function hasPhysicalSupport(candidate: SceneCargo, otherCargo: SceneCargo[]) {
  const geometry = cargoGeometry(candidate)
  if (geometry.y <= 1) return true
  const footprint = geometry.width * geometry.depth
  if (footprint <= 0) return false
  const supportedArea = otherCargo.reduce((sum, item) => {
    const support = cargoGeometry(item)
    if (Math.abs(support.y + support.height - geometry.y) > 2) return sum
    const overlapX = Math.max(0, Math.min(geometry.x + geometry.width, support.x + support.width) - Math.max(geometry.x, support.x))
    const overlapZ = Math.max(0, Math.min(geometry.z + geometry.depth, support.z + support.depth) - Math.max(geometry.z, support.z))
    return sum + overlapX * overlapZ
  }, 0)
  return supportedArea >= footprint * 0.7
}

function sceneLoadMetrics(items: SceneCargo[], container: ContainerSpec, fallback?: ContainerLoadMetrics) {
  if (items.length === 0) return fallback
  const hasMeasuredWeight = items.some((item) => item.weight > 0)
  const totalMass = items.reduce((sum, item) => sum + (hasMeasuredWeight ? Math.max(0, item.weight) : 1), 0)
  const weightedCenter = items.reduce((sum, item) => {
    const geometry = cargoGeometry(item)
    const mass = hasMeasuredWeight ? Math.max(0, item.weight) : 1
    return { longitudinal: sum.longitudinal + (geometry.x + geometry.width / 2) * mass, transversal: sum.transversal + (geometry.z + geometry.depth / 2) * mass, vertical: sum.vertical + (geometry.y + geometry.height / 2) * mass }
  }, { longitudinal: 0, transversal: 0, vertical: 0 })
  const maxOccupiedHeight = items.reduce((maximum, item) => Math.max(maximum, cargoGeometry(item).y + cargoGeometry(item).height), 0)
  const centerOfGravity = totalMass > 0 ? { longitudinal: weightedCenter.longitudinal / totalMass, transversal: weightedCenter.transversal / totalMass, vertical: weightedCenter.vertical / totalMass } : { longitudinal: 0, transversal: 0, vertical: 0 }
  return {
    maxOccupiedHeight,
    heightUtilizationPercentage: container.height > 0 ? (maxOccupiedHeight / container.height) * 100 : 0,
    centerOfGravity,
    centerOfGravityPercentage: { longitudinal: container.length > 0 ? (centerOfGravity.longitudinal / container.length) * 100 : 0, transversal: container.width > 0 ? (centerOfGravity.transversal / container.width) * 100 : 0, vertical: container.height > 0 ? (centerOfGravity.vertical / container.height) * 100 : 0 },
    usesUnitWeightFallback: !hasMeasuredWeight,
  }
}

function projector(yaw: number, pitch: number, scale: number, offsetX: number, offsetY: number, view: CameraView) {
  const cy = Math.cos(yaw)
  const sy = Math.sin(yaw)
  const cp = Math.cos(pitch)
  const sp = Math.sin(pitch)
  return (point: Point3D): ScreenPoint => {
    if (view === 'top') return { x: offsetX + point.x * scale, y: offsetY - point.z * scale, depth: point.y }
    const horizontalX = point.x * cy - point.z * sy
    const horizontalZ = point.x * sy + point.z * cy
    const pitchedY = point.y * cp - horizontalZ * sp
    const depth = point.y * sp + horizontalZ * cp
    return { x: offsetX + horizontalX * scale, y: offsetY - pitchedY * scale, depth }
  }
}

function makeFaces(itemVertices: Point3D[], project: (point: Point3D) => ScreenPoint, color: string, alpha: number): Face[] {
  const projected = itemVertices.map(project)
  return faces.map(({ indices, shade }) => ({ points: indices.map((index) => projected[index]), depth: indices.reduce((sum, index) => sum + projected[index].depth, 0) / indices.length, color: rgba(shadeHex(color, shade), alpha) }))
}

function drawPolygon(ctx: CanvasRenderingContext2D, points: ScreenPoint[], fill: string, stroke = 'rgba(15, 23, 42, 0.62)', lineWidth = 1.15) {
  ctx.beginPath()
  ctx.moveTo(points[0].x, points[0].y)
  points.slice(1).forEach((point) => ctx.lineTo(point.x, point.y))
  ctx.closePath()
  ctx.fillStyle = fill
  ctx.fill()
  ctx.strokeStyle = stroke
  ctx.lineWidth = lineWidth
  ctx.stroke()
}

function drawFace(ctx: CanvasRenderingContext2D, face: Face) {
  drawPolygon(ctx, face.points, face.color)
}

function drawLine(ctx: CanvasRenderingContext2D, from: ScreenPoint, to: ScreenPoint, color: string, width = 1.5, dash: number[] = []) {
  ctx.beginPath()
  ctx.moveTo(from.x, from.y)
  ctx.lineTo(to.x, to.y)
  ctx.strokeStyle = color
  ctx.lineWidth = width
  ctx.setLineDash(dash)
  ctx.stroke()
  ctx.setLineDash([])
}

function drawContainerShell(ctx: CanvasRenderingContext2D, container: { x: number; y: number; z: number; width: number; height: number; depth: number }, project: (point: Point3D) => ScreenPoint) {
  const projected = vertices(container).map(project)
  const farWall = [projected[4], projected[5], projected[6], projected[7]]
  const rearWall = [projected[3], projected[0], projected[4], projected[7]]

  ctx.save()
  drawPolygon(ctx, farWall, 'rgba(203, 213, 225, 0.12)', 'rgba(30, 41, 59, 0.72)', 1.6)
  drawPolygon(ctx, rearWall, 'rgba(203, 213, 225, 0.07)', 'rgba(30, 41, 59, 0.72)', 1.6)

  const ribCount = Math.max(8, Math.min(18, Math.round(container.width / 170)))
  for (let index = 0; index <= ribCount; index += 1) {
    const z = (container.depth / ribCount) * index
    drawLine(ctx, project({ x: 0, y: 0, z }), project({ x: 0, y: container.height, z }), 'rgba(51, 65, 85, 0.3)', 0.8)
    drawLine(ctx, project({ x: container.width, y: 0, z }), project({ x: container.width, y: container.height, z }), 'rgba(51, 65, 85, 0.3)', 0.8)
  }

  const structuralEdges = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]]
  structuralEdges.forEach(([from, to]) => drawLine(ctx, projected[from], projected[to], 'rgba(15, 23, 42, 0.9)', 2.2))
  ctx.restore()
}

const verticalLabelFaces = [
  { indices: [1, 2, 6, 5], horizontal: [2, 6], vertical: [1, 2] },
  { indices: [3, 0, 4, 7], horizontal: [3, 7], vertical: [0, 3] },
  { indices: [0, 3, 2, 1], horizontal: [3, 2], vertical: [0, 3] },
  { indices: [4, 5, 6, 7], horizontal: [6, 7], vertical: [5, 6] },
]

type LabelFace = typeof verticalLabelFaces[number] & { points: ScreenPoint[]; depth: number }

function faceCenter(points: ScreenPoint[]) {
  return points.reduce((center, point) => ({ x: center.x + point.x / points.length, y: center.y + point.y / points.length, depth: center.depth + point.depth / points.length }), { x: 0, y: 0, depth: 0 })
}

function labelFacesFor(item: SceneCargo, project: (point: Point3D) => ScreenPoint): LabelFace[] {
  const projected = vertices(cargoGeometry(item)).map(project)
  return verticalLabelFaces
    .map((face) => ({ ...face, points: face.indices.map((index) => projected[index]) }))
    .map((face) => ({ ...face, depth: faceCenter(face.points).depth }))
    .sort((a, b) => b.depth - a.depth)
    .slice(0, 2)
}

function pointInsidePolygon(point: ScreenPoint, polygon: ScreenPoint[]) {
  let inside = false
  for (let current = 0, previous = polygon.length - 1; current < polygon.length; previous = current++) {
    const currentPoint = polygon[current]
    const previousPoint = polygon[previous]
    const intersects = ((currentPoint.y > point.y) !== (previousPoint.y > point.y)) && (point.x < ((previousPoint.x - currentPoint.x) * (point.y - currentPoint.y)) / (previousPoint.y - currentPoint.y) + currentPoint.x)
    if (intersects) inside = !inside
  }
  return inside
}

function directlyVisibleLabelFaces(item: SceneCargo, cargo: SceneCargo[], project: (point: Point3D) => ScreenPoint) {
  const candidates = labelFacesFor(item, project)
  const occluders = cargo
    .filter((candidate) => candidate.id !== item.id)
    .flatMap((candidate) => labelFacesFor(candidate, project))
  return candidates.filter((face) => {
    const center = faceCenter(face.points)
    const samples = [center, ...face.points.map((point) => ({ x: center.x * 0.3 + point.x * 0.7, y: center.y * 0.3 + point.y * 0.7, depth: center.depth * 0.3 + point.depth * 0.7 }))]
    return !occluders.some((occluder) => occluder.depth > face.depth + 0.01 && samples.every((point) => pointInsidePolygon(point, occluder.points)))
  })
}

function drawCargoLabels(ctx: CanvasRenderingContext2D, item: SceneCargo, facesToLabel: LabelFace[], force = false) {
  const visibleFaces = facesToLabel

  visibleFaces.forEach((face) => {
    const pointAt = (vertexIndex: number) => face.points[face.indices.indexOf(vertexIndex)]
    const from = pointAt(face.horizontal[0])
    const to = pointAt(face.horizontal[1])
    const verticalFrom = pointAt(face.vertical[0])
    const verticalTo = pointAt(face.vertical[1])
    const faceWidth = Math.hypot(to.x - from.x, to.y - from.y)
    const faceHeight = Math.hypot(verticalTo.x - verticalFrom.x, verticalTo.y - verticalFrom.y)
    if (!force && (faceWidth < 58 || faceHeight < 48)) return

    let angle = Math.atan2(to.y - from.y, to.x - from.x)
    if (angle > Math.PI / 2 || angle < -Math.PI / 2) angle += Math.PI
    const availableWidth = faceWidth * 0.86
    const minimumFontSize = force ? 6 : 8
    let fontSize = Math.min(15, Math.max(minimumFontSize, Math.round(Math.min(faceHeight * 0.25, faceWidth * 0.12))))
    ctx.font = `800 ${fontSize}px Poppins, Arial, sans-serif`
    while (fontSize > minimumFontSize && ctx.measureText(item.label).width > availableWidth) {
      fontSize -= 1
      ctx.font = `800 ${fontSize}px Poppins, Arial, sans-serif`
    }
    let label = item.label
    if (ctx.measureText(label).width > availableWidth) {
      while (label.length > 1 && ctx.measureText(`${label.slice(0, -1)}…`).width > availableWidth) label = label.slice(0, -1)
      label = `${label}…`
    }
    const center = faceCenter(face.points)

    ctx.save()
    ctx.translate(center.x, center.y)
    ctx.rotate(angle)
    ctx.font = `800 ${fontSize}px Poppins, Arial, sans-serif`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.lineWidth = Math.max(1, fontSize * 0.14)
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.76)'
    ctx.strokeText(label, 0, 0)
    ctx.fillStyle = '#0f172a'
    ctx.fillText(label, 0, 0)
    ctx.restore()
  })
}

function drawSelectedOutline(ctx: CanvasRenderingContext2D, item: SceneCargo, project: (point: Point3D) => ScreenPoint) {
  const projected = vertices(cargoGeometry(item)).map(project)
  ctx.save()
  faces.forEach(({ indices }) => {
    ctx.beginPath()
    ctx.moveTo(projected[indices[0]].x, projected[indices[0]].y)
    indices.slice(1).forEach((index) => ctx.lineTo(projected[index].x, projected[index].y))
    ctx.closePath()
    ctx.strokeStyle = '#facc15'
    ctx.lineWidth = 3.2
    ctx.setLineDash([8, 4])
    ctx.stroke()
  })
  ctx.restore()
}

function drawOriginalReference(ctx: CanvasRenderingContext2D, item: SceneCargo, project: (point: Point3D) => ScreenPoint) {
  const projected = vertices(cargoGeometry(item)).map(project)
  ctx.save()
  ctx.strokeStyle = 'rgba(168, 85, 247, 0.95)'
  ctx.lineWidth = 2.1
  ctx.setLineDash([5, 5])
  ;[[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4], [1, 2, 6, 5], [2, 3, 7, 6], [3, 0, 4, 7]].forEach((indices) => {
    ctx.beginPath()
    ctx.moveTo(projected[indices[0]].x, projected[indices[0]].y)
    indices.slice(1).forEach((index) => ctx.lineTo(projected[index].x, projected[index].y))
    ctx.closePath()
    ctx.stroke()
  })
  ctx.restore()
}

function drawSelectedCargoDimensions(ctx: CanvasRenderingContext2D, item: SceneCargo, project: (point: Point3D) => ScreenPoint) {
  const geometry = cargoGeometry(item)
  const anchor = project({ x: geometry.x + geometry.width / 2, y: geometry.y + geometry.height, z: geometry.z + geometry.depth / 2 })
  const label = `${item.label} · ${Math.round(geometry.width).toLocaleString()} × ${Math.round(geometry.depth).toLocaleString()} × ${Math.round(geometry.height).toLocaleString()} mm`
  ctx.save()
  ctx.font = '800 10px Poppins, Arial, sans-serif'
  const labelWidth = Math.min(WIDTH - 32, Math.max(150, ctx.measureText(label).width + 20))
  const labelX = Math.max(labelWidth / 2 + 12, Math.min(WIDTH - labelWidth / 2 - 12, anchor.x))
  const labelY = Math.max(24, Math.min(HEIGHT - 24, anchor.y - 18))
  if (labelX !== anchor.x || labelY !== anchor.y - 18) drawLine(ctx, anchor, { x: labelX, y: labelY + 10, depth: anchor.depth }, 'rgba(250, 204, 21, 0.9)', 1.2, [4, 3])
  ctx.fillStyle = 'rgba(15, 23, 42, 0.92)'
  ctx.beginPath()
  ctx.roundRect(labelX - labelWidth / 2, labelY - 11, labelWidth, 22, 6)
  ctx.fill()
  ctx.strokeStyle = 'rgba(250, 204, 21, 0.85)'
  ctx.lineWidth = 1
  ctx.stroke()
  ctx.fillStyle = '#fef08a'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(label, labelX, labelY + 0.5)
  ctx.restore()
}

function drawLoadGuides(ctx: CanvasRenderingContext2D, container: { width: number; height: number; depth: number }, metrics: ContainerLoadMetrics | undefined, project: (point: Point3D) => ScreenPoint) {
  if (!metrics || metrics.maxOccupiedHeight <= 0) return
  const heightPoint = project({ x: container.width, y: metrics.maxOccupiedHeight, z: container.depth })
  const heightStart = project({ x: 0, y: metrics.maxOccupiedHeight, z: container.depth })
  const center = project({ x: metrics.centerOfGravity.longitudinal, y: metrics.centerOfGravity.vertical, z: metrics.centerOfGravity.transversal })

  ctx.save()
  drawLine(ctx, heightStart, heightPoint, 'rgba(14, 165, 233, 0.95)', 1.8, [8, 5])

  ctx.beginPath()
  ctx.arc(center.x, center.y, 12, 0, Math.PI * 2)
  ctx.fillStyle = 'rgba(250, 204, 21, 0.18)'
  ctx.fill()
  ctx.strokeStyle = '#facc15'
  ctx.lineWidth = 2.2
  ctx.stroke()
  drawLine(ctx, { ...center, x: center.x - 16 }, { ...center, x: center.x + 16 }, '#facc15', 2)
  drawLine(ctx, { ...center, y: center.y - 16 }, { ...center, y: center.y + 16 }, '#facc15', 2)
  ctx.fillStyle = 'rgba(15, 23, 42, 0.9)'
  ctx.beginPath()
  ctx.roundRect(center.x + 14, center.y - 24, 32, 18, 5)
  ctx.fill()
  ctx.fillStyle = '#fef08a'
  ctx.font = '800 10px Poppins, Arial, sans-serif'
  ctx.fillText('CG', center.x + 30, center.y - 15)
  ctx.restore()
}

function getLoadDimensions(container: { width: number; height: number; depth: number }, cargo: SceneCargo[], metrics: ContainerLoadMetrics | undefined) {
  const occupiedLength = cargo.reduce((largest, item) => Math.max(largest, item.x + item.placedLength), 0)
  const occupiedWidth = cargo.reduce((largest, item) => Math.max(largest, item.z + item.placedWidth), 0)
  const cargoHeight = cargo.reduce((largest, item) => Math.max(largest, item.y + cargoGeometry(item).height), 0)
  const occupiedHeight = Math.max(metrics?.maxOccupiedHeight ?? 0, cargoHeight)
  return {
    occupiedLength,
    occupiedWidth,
    occupiedHeight,
    freeLength: Math.max(0, container.width - occupiedLength),
    freeWidth: Math.max(0, container.depth - occupiedWidth),
    freeHeight: Math.max(0, container.height - occupiedHeight),
  }
}

function rulerIntervals(total: number) {
  if (total <= 3_000) return { minor: 100, major: 500 }
  if (total <= 12_000) return { minor: 250, major: 1_000 }
  return { minor: 500, major: 2_000 }
}

function drawRulerScale(ctx: CanvasRenderingContext2D, from: ScreenPoint, to: ScreenPoint, total: number, axis: string, side = 1) {
  const distance = Math.hypot(to.x - from.x, to.y - from.y)
  if (total <= 0 || distance < 90) return
  const { minor, major } = rulerIntervals(total)
  const tickCount = Math.max(1, Math.ceil(total / minor))
  const dx = (to.x - from.x) / distance
  const dy = (to.y - from.y) / distance
  const nx = -dy * side
  const ny = dx * side
  const angle = Math.atan2(to.y - from.y, to.x - from.x)
  const labelAngle = angle > Math.PI / 2 || angle < -Math.PI / 2 ? angle + Math.PI : angle

  ctx.save()
  ctx.strokeStyle = 'rgba(30, 64, 175, 0.74)'
  ctx.fillStyle = 'rgba(30, 64, 175, 0.86)'
  ctx.lineWidth = 1.2
  ctx.font = '800 9px Poppins, Arial, sans-serif'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  for (let index = 0; index <= tickCount; index += 1) {
    const value = Math.min(total, index * minor)
    const ratio = value / total
    const point = { x: from.x + (to.x - from.x) * ratio, y: from.y + (to.y - from.y) * ratio }
    const isMajor = index === 0 || value === total || value % major < minor / 2
    const tick = isMajor ? 13 : 6
    ctx.beginPath()
    ctx.moveTo(point.x, point.y)
    ctx.lineTo(point.x + nx * tick, point.y + ny * tick)
    ctx.stroke()
    if (isMajor) {
      ctx.save()
      ctx.translate(point.x + nx * 22, point.y + ny * 22)
      ctx.rotate(labelAngle)
      ctx.fillText(`${Math.round(value).toLocaleString('es-ES')} mm`, 0, 0)
      ctx.restore()
    }
  }
  ctx.save()
  ctx.translate((from.x + to.x) / 2 + nx * 42, (from.y + to.y) / 2 + ny * 42)
  ctx.rotate(labelAngle)
  ctx.fillStyle = 'rgba(15, 23, 42, 0.78)'
  ctx.font = '900 9px Poppins, Arial, sans-serif'
  ctx.fillText(`EJE ${axis} · MARCA ${minor} mm`, 0, 0)
  ctx.restore()
  ctx.restore()
}

function drawRulerOverlay(ctx: CanvasRenderingContext2D, container: { width: number; height: number; depth: number }, project: (point: Point3D) => ScreenPoint, view: CameraView) {
  if (view === 'top') {
    drawRulerScale(ctx, project({ x: 0, y: 0, z: 0 }), project({ x: container.width, y: 0, z: 0 }), container.width, 'X / LARGO', 1)
    drawRulerScale(ctx, project({ x: 0, y: 0, z: 0 }), project({ x: 0, y: 0, z: container.depth }), container.depth, 'Z / ANCHO', -1)
  }
  if (view === 'side') {
    drawRulerScale(ctx, project({ x: 0, y: 0, z: 0 }), project({ x: 0, y: 0, z: container.depth }), container.depth, 'Z / ANCHO', 1)
    drawRulerScale(ctx, project({ x: 0, y: 0, z: container.depth }), project({ x: 0, y: container.height, z: container.depth }), container.height, 'Y / ALTURA', 1)
  }
  if (view === 'front') {
    drawRulerScale(ctx, project({ x: 0, y: 0, z: 0 }), project({ x: container.width, y: 0, z: 0 }), container.width, 'X / LARGO', 1)
    drawRulerScale(ctx, project({ x: container.width, y: 0, z: 0 }), project({ x: container.width, y: container.height, z: 0 }), container.height, 'Y / ALTURA', 1)
  }
}

function drawDimension(ctx: CanvasRenderingContext2D, from: ScreenPoint, to: ScreenPoint, label: string, offsetX: number, offsetY: number, labelId: string, labelOffsets: Record<string, DimensionLabelOffset>, labelAreas: Map<string, DimensionLabelArea>, tone = '#0e7490') {
  const start = { ...from, x: from.x + offsetX, y: from.y + offsetY }
  const end = { ...to, x: to.x + offsetX, y: to.y + offsetY }
  ctx.save()
  drawLine(ctx, from, start, 'rgba(14, 116, 144, 0.62)', 1)
  drawLine(ctx, to, end, 'rgba(14, 116, 144, 0.62)', 1)
  drawLine(ctx, start, end, tone, 1.8, [6, 4])
  const angle = Math.atan2(end.y - start.y, end.x - start.x)
  ;[start, end].forEach((point, index) => {
    const direction = index === 0 ? angle : angle + Math.PI
    ctx.beginPath()
    ctx.moveTo(point.x, point.y)
    ctx.lineTo(point.x + Math.cos(direction + 2.65) * 7, point.y + Math.sin(direction + 2.65) * 7)
    ctx.lineTo(point.x + Math.cos(direction - 2.65) * 7, point.y + Math.sin(direction - 2.65) * 7)
    ctx.closePath()
    ctx.fillStyle = tone
    ctx.fill()
  })
  const centerX = (start.x + end.x) / 2
  const centerY = (start.y + end.y) / 2
  ctx.font = '800 10px Poppins, Arial, sans-serif'
  const labelWidth = Math.max(92, ctx.measureText(label).width + 16)
  const safeInsetX = labelWidth / 2 + 12
  const safeInsetY = 24
  const savedOffset = labelOffsets[labelId] ?? { x: 0, y: 0 }
  const requestedX = centerX + savedOffset.x
  const requestedY = centerY + savedOffset.y
  const labelX = Math.max(safeInsetX, Math.min(WIDTH - safeInsetX, requestedX))
  const labelY = Math.max(safeInsetY, Math.min(HEIGHT - safeInsetY, requestedY))
  if (labelX !== centerX || labelY !== centerY) drawLine(ctx, { x: centerX, y: centerY, depth: 0 }, { x: labelX, y: labelY, depth: 0 }, 'rgba(14, 116, 144, 0.62)', 1, [3, 3])
  ctx.fillStyle = 'rgba(8, 47, 73, 0.9)'
  ctx.beginPath()
  ctx.roundRect(labelX - labelWidth / 2, labelY - 10, labelWidth, 20, 6)
  ctx.fill()
  ctx.fillStyle = '#ecfeff'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(label, labelX, labelY + 0.5)
  labelAreas.set(labelId, { x: labelX - labelWidth / 2 - 6, y: labelY - 16, width: labelWidth + 12, height: 32 })
  ctx.restore()
}

function drawDimensionOverlay(ctx: CanvasRenderingContext2D, container: { width: number; height: number; depth: number }, cargo: SceneCargo[], metrics: ContainerLoadMetrics | undefined, project: (point: Point3D) => ScreenPoint, view: CameraView, labelOffsets: Record<string, DimensionLabelOffset>, labelAreas: Map<string, DimensionLabelArea>) {
  const { occupiedLength, occupiedWidth, occupiedHeight, freeLength, freeWidth, freeHeight } = getLoadDimensions(container, cargo, metrics)
  const mm = (value: number) => `${Math.round(value).toLocaleString()} mm`

  if (view === 'top') {
    if (freeLength > 0) drawDimension(ctx, project({ x: occupiedLength, y: 0, z: container.depth }), project({ x: container.width, y: 0, z: container.depth }), `ESPACIO LIBRE · L ${mm(freeLength)}`, 0, -27, 'top-free-length', labelOffsets, labelAreas, '#059669')
    if (freeWidth > 0) drawDimension(ctx, project({ x: container.width, y: 0, z: occupiedWidth }), project({ x: container.width, y: 0, z: container.depth }), `ESPACIO LIBRE · A ${mm(freeWidth)}`, 32, 0, 'top-free-width', labelOffsets, labelAreas, '#059669')
    return
  }

  if (view === 'side') {
    if (freeWidth > 0) drawDimension(ctx, project({ x: 0, y: 0, z: occupiedWidth }), project({ x: 0, y: 0, z: container.depth }), `ESPACIO LIBRE · A ${mm(freeWidth)}`, 0, 30, 'side-free-width', labelOffsets, labelAreas, '#059669')
    if (freeHeight > 0) drawDimension(ctx, project({ x: 0, y: occupiedHeight, z: 0 }), project({ x: 0, y: container.height, z: 0 }), `ESPACIO LIBRE · H ${mm(freeHeight)}`, -34, 0, 'side-free-height', labelOffsets, labelAreas, '#059669')
    return
  }

  if (view === 'front') {
    if (freeLength > 0) drawDimension(ctx, project({ x: occupiedLength, y: 0, z: container.depth }), project({ x: container.width, y: 0, z: container.depth }), `ESPACIO LIBRE · L ${mm(freeLength)}`, 0, -27, 'front-free-length', labelOffsets, labelAreas, '#059669')
    if (freeHeight > 0) drawDimension(ctx, project({ x: 0, y: occupiedHeight, z: 0 }), project({ x: 0, y: container.height, z: 0 }), `ESPACIO LIBRE · H ${mm(freeHeight)}`, -34, 0, 'front-free-height', labelOffsets, labelAreas, '#059669')
  }
}

export function ContainerVisualization3D({ container, pallets, boxes = [], originalPallets, originalBoxes = [], loadMetrics, selectedPalletId = null, onPalletSelect, selectedBoxId = null, onBoxSelect, onCargoAdjust }: ContainerVisualization3DProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const pointer = useRef<{ active: boolean; startX: number; moved: boolean; mode: 'rotate' | 'pan' | 'label' | 'cargo'; labelId: string | null; cargoId: string | null; lastPoint: { x: number; y: number } | null; candidate: ManualCargoAdjustment | null }>({ active: false, startX: 0, moved: false, mode: 'rotate', labelId: null, cargoId: null, lastPoint: null, candidate: null })
  const sceneTransform = useRef({ scale: 1, offsetX: 0, offsetY: 0 })
  const labelAreas = useRef(new Map<string, DimensionLabelArea>())
  const [yaw, setYaw] = useState(INITIAL_YAW)
  const [dragging, setDragging] = useState(false)
  const [showAllLabels, setShowAllLabels] = useState(false)
  const [showDimensions, setShowDimensions] = useState(true)
  const [labelOffsets, setLabelOffsets] = useState<Record<string, DimensionLabelOffset>>({})
  const [zoom, setZoom] = useState(1)
  const [cameraView, setCameraView] = useState<CameraView>('isometric')
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [rotationStatus, setRotationStatus] = useState<string | null>(null)
  const [localAdjustments, setLocalAdjustments] = useState<Record<string, ManualCargoAdjustment>>({})
  const [manualPlacementMode, setManualPlacementMode] = useState(false)
  const [showOriginal, setShowOriginal] = useState(false)
  const [isOperationalPanelExpanded, setIsOperationalPanelExpanded] = useState(true)
  const displayPallets = pallets.map((pallet) => ({ ...pallet, ...(localAdjustments[pallet.id] ?? {}) }))
  const displayBoxes = boxes.map((box) => ({ ...box, ...(localAdjustments[box.id] ?? {}) }))
  const displayCargo: SceneCargo[] = [...displayPallets, ...displayBoxes]
  const originalCargo: SceneCargo[] = [...(originalPallets ?? pallets), ...originalBoxes]
  const currentSceneMetrics = sceneLoadMetrics(displayCargo, container, loadMetrics)
  const boxLegend = displayBoxes.reduce<Array<{ label: string; color: string; count: number; firstId: string }>>((legend, box) => {
    const existing = legend.find((entry) => entry.label === box.label && entry.color === box.color)
    if (existing) existing.count += 1
    else legend.push({ label: box.label, color: box.color, count: 1, firstId: box.id })
    return legend
  }, [])
  const currentLoadDimensions = getLoadDimensions({ width: container.length, height: container.height, depth: container.width }, displayCargo, currentSceneMetrics)
  const interiorVolumeM3 = (container.length * container.width * container.height) / 1_000_000_000
  const occupiedVolumeM3 = displayCargo.reduce((sum, item) => {
    const geometry = cargoGeometry(item)
    return sum + geometry.width * geometry.depth * geometry.height
  }, 0) / 1_000_000_000
  const freeVolumeM3 = Math.max(0, interiorVolumeM3 - occupiedVolumeM3)
  const formatM3 = (value: number) => `${value.toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} m³`
  const selectedCargo = (selectedBoxId ? displayBoxes.find((box) => box.id === selectedBoxId) : null) ?? (selectedPalletId ? displayPallets.find((pallet) => pallet.id === selectedPalletId) : null)
  const selectedGeometry = selectedCargo ? cargoGeometry(selectedCargo) : null
  const freeVolumePercentage = interiorVolumeM3 > 0 ? (freeVolumeM3 / interiorVolumeM3) * 100 : 0
  const gravityOffset = currentSceneMetrics ? Math.max(Math.abs(currentSceneMetrics.centerOfGravityPercentage.longitudinal - 50), Math.abs(currentSceneMetrics.centerOfGravityPercentage.transversal - 50)) : 0
  const stabilityIndicator = !currentSceneMetrics || displayCargo.length === 0
    ? { label: 'Sin carga', detail: 'Calcula una distribución', dot: 'bg-slate-400', surface: 'border-slate-200 bg-slate-50 text-slate-700' }
    : gravityOffset <= 18 && currentSceneMetrics.heightUtilizationPercentage <= 55
      ? { label: 'Estable', detail: `CG desvío ${gravityOffset.toFixed(1)}%`, dot: 'bg-emerald-500', surface: 'border-emerald-200 bg-emerald-50 text-emerald-800' }
      : gravityOffset <= 35 && currentSceneMetrics.heightUtilizationPercentage <= 75
        ? { label: 'Revisar CG', detail: `CG desvío ${gravityOffset.toFixed(1)}%`, dot: 'bg-amber-500', surface: 'border-amber-200 bg-amber-50 text-amber-800' }
        : { label: 'CG desplazado', detail: `CG desvío ${gravityOffset.toFixed(1)}%`, dot: 'bg-rose-500', surface: 'border-rose-200 bg-rose-50 text-rose-800' }
  const freeSpaceIndicator = freeVolumePercentage >= 45
    ? { label: 'Espacio amplio', detail: `${freeVolumePercentage.toFixed(0)}% libre`, dot: 'bg-emerald-500', surface: 'border-emerald-200 bg-emerald-50 text-emerald-800' }
    : freeVolumePercentage >= 15
      ? { label: 'Espacio moderado', detail: `${freeVolumePercentage.toFixed(0)}% libre`, dot: 'bg-amber-500', surface: 'border-amber-200 bg-amber-50 text-amber-800' }
      : { label: 'Espacio limitado', detail: `${freeVolumePercentage.toFixed(0)}% libre`, dot: 'bg-rose-500', surface: 'border-rose-200 bg-rose-50 text-rose-800' }

  useEffect(() => {
    if (selectedPalletId || selectedBoxId) setIsOperationalPanelExpanded(true)
  }, [selectedPalletId, selectedBoxId])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const containerBox = { x: 0, y: 0, z: 0, width: container.length, height: container.height, depth: container.width }
    const cargo = displayCargo
    const camera = cameraView === 'isometric' ? { yaw, pitch: FIXED_PITCH } : CAMERA_VIEWS[cameraView]
    const allVertices = [...vertices(containerBox), ...cargo.flatMap((item) => vertices(cargoGeometry(item)))]
    const unscaledProject = projector(camera.yaw, camera.pitch, 1, 0, 0, cameraView)
    const projected = allVertices.map(unscaledProject)
    const minX = Math.min(...projected.map((point) => point.x))
    const maxX = Math.max(...projected.map((point) => point.x))
    const minY = Math.min(...projected.map((point) => point.y))
    const maxY = Math.max(...projected.map((point) => point.y))
    const paddingX = 56
    const paddingY = 68
    const fitScale = Math.min((WIDTH - paddingX * 2) / Math.max(maxX - minX, 1), (HEIGHT - paddingY * 2) / Math.max(maxY - minY, 1))
    const scale = fitScale * zoom
    const offsetX = WIDTH / 2 - ((minX + maxX) / 2) * scale + pan.x
    const offsetY = HEIGHT / 2 - ((minY + maxY) / 2) * scale + pan.y
    const project = projector(camera.yaw, camera.pitch, scale, offsetX, offsetY, cameraView)
    sceneTransform.current = { scale, offsetX, offsetY }

    ctx.clearRect(0, 0, WIDTH, HEIGHT)
    const background = ctx.createLinearGradient(0, 0, 0, HEIGHT)
    background.addColorStop(0, '#f3f6f9')
    background.addColorStop(0.58, '#d7dee6')
    background.addColorStop(1, '#9ba6b2')
    ctx.fillStyle = background
    ctx.fillRect(0, 0, WIDTH, HEIGHT)
    const shadow = ctx.createRadialGradient(WIDTH * 0.53, HEIGHT * 0.78, 20, WIDTH * 0.53, HEIGHT * 0.78, WIDTH * 0.5)
    shadow.addColorStop(0, 'rgba(15, 23, 42, 0.17)')
    shadow.addColorStop(1, 'rgba(15, 23, 42, 0)')
    ctx.fillStyle = shadow
    ctx.fillRect(0, 0, WIDTH, HEIGHT)

    const deck = makeFaces(vertices({ x: 0, y: 0, z: 0, width: container.length, height: 30, depth: container.width }), project, '#a66a2d', 0.94)
    deck.sort((a, b) => a.depth - b.depth).forEach((face) => drawFace(ctx, face))

    const visibleFaces = [
      ...displayPallets.flatMap((pallet) => makeFaces(vertices(cargoGeometry(pallet)), project, pallet.color, 0.94)),
      ...displayBoxes.flatMap((box) => makeFaces(vertices(cargoGeometry(box)), project, box.color, 0.9)),
    ]
    visibleFaces.sort((a, b) => a.depth - b.depth).forEach((face) => drawFace(ctx, face))
    drawContainerShell(ctx, containerBox, project)
    drawLoadGuides(ctx, containerBox, currentSceneMetrics, project)
    labelAreas.current.clear()
    if (showDimensions) {
      drawRulerOverlay(ctx, containerBox, project, cameraView)
      drawDimensionOverlay(ctx, containerBox, cargo, currentSceneMetrics, project, cameraView, labelOffsets, labelAreas.current)
    }

    const labels = cargo
      .map((item) => {
        const facesToLabel = directlyVisibleLabelFaces(item, cargo, project)
        return { item, facesToLabel, depth: facesToLabel.reduce((maximum, face) => Math.max(maximum, face.depth), Number.NEGATIVE_INFINITY) }
      })
      .filter(({ facesToLabel }) => facesToLabel.length > 0)
      .sort((a, b) => a.depth - b.depth)
    if (showAllLabels && cameraView !== 'top') labels.forEach(({ item, facesToLabel }) => drawCargoLabels(ctx, item, facesToLabel, true))

    if (showOriginal) originalCargo.forEach((original) => {
      const adjusted = cargo.find((item) => item.id === original.id)
      const originalGeometry = cargoGeometry(original)
      const adjustedGeometry = adjusted ? cargoGeometry(adjusted) : null
      if (adjustedGeometry && (originalGeometry.x !== adjustedGeometry.x || originalGeometry.y !== adjustedGeometry.y || originalGeometry.z !== adjustedGeometry.z || originalGeometry.width !== adjustedGeometry.width || originalGeometry.depth !== adjustedGeometry.depth)) drawOriginalReference(ctx, original, project)
    })

    displayPallets.forEach((pallet) => {
      if (pallet.id === selectedPalletId) {
        drawSelectedOutline(ctx, pallet, project)
        if (cameraView !== 'top') drawCargoLabels(ctx, pallet, directlyVisibleLabelFaces(pallet, cargo, project), true)
        drawSelectedCargoDimensions(ctx, pallet, project)
      }
    })
    displayBoxes.forEach((box) => {
      if (box.id === selectedBoxId) {
        drawSelectedOutline(ctx, box, project)
        if (cameraView !== 'top') drawCargoLabels(ctx, box, directlyVisibleLabelFaces(box, cargo, project), true)
        drawSelectedCargoDimensions(ctx, box, project)
      }
    })
  }, [container, pallets, boxes, loadMetrics, selectedPalletId, selectedBoxId, showAllLabels, showDimensions, labelOffsets, yaw, zoom, cameraView, pan, localAdjustments, showOriginal, originalPallets, originalBoxes])

  const resetView = () => { setYaw(INITIAL_YAW); setZoom(1); setPan({ x: 0, y: 0 }); setCameraView('isometric'); setLabelOffsets({}) }
  const selectCameraView = (view: CameraView) => {
    setCameraView(view)
    setLabelOffsets({})
    setPan({ x: 0, y: 0 })
    if (view === 'isometric') setYaw(INITIAL_YAW)
  }
  const changeZoom = (amount: number) => setZoom((current) => Math.max(0.7, Math.min(2.4, Math.round((current + amount) * 10) / 10)))
  const handleWheel = (event: React.WheelEvent<HTMLCanvasElement>) => {
    event.preventDefault()
    changeZoom(event.deltaY < 0 ? 0.1 : -0.1)
  }
  const handleRotateSelected = () => {
    if (!selectedCargo) {
      setRotationStatus('Selecciona una caja o paleta para girarla.')
      return
    }
    const candidate = { ...selectedCargo, placedLength: selectedCargo.placedWidth, placedWidth: selectedCargo.placedLength }
    const otherCargo = displayCargo.filter((item) => item.id !== selectedCargo.id)
    if (!isInsideContainer(candidate, container)) {
      setRotationStatus('El giro excede los límites internos del método de envío.')
      return
    }
    if (otherCargo.some((item) => cargoOverlaps(candidate, item))) {
      setRotationStatus('El giro invadiría otra unidad de carga.')
      return
    }
    const adjustment = { x: selectedCargo.x, y: selectedCargo.y, z: selectedCargo.z, placedLength: selectedCargo.placedWidth, placedWidth: selectedCargo.placedLength }
    setLocalAdjustments((current) => ({ ...current, [selectedCargo.id]: adjustment }))
    onCargoAdjust?.(selectedCargo.id, adjustment)
    setRotationStatus(`Giro de 90° aplicado a ${selectedCargo.label}.`)
  }
  const pointFromEvent = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = event.currentTarget.getBoundingClientRect()
    return { x: ((event.clientX - rect.left) / rect.width) * WIDTH, y: ((event.clientY - rect.top) / rect.height) * HEIGHT }
  }
  const cargoAtPoint = (point: { x: number; y: number }) => {
    const activeCamera = cameraView === 'isometric' ? { yaw, pitch: FIXED_PITCH } : CAMERA_VIEWS[cameraView]
    const projectHit = projector(activeCamera.yaw, activeCamera.pitch, sceneTransform.current.scale, sceneTransform.current.offsetX, sceneTransform.current.offsetY, cameraView)
    const hits = displayCargo
      .map((item) => {
        const projected = vertices(cargoGeometry(item)).map(projectHit)
        return { item, minX: Math.min(...projected.map((vertex) => vertex.x)), maxX: Math.max(...projected.map((vertex) => vertex.x)), minY: Math.min(...projected.map((vertex) => vertex.y)), maxY: Math.max(...projected.map((vertex) => vertex.y)) }
      })
      .filter(({ minX, maxX, minY, maxY }) => point.x >= minX && point.x <= maxX && point.y >= minY && point.y <= maxY)
    return hits[hits.length - 1]?.item ?? null
  }

  const handlePointerDown = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const point = pointFromEvent(event)
    const labelHit = showDimensions ? [...labelAreas.current.entries()].find(([, area]) => point.x >= area.x && point.x <= area.x + area.width && point.y >= area.y && point.y <= area.y + area.height) : undefined
    const panRequested = event.shiftKey || event.button === 1
    const cargoHit = manualPlacementMode && cameraView === 'top' && !labelHit ? cargoAtPoint(point) : null
    const candidate = cargoHit ? { x: cargoHit.x, y: cargoHit.y, z: cargoHit.z, placedLength: cargoHit.placedLength, placedWidth: cargoHit.placedWidth } : null
    pointer.current = { active: true, startX: event.clientX, moved: false, mode: labelHit ? 'label' : cargoHit ? 'cargo' : panRequested ? 'pan' : 'rotate', labelId: labelHit?.[0] ?? null, cargoId: cargoHit?.id ?? null, lastPoint: point, candidate }
    event.currentTarget.setPointerCapture(event.pointerId)
    if (panRequested) event.preventDefault()
    setDragging(true)
  }

  const handlePointerMove = (event: React.PointerEvent<HTMLCanvasElement>) => {
    if (!pointer.current.active) return
    if (pointer.current.mode === 'label' && pointer.current.labelId && pointer.current.lastPoint) {
      const point = pointFromEvent(event)
      const deltaX = point.x - pointer.current.lastPoint.x
      const deltaY = point.y - pointer.current.lastPoint.y
      if (Math.abs(deltaX) > 0.1 || Math.abs(deltaY) > 0.1) {
        const labelId = pointer.current.labelId
        pointer.current.moved = true
        setLabelOffsets((current) => {
          const previous = current[labelId] ?? { x: 0, y: 0 }
          return { ...current, [labelId]: { x: previous.x + deltaX, y: previous.y + deltaY } }
        })
      }
      pointer.current.lastPoint = point
      return
    }
    if (pointer.current.mode === 'pan' && pointer.current.lastPoint) {
      const point = pointFromEvent(event)
      const deltaX = point.x - pointer.current.lastPoint.x
      const deltaY = point.y - pointer.current.lastPoint.y
      if (Math.abs(deltaX) > 0.1 || Math.abs(deltaY) > 0.1) {
        pointer.current.moved = true
        setPan((current) => ({ x: Math.max(-WIDTH * 0.8, Math.min(WIDTH * 0.8, current.x + deltaX)), y: Math.max(-HEIGHT * 0.8, Math.min(HEIGHT * 0.8, current.y + deltaY)) }))
      }
      pointer.current.lastPoint = point
      return
    }
    if (pointer.current.mode === 'cargo' && pointer.current.cargoId && pointer.current.lastPoint && pointer.current.candidate) {
      const point = pointFromEvent(event)
      const deltaX = (point.x - pointer.current.lastPoint.x) / Math.max(sceneTransform.current.scale, 0.01)
      const deltaZ = -(point.y - pointer.current.lastPoint.y) / Math.max(sceneTransform.current.scale, 0.01)
      const activeCargo = displayCargo.find((item) => item.id === pointer.current.cargoId)
      const previous = pointer.current.candidate
      if (activeCargo && (Math.abs(deltaX) > 0.1 || Math.abs(deltaZ) > 0.1)) {
        const next = { ...previous, x: Math.round((previous.x + deltaX) / 25) * 25, z: Math.round((previous.z + deltaZ) / 25) * 25 }
        const candidate = { ...activeCargo, ...next }
        const otherCargo = displayCargo.filter((item) => item.id !== activeCargo.id)
        if (isInsideContainer(candidate, container) && !otherCargo.some((item) => cargoOverlaps(candidate, item)) && hasPhysicalSupport(candidate, otherCargo)) {
          pointer.current.moved = true
          pointer.current.candidate = next
          setLocalAdjustments((current) => ({ ...current, [activeCargo.id]: next }))
          onCargoAdjust?.(activeCargo.id, next)
          setRotationStatus(`Posición manual aplicada a ${activeCargo.label}.`)
        }
      }
      pointer.current.lastPoint = point
      return
    }
    const delta = event.clientX - pointer.current.startX
    if (Math.abs(delta) > 3) pointer.current.moved = true
    if (cameraView !== 'top') {
      setCameraView('isometric')
      setYaw((current) => current + delta * 0.008)
    }
    pointer.current.startX = event.clientX
  }

  const handlePointerUp = (event: React.PointerEvent<HTMLCanvasElement>) => {
    if (!pointer.current.active) return
    if (!pointer.current.moved && pointer.current.mode !== 'label' && pointer.current.mode !== 'cargo') {
      const point = pointFromEvent(event)
      const activeCamera = cameraView === 'isometric' ? { yaw, pitch: FIXED_PITCH } : CAMERA_VIEWS[cameraView]
      const projectHit = projector(activeCamera.yaw, activeCamera.pitch, sceneTransform.current.scale, sceneTransform.current.offsetX, sceneTransform.current.offsetY, cameraView)
      const boxHits = displayBoxes
        .map((box) => {
          const projected = vertices(cargoGeometry(box)).map(projectHit)
          return { box, minX: Math.min(...projected.map((vertex) => vertex.x)), maxX: Math.max(...projected.map((vertex) => vertex.x)), minY: Math.min(...projected.map((vertex) => vertex.y)), maxY: Math.max(...projected.map((vertex) => vertex.y)) }
        })
        .filter(({ minX, maxX, minY, maxY }) => point.x >= minX && point.x <= maxX && point.y >= minY && point.y <= maxY)
      const boxHit = boxHits[boxHits.length - 1]?.box
      if (boxHit && onBoxSelect) {
        onPalletSelect?.(null)
        onBoxSelect(boxHit.id)
      } else if (onPalletSelect) {
        const hits = displayPallets
          .map((pallet) => {
            const projected = vertices(cargoGeometry(pallet)).map(projectHit)
            return { pallet, minX: Math.min(...projected.map((vertex) => vertex.x)), maxX: Math.max(...projected.map((vertex) => vertex.x)), minY: Math.min(...projected.map((vertex) => vertex.y)), maxY: Math.max(...projected.map((vertex) => vertex.y)) }
          })
          .filter(({ minX, maxX, minY, maxY }) => point.x >= minX && point.x <= maxX && point.y >= minY && point.y <= maxY)
        onPalletSelect(hits[hits.length - 1]?.pallet.id ?? null)
        onBoxSelect?.(null)
      }
    }
    pointer.current.active = false
    setDragging(false)
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId)
  }

  return (
    <section className="flex flex-col overflow-hidden rounded-2xl border border-slate-300 bg-white shadow-[0_18px_42px_rgba(15,23,42,0.12)]">
      <div className="order-3 flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 bg-slate-950 px-5 py-4 text-white">
        <div className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-lg border border-cyan-300/30 bg-cyan-400/10"><Truck className="h-5 w-5 text-cyan-300" /></span><div><p className="text-[10px] font-bold uppercase tracking-[0.18em] text-cyan-300">Carga interior / vista 3D</p><h2 className="font-poppins text-xl font-bold">Inspección longitudinal del contenedor</h2></div></div>
        <div className="flex flex-wrap items-center justify-end gap-2"><div className="flex rounded-lg border border-slate-600 bg-slate-800 p-1">{(Object.keys(CAMERA_VIEWS) as CameraView[]).map((view) => <button key={view} type="button" onClick={() => selectCameraView(view)} className={`rounded-md px-2 py-1.5 text-[10px] font-bold uppercase tracking-wide transition ${cameraView === view ? 'bg-cyan-300 text-slate-950' : 'text-slate-300 hover:bg-slate-700 hover:text-white'}`}>{CAMERA_VIEWS[view].label}</button>)}</div><div className="flex rounded-lg border border-slate-600 bg-slate-800 p-1"><button type="button" aria-label="Alejar vista" onClick={() => changeZoom(-0.2)} disabled={zoom <= 0.7} className="rounded-md p-1.5 text-slate-200 transition hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-40"><ZoomOut className="h-4 w-4" /></button><span className="flex min-w-11 items-center justify-center text-[10px] font-bold tabular-nums text-cyan-200">{Math.round(zoom * 100)}%</span><button type="button" aria-label="Acercar vista" onClick={() => changeZoom(0.2)} disabled={zoom >= 2.4} className="rounded-md p-1.5 text-slate-200 transition hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-40"><ZoomIn className="h-4 w-4" /></button></div><button onClick={() => setShowDimensions((current) => !current)} className={`inline-flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold transition ${showDimensions ? 'border-cyan-300 bg-cyan-300/15 text-cyan-100' : 'border-slate-600 bg-slate-800 text-slate-100 hover:border-cyan-300 hover:text-cyan-200'}`}><Ruler className="h-4 w-4" />{showDimensions ? 'Ocultar cotas' : 'Mostrar cotas'}</button><button onClick={() => setShowAllLabels((current) => !current)} className={`inline-flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold transition ${showAllLabels ? 'border-cyan-300 bg-cyan-300/15 text-cyan-100' : 'border-slate-600 bg-slate-800 text-slate-100 hover:border-cyan-300 hover:text-cyan-200'}`}>{showAllLabels ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}{showAllLabels ? 'Ocultar etiquetas' : 'Mostrar etiquetas'}</button><button onClick={resetView} className="inline-flex items-center gap-2 rounded-lg border border-slate-600 bg-slate-800 px-3 py-2 text-xs font-semibold text-slate-100 transition hover:border-cyan-300 hover:text-cyan-200"><RotateCcw className="h-4 w-4" /> Restablecer</button></div>
      </div>
      <div className="order-4 relative bg-slate-200 p-2">
        <canvas ref={canvasRef} width={WIDTH} height={HEIGHT} onPointerDown={handlePointerDown} onPointerMove={handlePointerMove} onPointerUp={handlePointerUp} onPointerCancel={handlePointerUp} onPointerLeave={handlePointerUp} onWheel={handleWheel} className={`block h-auto w-full touch-pan-y select-none ${dragging ? 'cursor-grabbing' : 'cursor-grab'}`} aria-label="Visualización 3D del contenedor; use la rueda para zoom, arrastre para girar, Mayús y arrastre o botón central para desplazarse, y seleccione una carga para ver sus dimensiones" />
        <div className={`pointer-events-none absolute left-5 top-5 inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-semibold shadow-lg ${manualPlacementMode ? 'border-cyan-200/60 bg-cyan-950/90 text-cyan-50' : 'border-slate-600/40 bg-slate-950/80 text-slate-100'}`}><MoveHorizontal className="h-4 w-4 text-cyan-300" />{manualPlacementMode ? 'Ajuste manual: arrastra la unidad seleccionada en vista superior' : `Rueda: zoom · arrastra: girar · Mayús + arrastra: mover${showDimensions ? ' · arrastra cotas' : ''}`}</div>
        {rotationStatus && <div className="pointer-events-none absolute bottom-14 left-5 max-w-[min(420px,calc(100%-2.5rem))] rounded-lg border border-amber-300/50 bg-slate-950/90 px-3 py-2 text-xs font-semibold text-amber-100 shadow-lg">{rotationStatus}</div>}
        <div className="pointer-events-none absolute bottom-5 right-5 rounded-lg border border-white/30 bg-white/80 px-3 py-2 text-[10px] font-bold uppercase tracking-[0.14em] text-slate-700 shadow-sm">{cameraView === 'top' ? 'Vista superior · uso de piso' : showAllLabels ? 'SKU de caras expuestas' : 'Etiquetas selectivas'}</div>
      </div>
      <section aria-label="Panel operativo de carga" className="order-1 border-t border-slate-200 bg-slate-100">
        <button type="button" aria-expanded={isOperationalPanelExpanded} aria-controls="panel-operativo-carga" onClick={() => setIsOperationalPanelExpanded((current) => !current)} className="flex w-full flex-col gap-3 px-4 py-3 text-left transition hover:bg-slate-200/70 focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-cyan-600 sm:flex-row sm:items-center sm:justify-between sm:px-5">
          <div className="flex min-w-0 items-center gap-2"><span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-900 text-cyan-300"><Ruler className="h-4 w-4" /></span><div className="min-w-0"><p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-500">Panel operativo</p><h3 className="truncate text-sm font-black text-slate-900">Medidas, estabilidad y acciones</h3></div></div>
          <div className="flex flex-wrap items-center gap-2"><span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.08em] ${stabilityIndicator.surface}`}><span className={`h-2 w-2 rounded-full ${stabilityIndicator.dot}`} />{stabilityIndicator.label}</span><span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.08em] ${freeSpaceIndicator.surface}`}><span className={`h-2 w-2 rounded-full ${freeSpaceIndicator.dot}`} />{freeSpaceIndicator.label}</span><span className="ml-auto inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-300 bg-white text-slate-700">{isOperationalPanelExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}</span></div>
        </button>
        {isOperationalPanelExpanded && <div id="panel-operativo-carga" className="border-t border-slate-200 px-4 pb-3 pt-3 sm:px-5">
          <div className="mb-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            <div className={`rounded-xl border px-3 py-2 shadow-sm ${stabilityIndicator.surface}`}><div className="flex items-center gap-2"><span className={`h-2.5 w-2.5 rounded-full ${stabilityIndicator.dot}`} /><p className="text-[10px] font-black uppercase tracking-[0.1em]">Estabilidad / CG</p></div><p className="mt-1 text-sm font-black">{stabilityIndicator.label}</p><p className="text-[10px] font-semibold opacity-80">{stabilityIndicator.detail} · H {currentSceneMetrics?.heightUtilizationPercentage.toFixed(1) ?? '0.0'}%</p></div>
            <div className={`rounded-xl border px-3 py-2 shadow-sm ${freeSpaceIndicator.surface}`}><div className="flex items-center gap-2"><span className={`h-2.5 w-2.5 rounded-full ${freeSpaceIndicator.dot}`} /><p className="text-[10px] font-black uppercase tracking-[0.1em]">Espacio libre</p></div><p className="mt-1 text-sm font-black">{freeSpaceIndicator.label}</p><p className="text-[10px] font-semibold opacity-80">{freeSpaceIndicator.detail} · {formatM3(freeVolumeM3)}</p></div>
            <div className="rounded-xl border border-slate-300 bg-white px-3 py-2 shadow-sm"><p className="text-[10px] font-black uppercase tracking-[0.1em] text-slate-500">Interior · L × A × H</p><p className="mt-1 font-mono text-xs font-black tabular-nums text-slate-900">{container.length.toLocaleString()} × {container.width.toLocaleString()} × {container.height.toLocaleString()} mm</p></div>
            <div className="rounded-xl border border-slate-300 bg-white px-3 py-2 shadow-sm"><p className="text-[10px] font-black uppercase tracking-[0.1em] text-slate-500">Ocupado / libre</p><p className="mt-1 font-mono text-xs font-black tabular-nums text-slate-900">{Math.round(currentLoadDimensions.occupiedLength).toLocaleString()} × {Math.round(currentLoadDimensions.occupiedWidth).toLocaleString()} × {Math.round(currentLoadDimensions.occupiedHeight).toLocaleString()}</p><p className="mt-0.5 font-mono text-[10px] font-semibold text-emerald-700">Libre {Math.round(currentLoadDimensions.freeLength).toLocaleString()} × {Math.round(currentLoadDimensions.freeWidth).toLocaleString()} × {Math.round(currentLoadDimensions.freeHeight).toLocaleString()} mm</p></div>
          </div>
          <div className="grid grid-cols-2 gap-2 xl:grid-cols-[1fr_1fr_1fr]">
            <div className="rounded-xl border border-sky-200 bg-sky-50 px-3 py-2.5 shadow-sm"><p className="text-[9px] font-black uppercase tracking-[0.12em] text-sky-800">Altura de carga</p><p className="mt-1 font-mono text-sm font-black tabular-nums text-sky-950">{currentSceneMetrics ? `${Math.round(currentSceneMetrics.maxOccupiedHeight).toLocaleString()} mm` : '0 mm'} <span className="text-[10px] font-semibold text-sky-700">· Uso {currentSceneMetrics ? `${currentSceneMetrics.heightUtilizationPercentage.toFixed(1)}%` : '0.0%'}</span></p></div>
            <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2.5 shadow-sm"><p className="text-[9px] font-black uppercase tracking-[0.12em] text-amber-800">Centro de gravedad · X / Z / Y</p><p className="mt-1 font-mono text-xs font-black tabular-nums text-amber-950">{currentSceneMetrics ? `${Math.round(currentSceneMetrics.centerOfGravity.longitudinal).toLocaleString()} / ${Math.round(currentSceneMetrics.centerOfGravity.transversal).toLocaleString()} / ${Math.round(currentSceneMetrics.centerOfGravity.vertical).toLocaleString()} mm` : 'Pendiente de carga'}</p></div>
            <div className="col-span-2 rounded-xl border border-emerald-300 bg-white px-3 py-2.5 shadow-sm xl:col-span-1"><p className="text-[9px] font-black uppercase tracking-[0.12em] text-emerald-800">Volumen libre / ocupado</p><p className="mt-1 font-mono text-sm font-black tabular-nums text-emerald-950">{formatM3(freeVolumeM3)} <span className="text-[10px] font-semibold text-emerald-700">· ocupado {formatM3(occupiedVolumeM3)}</span></p></div>
          </div>
          {selectedCargo && selectedGeometry && <div className="mt-3 border-t border-slate-200 pt-3"><div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between"><div className="flex min-w-0 items-center gap-3"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-amber-300 bg-amber-100 text-amber-800 shadow-sm"><RotateCw className="h-5 w-5" /></span><div className="min-w-0"><p className="text-[10px] font-black uppercase tracking-[0.14em] text-amber-800">Acciones de unidad seleccionada</p><p className="truncate font-mono text-sm font-bold text-slate-900">{selectedCargo.label} <span className="font-medium text-slate-500">· {Math.round(selectedGeometry.width).toLocaleString()} × {Math.round(selectedGeometry.depth).toLocaleString()} × {Math.round(selectedGeometry.height).toLocaleString()} mm</span></p></div></div><div className="grid grid-cols-1 gap-2 sm:grid-cols-3 xl:min-w-[610px]"><button type="button" onClick={handleRotateSelected} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-lg border border-amber-500 bg-amber-400 px-4 py-2 text-xs font-black uppercase tracking-[0.1em] text-amber-950 shadow-[0_5px_0_rgb(180,83,9)] transition hover:bg-amber-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-600 active:translate-y-[2px] active:shadow-[0_3px_0_rgb(180,83,9)]"><RotateCw className="h-4 w-4" />Girar 90°</button><button type="button" onClick={() => { setManualPlacementMode((current) => !current); setCameraView('top'); setPan({ x: 0, y: 0 }) }} className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-lg border px-4 py-2 text-xs font-black uppercase tracking-[0.1em] shadow-sm transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-600 ${manualPlacementMode ? 'border-cyan-500 bg-cyan-600 text-white shadow-cyan-900/20 hover:bg-cyan-500' : 'border-cyan-200 bg-white text-cyan-800 hover:border-cyan-400 hover:bg-cyan-50'}`}><Hand className="h-4 w-4" />{manualPlacementMode ? 'Mover activo' : 'Mover en planta'}</button><button type="button" onClick={() => setShowOriginal((current) => !current)} className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-lg border px-4 py-2 text-xs font-black uppercase tracking-[0.1em] shadow-sm transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-600 ${showOriginal ? 'border-violet-500 bg-violet-600 text-white shadow-violet-900/20 hover:bg-violet-500' : 'border-violet-200 bg-white text-violet-800 hover:border-violet-400 hover:bg-violet-50'}`}><GitCompare className="h-4 w-4" />{showOriginal ? 'Ocultar original' : 'Comparar origen'}</button></div></div></div>}
        </div>}
      </section>
      <div className="order-5 flex max-h-32 flex-wrap gap-2 overflow-y-auto border-t border-slate-100 px-5 py-3">{pallets.map((pallet) => <button key={pallet.id} type="button" onClick={() => onPalletSelect?.(pallet.id)} className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold transition ${selectedPalletId === pallet.id ? 'border-cyan-600 bg-cyan-50 text-cyan-900' : 'border-slate-200 bg-white text-slate-600 hover:border-cyan-300'}`}><span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: pallet.color }} />{pallet.label}</button>)}{boxLegend.map((entry) => <button key={`${entry.label}-${entry.color}`} type="button" onClick={() => onBoxSelect?.(entry.firstId)} className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:border-cyan-300 hover:text-cyan-800"><span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: entry.color }} />{entry.label}<span className="rounded-full bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-500">×{entry.count}</span></button>)}</div>
    </section>
  )
}
