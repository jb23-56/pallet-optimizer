// Estilo: Modernismo Industrial Funcional; interfaz logística de lectura rápida, controles directos y visualización 3D explicativa.
/* Estilo: Plano de Carga Guiado; destino final y paleta a medida convierten medidas de producto en decisiones de envío. */
import { useEffect, useMemo, useState } from 'react'
import { AlertTriangle, ArrowRight, BarChart3, Box, ChevronDown, CircleCheck, FileDown, FileSpreadsheet, Layers3, List as ListIcon, Package, Plus, Ruler, Star, Trash2, Truck } from 'lucide-react'
import {
  calculateMixedBoxArrangement,
  calculatePalletArrangement,
  calculatePalletsNeeded,
  recommendMixedPalletDimensions,
  recommendOptimizedPalletDimensions,
  recommendPalletDimensions,
  type BoxDimensions,
  type BoxHandlingOptions,
  type CalculationResult,
  type MixedBoxItem,
  type MixedBoxPlacement,
  type MixedBoxResult,
  type PalletDimensions,
  type PalletOptimizationRecommendation,
} from './lib/palletCalculator'
import { calculateContainerLoad, calculateLooseContainerLoad, type ContainerLoadMetrics, type ContainerLoadResult, type ContainerLooseBoxInput, type ContainerPalletInput, type ContainerSpec, type LooseContainerLoadResult } from './lib/containerCalculator'
import { PalletVisualization3D, type Box3D } from './components/PalletVisualization3D'
import { ContainerVisualization3D, type ManualCargoAdjustment } from './components/ContainerVisualization3D'
import { ProductListPanel } from './components/ProductListPanel'
import { downloadProductTemplate, parseProductFile, productItemsToMixedBoxes, type ProductImportResult, type ProductListItem } from './lib/productList'
import { downloadLogisticsPdf } from './lib/logisticsPdf'
import { downloadLogisticsExcel } from './lib/logisticsExcel'
import { downloadBasicLogisticsExcel, downloadBasicLogisticsPdf, type BasicLogisticsReportInput, type ManualLoadAdjustmentReportRow } from './lib/basicLogisticsReport'

const BOX_COLORS = ['#2563eb', '#0891b2', '#059669', '#d97706', '#dc2626', '#7c3aed', '#db2777', '#475569']
const CONTAINER_SPECS: ContainerSpec[] = [
  { id: '20-dry', name: 'Contenedor marítimo 20 ft', length: 5898, width: 2352, height: 2393, maxWeight: 28000, note: 'Medidas internas de referencia; confirmar con el transportista.' },
  { id: '40-dry', name: 'Contenedor marítimo 40 ft', length: 12032, width: 2352, height: 2393, maxWeight: 28000, note: 'Medidas internas de referencia; confirmar con el transportista.' },
  { id: '40-high-cube', name: 'Contenedor 40 ft High Cube', length: 12032, width: 2352, height: 2698, maxWeight: 28000, note: 'Mayor altura interior; confirmar tara y peso útil con el transportista.' },
  { id: 'trailer', name: 'Semirremolque estándar', length: 13600, width: 2450, height: 2600, maxWeight: 24000, note: 'Referencia de caja útil para transporte terrestre.' },
  { id: 'rigid-truck', name: 'Camión rígido caja 7 m', length: 7000, width: 2300, height: 2400, maxWeight: 7000, note: 'Medidas interiores de referencia para reparto; confirmar con el transportista.' },
  { id: 'cargo-van', name: 'Furgón de carga', length: 4300, width: 1780, height: 1900, maxWeight: 1200, note: 'Medidas interiores de referencia; validar pasos de rueda y carga útil.' },
]

type ShippingProfile = {
  id: string
  label: string
  maxTotalHeight: number
  maxLength: number
  maxWidth: number
  maxWeight: number
  note: string
  containerSpecId?: string
  isFavorite?: boolean
  isCustom?: boolean
}

const DEFAULT_FINAL_TRANSPORT_PROFILES: ShippingProfile[] = [
  { id: 'container', label: 'Contenedor marítimo 40 ft', maxTotalHeight: 2393, maxLength: 12032, maxWidth: 2352, maxWeight: 28000, note: 'Caja seca estándar de referencia para transporte marítimo.', containerSpecId: '40-dry' },
  { id: 'container-20', label: 'Contenedor marítimo 20 ft', maxTotalHeight: 2393, maxLength: 5898, maxWidth: 2352, maxWeight: 28000, note: 'Caja seca corta de referencia para transporte marítimo.', containerSpecId: '20-dry' },
  { id: 'container-high-cube', label: 'Contenedor 40 ft High Cube', maxTotalHeight: 2698, maxLength: 12032, maxWidth: 2352, maxWeight: 28000, note: 'Mayor altura interior para cargas voluminosas; confirma el peso útil de la naviera.', containerSpecId: '40-high-cube' },
  { id: 'truck', label: 'Semirremolque estándar', maxTotalHeight: 2600, maxLength: 13600, maxWidth: 2450, maxWeight: 24000, note: 'Caja útil de referencia para transporte terrestre de larga distancia.', containerSpecId: 'trailer' },
  { id: 'rigid-truck', label: 'Camión rígido caja 7 m', maxTotalHeight: 2400, maxLength: 7000, maxWidth: 2300, maxWeight: 7000, note: 'Referencia para camión rígido de reparto; confirma dimensiones interiores reales.', containerSpecId: 'rigid-truck' },
  { id: 'cargo-van', label: 'Furgón de carga', maxTotalHeight: 1900, maxLength: 4300, maxWidth: 1780, maxWeight: 1200, note: 'Referencia para furgón de carga; valida la carga útil y pasos de rueda.', containerSpecId: 'cargo-van' },
]

type FinalTransportId = string
type PersistedManualCargoAdjustment = ManualCargoAdjustment & {
  source: 'container' | 'loose'
  planIndex: number
  cargoId: string
}
const MANEUVERABLE_PALLET_MAX_SIDE = 1700
const LOCAL_WORKSPACE_KEY = 'palletoptimizer.workspace.v1'

type LocalWorkspace = {
  activeTab: 'products' | 'simple' | 'mixed' | 'containers' | 'compare'
  simpleBoxName: string
  boxLength: number
  boxWidth: number
  boxHeight: number
  boxWeight: number
  totalBoxes: number
  simpleHandling: BoxHandlingOptions
  palletLength: number
  palletWidth: number
  palletHeight: number
  palletBaseHeight: number
  maxWeight: number
  finalTransport: FinalTransportId
  customShippingProfiles: ShippingProfile[]
  allowOversizePallets: boolean
  mixedBoxes: MixedBoxItem[]
  productItems: ProductListItem[]
  containerSource: 'mixed' | 'simple' | 'list'
  containerSpecId: string
}

function readLocalWorkspace(): Partial<LocalWorkspace> {
  try {
    const saved = window.localStorage.getItem(LOCAL_WORKSPACE_KEY)
    if (!saved) return {}
    const parsed: unknown = JSON.parse(saved)
    return parsed && typeof parsed === 'object' ? parsed as Partial<LocalWorkspace> : {}
  } catch {
    return {}
  }
}

function numberValue(value: string, fallback = 0) {
  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : fallback
}

export default function App() {
  const [storedWorkspace] = useState(readLocalWorkspace)
  const [activeTab, setActiveTab] = useState<'products' | 'simple' | 'mixed' | 'containers' | 'compare'>(storedWorkspace.activeTab ?? 'products')

  const [simpleBoxName, setSimpleBoxName] = useState(storedWorkspace.simpleBoxName ?? 'Caja A')
  const [boxLength, setBoxLength] = useState(storedWorkspace.boxLength ?? 600)
  const [boxWidth, setBoxWidth] = useState(storedWorkspace.boxWidth ?? 400)
  const [boxHeight, setBoxHeight] = useState(storedWorkspace.boxHeight ?? 300)
  const [boxWeight, setBoxWeight] = useState(storedWorkspace.boxWeight ?? 15)
  const [totalBoxes, setTotalBoxes] = useState(storedWorkspace.totalBoxes ?? 100)
  const [simpleHandling, setSimpleHandling] = useState<BoxHandlingOptions>(storedWorkspace.simpleHandling ?? { canStack: true, allowHorizontalRotation: true, allowVerticalRotation: false })

  const [palletLength, setPalletLength] = useState(storedWorkspace.palletLength ?? 1200)
  const [palletWidth, setPalletWidth] = useState(storedWorkspace.palletWidth ?? 800)
  const [palletHeight, setPalletHeight] = useState(storedWorkspace.palletHeight ?? 1500)
  const [palletBaseHeight, setPalletBaseHeight] = useState(storedWorkspace.palletBaseHeight ?? 150)
  const [maxWeight, setMaxWeight] = useState(storedWorkspace.maxWeight ?? 1000)
  const [finalTransport, setFinalTransport] = useState<FinalTransportId>(storedWorkspace.finalTransport ?? 'container')
  const [customShippingProfiles, setCustomShippingProfiles] = useState<ShippingProfile[]>(storedWorkspace.customShippingProfiles ?? [])
  const [allowOversizePallets, setAllowOversizePallets] = useState(storedWorkspace.allowOversizePallets ?? false)

  const [simpleResult, setSimpleResult] = useState<(CalculationResult & { palletsNeeded: number; totalBoxesNeeded: number }) | { error: true; recommendations: PalletDimensions[] } | null>(null)
  const [selectedSimpleBoxId, setSelectedSimpleBoxId] = useState<string | null>(null)
  const [mixedBoxes, setMixedBoxes] = useState<MixedBoxItem[]>(storedWorkspace.mixedBoxes ?? [
    { id: '1', name: 'SKU-A · Caja grande', boxDimensions: { length: 600, width: 400, height: 300, weight: 15 }, quantity: 20, canStack: true, allowHorizontalRotation: true, allowVerticalRotation: false },
    { id: '2', name: 'SKU-B · Caja pequeña', boxDimensions: { length: 400, width: 300, height: 250, weight: 8 }, quantity: 20, canStack: true, allowHorizontalRotation: true, allowVerticalRotation: false },
  ])
  const [mixedResult, setMixedResult] = useState<MixedBoxResult | null>(null)
  const [productItems, setProductItems] = useState<ProductListItem[]>(storedWorkspace.productItems ?? [])
  const [productImportResult, setProductImportResult] = useState<ProductImportResult | null>(null)
  const [selectedMixedPallet, setSelectedMixedPallet] = useState(0)
  const [selectedBoxPlacementId, setSelectedBoxPlacementId] = useState<string | null>(null)
  const [containerSource, setContainerSource] = useState<'mixed' | 'simple' | 'list'>(storedWorkspace.containerSource ?? 'mixed')
  const [containerSpecId, setContainerSpecId] = useState(storedWorkspace.containerSpecId ?? '40-dry')
  const [containerResult, setContainerResult] = useState<ContainerLoadResult | null>(null)
  const [looseContainerResult, setLooseContainerResult] = useState<LooseContainerLoadResult | null>(null)
  const [lastReportSource, setLastReportSource] = useState<'mixed' | 'simple' | 'container' | 'loose' | null>(null)
  const [selectedContainerPlan, setSelectedContainerPlan] = useState(0)
  const [selectedContainerPalletId, setSelectedContainerPalletId] = useState<string | null>(null)
  const [selectedContainerBoxId, setSelectedContainerBoxId] = useState<string | null>(null)
  const [manualCargoAdjustments, setManualCargoAdjustments] = useState<Record<string, PersistedManualCargoAdjustment>>({})

  const favoriteShippingProfiles = useMemo(() => customShippingProfiles.filter((profile) => profile.isFavorite), [customShippingProfiles])
  const otherShippingProfiles = useMemo(() => [...DEFAULT_FINAL_TRANSPORT_PROFILES, ...customShippingProfiles.filter((profile) => !profile.isFavorite)], [customShippingProfiles])
  const shippingProfiles = useMemo(() => [...favoriteShippingProfiles, ...otherShippingProfiles], [favoriteShippingProfiles, otherShippingProfiles])
  const shippingContainerSpecs = useMemo<ContainerSpec[]>(() => customShippingProfiles.map((profile) => ({ id: `profile-${profile.id}`, name: profile.label, length: profile.maxLength, width: profile.maxWidth, height: profile.maxTotalHeight, maxWeight: profile.maxWeight, note: profile.note })), [customShippingProfiles])
  const allContainerSpecs = useMemo(() => {
    const favoriteIds = new Set(favoriteShippingProfiles.map((profile) => `profile-${profile.id}`))
    const favorites = shippingContainerSpecs.filter((spec) => favoriteIds.has(spec.id))
    const others = [...CONTAINER_SPECS, ...shippingContainerSpecs.filter((spec) => !favoriteIds.has(spec.id))]
    return [...favorites, ...others]
  }, [favoriteShippingProfiles, shippingContainerSpecs])
  const destinationProfile = shippingProfiles.find((profile) => profile.id === finalTransport) ?? DEFAULT_FINAL_TRANSPORT_PROFILES[0]
  const effectivePalletHeight = Math.min(palletHeight, destinationProfile.maxTotalHeight)
  const pallet: PalletDimensions = { length: palletLength, width: palletWidth, height: effectivePalletHeight, baseHeight: palletBaseHeight, maxWeight }
  const selectedContainer = allContainerSpecs.find((container) => container.id === containerSpecId) ?? allContainerSpecs[0]
  const simplePalletRecommendations = useMemo(() => recommendOptimizedPalletDimensions(
    { length: boxLength, width: boxWidth, height: boxHeight, weight: boxWeight },
    simpleHandling,
    { maxTotalHeight: destinationProfile.maxTotalHeight, baseHeight: palletBaseHeight, maxWeight, maxLength: destinationProfile.maxLength, maxWidth: destinationProfile.maxWidth, preferredMaxSide: MANEUVERABLE_PALLET_MAX_SIDE, allowOversize: allowOversizePallets },
  ), [boxLength, boxWidth, boxHeight, boxWeight, simpleHandling, destinationProfile, palletBaseHeight, maxWeight, allowOversizePallets])
  const mixedPalletRecommendations = useMemo(() => recommendMixedPalletDimensions(
    mixedBoxes,
    { maxTotalHeight: destinationProfile.maxTotalHeight, baseHeight: palletBaseHeight, maxWeight, maxLength: destinationProfile.maxLength, maxWidth: destinationProfile.maxWidth, preferredMaxSide: MANEUVERABLE_PALLET_MAX_SIDE, allowOversize: allowOversizePallets },
  ), [mixedBoxes, destinationProfile, palletBaseHeight, maxWeight, allowOversizePallets])
  const productListResult = productItems.length > 0 ? calculateMixedBoxArrangement(productItemsToMixedBoxes(productItems), pallet) : null
  const productListTotalBoxes = productItems.reduce((sum, item) => sum + item.quantity, 0)
  const productListTotalWeight = productItems.reduce((sum, item) => sum + item.boxDimensions.weight * item.quantity, 0)
  const productListLabel = productImportResult?.sourceName || 'Lista de productos actual'
  const activeMixedPallet = mixedResult?.pallets[Math.min(selectedMixedPallet, Math.max(mixedResult.pallets.length - 1, 0))]
  const activeContainerPlan = containerResult?.plans[Math.min(selectedContainerPlan, Math.max(containerResult.plans.length - 1, 0))]
  const activeLooseContainerPlan = looseContainerResult?.plans[Math.min(selectedContainerPlan, Math.max(looseContainerResult.plans.length - 1, 0))]
  const manualAdjustmentKey = (source: 'container' | 'loose', planIndex: number, cargoId: string) => `${source}:${planIndex}:${cargoId}`
  const adjustedContainerPallets = activeContainerPlan?.pallets.map((pallet) => ({ ...pallet, ...(manualCargoAdjustments[manualAdjustmentKey('container', selectedContainerPlan, pallet.id)] ?? {}) })) ?? []
  const adjustedLooseBoxes = activeLooseContainerPlan?.boxes.map((box) => ({ ...box, ...(manualCargoAdjustments[manualAdjustmentKey('loose', selectedContainerPlan, box.id)] ?? {}) })) ?? []
  const selectedLoadMetrics = activeContainerPlan?.loadMetrics ?? activeLooseContainerPlan?.loadMetrics
  const simpleCalculation = simpleResult && !('error' in simpleResult) ? simpleResult : null
  const hasDetailedMixedReport = Boolean(mixedResult && mixedResult.pallets.length > 0)
  const reportAvailable = (lastReportSource === 'mixed' && hasDetailedMixedReport) || (lastReportSource === 'simple' && Boolean(simpleCalculation)) || (lastReportSource === 'container' && Boolean(containerResult?.plans.length)) || (lastReportSource === 'loose' && Boolean(looseContainerResult?.plans.length))
  const reportScope = lastReportSource === 'container' ? 'Carga paletizada' : lastReportSource === 'loose' ? 'Carga suelta' : lastReportSource === 'mixed' ? 'Mezcla de cajas' : 'Paleta simple'
  const containerVolumeSummary = useMemo(() => {
    const result = containerResult ?? looseContainerResult
    if (!result) return null
    const volumePerUnitM3 = (result.container.length * result.container.width * result.container.height) / 1_000_000_000
    const usedM3 = result.plans.reduce((sum, plan) => sum + volumePerUnitM3 * (plan.volumeUtilizationPercentage / 100), 0)
    return { usedM3, freeM3: Math.max(0, volumePerUnitM3 * result.plans.length - usedM3) }
  }, [containerResult, looseContainerResult])
  const formatVolumeM3 = (value: number) => `${value.toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} m³`
  const manualAdjustmentRows = useMemo<ManualLoadAdjustmentReportRow[]>(() => Object.values(manualCargoAdjustments).flatMap((adjustment) => {
    const plan = adjustment.source === 'container' ? containerResult?.plans[adjustment.planIndex] : looseContainerResult?.plans[adjustment.planIndex]
    const original = plan && ('pallets' in plan ? plan.pallets.find((item) => item.id === adjustment.cargoId) : plan.boxes.find((item) => item.id === adjustment.cargoId))
    if (!original) return []
    return [{
      containerIndex: adjustment.planIndex,
      kind: adjustment.source === 'container' ? 'Paleta' : 'Caja',
      label: original.label,
      cargoId: adjustment.cargoId,
      original: { x: original.x, y: original.y, z: original.z, length: original.placedLength, width: original.placedWidth },
      adjusted: { x: adjustment.x, y: adjustment.y, z: adjustment.z, length: adjustment.placedLength, width: adjustment.placedWidth },
    }]
  }), [manualCargoAdjustments, containerResult, looseContainerResult])

  useEffect(() => {
    const workspace: LocalWorkspace = {
      activeTab,
      simpleBoxName,
      boxLength,
      boxWidth,
      boxHeight,
      boxWeight,
      totalBoxes,
      simpleHandling,
      palletLength,
      palletWidth,
      palletHeight,
      palletBaseHeight,
      maxWeight,
      finalTransport,
      customShippingProfiles,
      allowOversizePallets,
      mixedBoxes,
      productItems,
      containerSource,
      containerSpecId,
    }
    window.localStorage.setItem(LOCAL_WORKSPACE_KEY, JSON.stringify(workspace))
  }, [activeTab, simpleBoxName, boxLength, boxWidth, boxHeight, boxWeight, totalBoxes, simpleHandling, palletLength, palletWidth, palletHeight, palletBaseHeight, maxWeight, finalTransport, customShippingProfiles, allowOversizePallets, mixedBoxes, productItems, containerSource, containerSpecId])

  const generateSimpleBoxes3D = (result: CalculationResult): Box3D[] => {
    const boxes: Box3D[] = []
    const oriented = result.orientation.dimensions
    const maxRenderedBoxes = Math.min(result.totalBoxes, 260)

    for (let index = 0; index < maxRenderedBoxes; index += 1) {
      const perLevel = result.arrangement.boxesAlongLength * result.arrangement.boxesAlongWidth
      const level = Math.floor(index / perLevel)
      const indexInLevel = index % perLevel
      const row = Math.floor(indexInLevel / result.arrangement.boxesAlongLength)
      const column = indexInLevel % result.arrangement.boxesAlongLength
      boxes.push({
        id: `simple-${index}`,
        x: column * oriented.length,
        y: palletBaseHeight + level * oriented.height,
        z: row * oriented.width,
        width: oriented.length,
        height: oriented.height,
        depth: oriented.width,
        color: '#2563eb',
        label: simpleBoxName || 'Caja simple',
      })
    }
    return boxes
  }

  const generateMixedBoxes3D = (placements: MixedBoxPlacement[]): Box3D[] => placements.slice(0, 320).map((placement, index) => ({
    id: placement.placementId,
    x: placement.x,
    y: placement.y,
    z: placement.z,
    width: placement.width,
    height: placement.height,
    depth: placement.depth,
    color: BOX_COLORS[Math.max(0, mixedBoxes.findIndex((item) => item.id === placement.boxId)) % BOX_COLORS.length],
    label: placement.boxName || `Caja ${index + 1}`,
  }))

  const handleCalculateSimple = () => {
    const box: BoxDimensions = { length: boxLength, width: boxWidth, height: boxHeight, weight: boxWeight }
    const result = calculatePalletArrangement(box, pallet, simpleHandling)
    if (result) {
      setSelectedSimpleBoxId(null)
      setSimpleResult({ ...result, palletsNeeded: calculatePalletsNeeded(totalBoxes, result.totalBoxes), totalBoxesNeeded: totalBoxes })
      setLastReportSource('simple')
    } else {
      setSelectedSimpleBoxId(null)
      setSimpleResult({ error: true, recommendations: recommendPalletDimensions(box) })
    }
  }

  const handleFinalTransportChange = (nextTransport: FinalTransportId) => {
    const nextProfile = shippingProfiles.find((profile) => profile.id === nextTransport) ?? DEFAULT_FINAL_TRANSPORT_PROFILES[0]
    setFinalTransport(nextProfile.id)
    setPalletHeight(nextProfile.maxTotalHeight)
    setContainerSpecId(nextProfile.containerSpecId ?? `profile-${nextProfile.id}`)
    setSimpleResult(null)
    setMixedResult(null)
    setContainerResult(null)
    setLooseContainerResult(null)
  }

  const handleContainerSpecChange = (nextContainerSpecId: string) => {
    const matchingProfile = shippingProfiles.find((profile) => (profile.containerSpecId ?? `profile-${profile.id}`) === nextContainerSpecId)
    if (matchingProfile) {
      handleFinalTransportChange(matchingProfile.id)
      return
    }
    setContainerSpecId(nextContainerSpecId)
    setContainerResult(null)
    setLooseContainerResult(null)
  }

  const handleAddShippingProfile = () => {
    const id = `custom-${Date.now()}`
    const profile: ShippingProfile = { id, label: 'Nuevo tipo de envío', maxTotalHeight: 2400, maxLength: 7000, maxWidth: 2300, maxWeight: 12000, note: 'Perfil personalizado; valida las medidas útiles con el transportista.', isCustom: true }
    setCustomShippingProfiles((current) => [...current, profile])
    setFinalTransport(id)
    setContainerSpecId(`profile-${id}`)
    setSimpleResult(null)
    setMixedResult(null)
    setContainerResult(null)
    setLooseContainerResult(null)
  }

  const handleUpdateShippingProfile = (id: string, updates: Partial<ShippingProfile>) => {
    setCustomShippingProfiles((current) => current.map((profile) => profile.id === id ? { ...profile, ...updates } : profile))
    if (finalTransport === id && updates.maxTotalHeight !== undefined) setPalletHeight((current) => Math.min(current, updates.maxTotalHeight ?? current))
    setSimpleResult(null)
    setMixedResult(null)
    setContainerResult(null)
    setLooseContainerResult(null)
  }

  const handleToggleShippingFavorite = (id: string) => {
    setCustomShippingProfiles((current) => current.map((profile) => profile.id === id ? { ...profile, isFavorite: !profile.isFavorite } : profile))
  }

  const handleRemoveShippingProfile = (id: string) => {
    setCustomShippingProfiles((current) => current.filter((profile) => profile.id !== id))
    if (finalTransport === id) handleFinalTransportChange('container')
    if (containerSpecId === `profile-${id}`) setContainerSpecId('40-dry')
    setContainerResult(null)
    setLooseContainerResult(null)
  }

  const handleApplyPalletRecommendation = (recommendation: PalletOptimizationRecommendation) => {
    setPalletLength(recommendation.length)
    setPalletWidth(recommendation.width)
    setPalletHeight(recommendation.totalHeight)
    setPalletBaseHeight(recommendation.baseHeight)
    setMaxWeight(recommendation.maxWeight)
    setSimpleResult(null)
    setMixedResult(null)
  }

  const handleImportProducts = async (file: File) => {
    const parsed = await parseProductFile(file)
    setProductImportResult(parsed)
    if (parsed.errors.length === 0 && parsed.items.length > 0) {
      setProductItems(parsed.items)
    }
  }

  const handleClearProductList = () => {
    setProductItems([])
    setProductImportResult(null)
    if (containerSource === 'list') setLooseContainerResult(null)
  }

  const handleApplyProductList = () => {
    const nextMixedBoxes = productItemsToMixedBoxes(productItems)
    if (nextMixedBoxes.length === 0) return
    setMixedBoxes(nextMixedBoxes)
    setMixedResult(null)
    setSelectedMixedPallet(0)
    setSelectedBoxPlacementId(null)
    setActiveTab('mixed')
  }

  const handleApplyProductToSimple = (item: ProductListItem) => {
    setSimpleBoxName(item.name)
    setBoxLength(item.boxDimensions.length)
    setBoxWidth(item.boxDimensions.width)
    setBoxHeight(item.boxDimensions.height)
    setBoxWeight(item.boxDimensions.weight)
    setTotalBoxes(item.quantity)
    setSimpleHandling({
      canStack: item.canStack,
      allowHorizontalRotation: item.allowHorizontalRotation,
      allowVerticalRotation: item.allowVerticalRotation,
    })
    setSimpleResult(null)
    setSelectedSimpleBoxId(null)
    setActiveTab('simple')
  }

  const getLooseContainerInputs = (): ContainerLooseBoxInput[] => productItems.flatMap((item, itemIndex) => Array.from({ length: Math.max(0, Math.floor(item.quantity)) }, (_, quantityIndex) => ({
    id: `loose-${item.id}-${quantityIndex + 1}`,
    label: item.name || `SKU ${itemIndex + 1}`,
    length: item.boxDimensions.length,
    width: item.boxDimensions.width,
    height: item.boxDimensions.height,
    weight: item.boxDimensions.weight,
    color: BOX_COLORS[itemIndex % BOX_COLORS.length],
    sourceIndex: itemIndex,
    canStack: item.canStack,
  })))

  const handleApplyListToContainers = () => {
    const nextMixedBoxes = productItemsToMixedBoxes(productItems)
    const looseBoxes = getLooseContainerInputs()
    if (nextMixedBoxes.length === 0 || looseBoxes.length === 0) return
    setMixedBoxes(nextMixedBoxes)
    setMixedResult(null)
    setSelectedMixedPallet(0)
    setSelectedBoxPlacementId(null)
    setContainerSource('list')
    setSelectedContainerPlan(0)
    setSelectedContainerPalletId(null)
    setSelectedContainerBoxId(null)
    setContainerResult(null)
    setLooseContainerResult(calculateLooseContainerLoad(looseBoxes, selectedContainer, productItems.length))
    setActiveTab('containers')
  }

  const getContainerPalletInputs = (source: 'mixed' | 'simple' | 'list'): ContainerPalletInput[] => {
    const result = source === 'list' ? productListResult : mixedResult
    if ((source === 'mixed' || source === 'list') && result) {
      return result.pallets.map((palletPlan, index) => ({
        id: `${source}-pallet-${index}`,
        label: `Paleta ${index + 1}`,
        length: palletPlan.fabricatedPallet.length,
        width: palletPlan.fabricatedPallet.width,
        height: palletPlan.fabricatedPallet.height,
        weight: palletPlan.totalWeight,
        color: BOX_COLORS[index % BOX_COLORS.length],
        sourceIndex: index,
      }))
    }

    if (source === 'simple' && simpleResult && !('error' in simpleResult)) {
      return Array.from({ length: simpleResult.palletsNeeded }, (_, index) => {
        const boxesOnThisPallet = index === simpleResult.palletsNeeded - 1
          ? simpleResult.totalBoxesNeeded - simpleResult.totalBoxes * index
          : simpleResult.totalBoxes
        return {
          id: `simple-pallet-${index}`,
          label: `Paleta ${index + 1}`,
          length: pallet.length,
          width: pallet.width,
          height: pallet.height,
          weight: Math.max(0, Math.min(simpleResult.totalBoxes, boxesOnThisPallet)) * boxWeight,
          color: '#2563eb',
          sourceIndex: index,
        }
      })
    }

    return []
  }

  const handleSelectContainerSource = (source: 'mixed' | 'simple' | 'list') => {
    setContainerSource(source)
    setSelectedContainerPlan(0)
    setSelectedContainerPalletId(null)
    setSelectedContainerBoxId(null)
    setManualCargoAdjustments({})
    if (source === 'list') {
      const looseBoxes = getLooseContainerInputs()
      setContainerResult(null)
      const result = looseBoxes.length > 0 ? calculateLooseContainerLoad(looseBoxes, selectedContainer, productItems.length) : null
      setLooseContainerResult(result)
      if (result?.plans.length) setLastReportSource('loose')
      return
    }
    const sourcePallets = getContainerPalletInputs(source)
    setLooseContainerResult(null)
    const result = sourcePallets.length > 0 ? calculateContainerLoad(sourcePallets, selectedContainer) : null
    setContainerResult(result)
    if (result?.plans.length) setLastReportSource('container')
  }

  const handleCalculateMixed = () => {
    setSelectedMixedPallet(0)
    setSelectedBoxPlacementId(null)
    const result = calculateMixedBoxArrangement(mixedBoxes, pallet)
    setMixedResult(result)
    if (result?.pallets.length) setLastReportSource('mixed')
    setContainerResult(null)
  }

  const buildBasicReportInput = (): BasicLogisticsReportInput | null => {
    if (lastReportSource === 'container' && containerResult) return {
      title: 'Informe de carga paletizada',
      subtitle: 'Resumen operativo de paletas ubicadas dentro del método de envío seleccionado.',
      destination: containerResult.container.name,
      summary: [
        { label: 'Contenedores necesarios', value: containerResult.containersNeeded },
        { label: 'Paletas ubicadas', value: `${containerResult.placedPallets}/${containerResult.totalPallets}` },
        { label: 'Paletas pendientes', value: containerResult.unplacedPallets },
        { label: 'Peso total', value: `${containerResult.totalWeight.toFixed(0)} kg` },
      ],
      warnings: containerResult.warnings,
      containerResult,
      manualAdjustments: manualAdjustmentRows,
    }
    if (lastReportSource === 'loose' && looseContainerResult) return {
      title: 'Informe de carga suelta',
      subtitle: 'Resumen operativo de cajas individuales ubicadas dentro del método de envío seleccionado.',
      destination: looseContainerResult.container.name,
      summary: [
        { label: 'Contenedores necesarios', value: looseContainerResult.containersNeeded },
        { label: 'Cajas ubicadas', value: `${looseContainerResult.placedBoxes}/${looseContainerResult.totalBoxes}` },
        { label: 'Cajas pendientes', value: looseContainerResult.unplacedBoxes },
        { label: 'Peso total', value: `${looseContainerResult.totalWeight.toFixed(0)} kg` },
        { label: 'Tipos de SKU', value: looseContainerResult.totalBoxTypes },
      ],
      warnings: looseContainerResult.warnings,
      containerResult: looseContainerResult,
      manualAdjustments: manualAdjustmentRows,
    }
    if (lastReportSource === 'simple' && simpleCalculation) return {
      title: 'Informe de paleta simple',
      subtitle: 'Resultado de cálculo para una referencia de caja y paleta configurada.',
      destination: destinationProfile.label,
      summary: [
        { label: 'Caja / SKU', value: simpleBoxName || 'Caja simple' },
        { label: 'Cajas solicitadas', value: simpleCalculation.totalBoxesNeeded },
        { label: 'Cajas por paleta', value: simpleCalculation.totalBoxes },
        { label: 'Paletas requeridas', value: simpleCalculation.palletsNeeded },
        { label: 'Peso total', value: `${simpleCalculation.totalWeight.toFixed(0)} kg` },
        { label: 'Utilización', value: `${simpleCalculation.utilizationPercentage.toFixed(1)}%` },
        { label: 'Paleta', value: `${pallet.length.toLocaleString()} × ${pallet.width.toLocaleString()} × ${pallet.height.toLocaleString()} mm` },
      ],
    }
    return null
  }

  const handleDownloadLogisticsPdf = () => {
    if (lastReportSource === 'mixed' && hasDetailedMixedReport && mixedResult) {
      downloadLogisticsPdf({
        destination: destinationProfile,
        maneuverability: { preferredMaxSide: MANEUVERABLE_PALLET_MAX_SIDE, allowOversize: allowOversizePallets },
        configuredPallet: pallet,
        mixedBoxes,
        mixedResult,
        containerResult: containerSource === 'mixed' ? containerResult : null,
        manualAdjustments: manualAdjustmentRows,
      })
      return
    }
    const report = buildBasicReportInput()
    if (report) downloadBasicLogisticsPdf(report)
  }

  const handleDownloadLogisticsExcel = () => {
    if (lastReportSource === 'mixed' && hasDetailedMixedReport && mixedResult) {
      downloadLogisticsExcel({
        destination: destinationProfile,
        maneuverability: { preferredMaxSide: MANEUVERABLE_PALLET_MAX_SIDE, allowOversize: allowOversizePallets },
        configuredPallet: pallet,
        mixedBoxes,
        mixedResult,
        containerResult: containerSource === 'mixed' ? containerResult : null,
        manualAdjustments: manualAdjustmentRows,
      })
      return
    }
    const report = buildBasicReportInput()
    if (report) downloadBasicLogisticsExcel(report)
  }

  const getContainerPallets = (): ContainerPalletInput[] => getContainerPalletInputs(containerSource)

  const handleManualCargoAdjust = (source: 'container' | 'loose', cargoId: string, adjustment: ManualCargoAdjustment) => {
    const key = manualAdjustmentKey(source, selectedContainerPlan, cargoId)
    setManualCargoAdjustments((current) => ({ ...current, [key]: { ...adjustment, source, planIndex: selectedContainerPlan, cargoId } }))
  }

  const handleCalculateContainer = () => {
    setSelectedContainerPlan(0)
    setSelectedContainerPalletId(null)
    setSelectedContainerBoxId(null)
    setManualCargoAdjustments({})
    if (containerSource === 'list') {
      const looseBoxes = getLooseContainerInputs()
      setContainerResult(null)
      const result = looseBoxes.length > 0 ? calculateLooseContainerLoad(looseBoxes, selectedContainer, productItems.length) : null
      setLooseContainerResult(result)
      if (result?.plans.length) setLastReportSource('loose')
      return
    }
    const sourcePallets = getContainerPallets()
    setLooseContainerResult(null)
    const result = sourcePallets.length > 0 ? calculateContainerLoad(sourcePallets, selectedContainer) : null
    setContainerResult(result)
    if (result?.plans.length) setLastReportSource('container')
  }

  const availableContainerPallets = containerSource === 'list' ? [] : getContainerPallets()
  const availableLooseBoxes = getLooseContainerInputs()

  const handleAddMixedBox = () => {
    setMixedBoxes((current) => [
      ...current,
      {
        id: `${Date.now()}-${current.length}`,
        name: `SKU-${String.fromCharCode(65 + current.length)} · Nueva caja`,
        boxDimensions: { length: 500, width: 350, height: 250, weight: 10 },
        quantity: 10,
        canStack: true,
        allowHorizontalRotation: true,
        allowVerticalRotation: false,
      },
    ])
  }

  const handleRemoveMixedBox = (id: string) => {
    setMixedBoxes((current) => current.length > 1 ? current.filter((box) => box.id !== id) : current)
    setSelectedMixedPallet(0)
    setSelectedBoxPlacementId(null)
    setMixedResult(null)
  }

  const handleUpdateMixedBox = (id: string, updates: Partial<MixedBoxItem>) => {
    setMixedBoxes((current) => current.map((box) => box.id === id ? { ...box, ...updates } : box))
    setSelectedMixedPallet(0)
    setSelectedBoxPlacementId(null)
    setMixedResult(null)
  }

  const handleUpdateMixedDimensions = (id: string, updates: Partial<BoxDimensions>) => {
    setMixedBoxes((current) => current.map((box) => box.id === id ? { ...box, boxDimensions: { ...box.boxDimensions, ...updates } } : box))
    setSelectedMixedPallet(0)
    setSelectedBoxPlacementId(null)
    setMixedResult(null)
  }

  const renderNumberField = (label: string, value: number, onChange: (value: number) => void, min = 1) => (
    <label className="measure-field block text-slate-700">
      <span className="mb-1 block font-mono text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">{label}</span>
      <input
        type="number"
        min={min}
        value={value}
        onChange={(event) => onChange(numberValue(event.target.value, value))}
        className="measure-input w-full rounded-md border border-slate-300 bg-white px-3 py-2 font-mono text-sm font-semibold tabular-nums text-slate-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
      />
    </label>
  )

  const renderCheckboxField = (label: string, checked: boolean, onChange: (checked: boolean) => void) => (
    <label className="flex cursor-pointer items-center gap-2 rounded-md border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 transition hover:border-slate-400 hover:bg-slate-50">
      <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} className="h-4 w-4 accent-blue-700" />
      <span>{label}</span>
    </label>
  )

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900">
      <header className="border-b-2 border-slate-200 bg-white/95 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
        <div className="container flex flex-wrap items-center justify-between gap-4 py-3 sm:py-4">
          <div className="brand-lockup flex items-center gap-3"><div className="brand-mark flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-blue-600 text-white shadow-sm shadow-blue-200"><Package className="h-5 w-5" /></div><div><div className="flex flex-wrap items-center gap-2"><h1 className="brand-wordmark font-poppins text-xl font-bold tracking-[-0.04em] text-slate-900 sm:text-2xl"><span>Pallet</span><span className="text-cyan-600">Optimizer</span></h1><span className="brand-descriptor border-l border-slate-200 pl-2 font-mono text-[9px] font-bold uppercase tracking-[0.15em] text-slate-400">Planificación de carga</span></div><p className="mt-0.5 text-xs text-slate-500">Cajas, paletas y envío en un solo flujo.</p></div></div>
          <div className="hidden items-center gap-2 rounded-full border border-emerald-100 bg-emerald-50 px-3 py-1.5 text-xs font-medium text-emerald-700 sm:flex"><CircleCheck className="h-4 w-4" /> Planificador listo</div>
        </div>
      </header>

      <main className="container max-w-[1500px] py-5 sm:py-6">
        <div className="workflow-tabs mb-5 overflow-x-auto rounded-xl border border-slate-200 bg-white p-1.5 shadow-sm">
          {[
            { id: 'products' as const, label: 'Productos', helper: '1', icon: ListIcon },
            { id: 'simple' as const, label: 'Paleta simple', helper: '2', icon: Box },
            { id: 'mixed' as const, label: 'Mezcla de cajas', helper: '3', icon: Layers3 },
            { id: 'containers' as const, label: 'Contenedores', helper: '4', icon: Truck },
            { id: 'compare' as const, label: 'Descarga informe', helper: '5', icon: FileDown },
          ].map(({ id, label, helper, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              aria-current={activeTab === id ? 'step' : undefined}
              className={`workflow-step inline-flex min-w-max flex-1 items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-sm font-semibold transition sm:flex-none sm:justify-start ${activeTab === id ? 'bg-sky-500 text-white shadow-md shadow-sky-200' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'}`}
            >
              <span className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold ${activeTab === id ? 'bg-white/25 text-white' : 'bg-slate-100 text-slate-500'}`}>{helper}</span><Icon className="h-4 w-4" /><span className="hidden md:inline">{label}</span><span className="md:hidden">{helper === '1' ? 'Productos' : helper === '2' ? 'Simple' : helper === '3' ? 'Mezcla' : helper === '4' ? 'Envío' : 'Informe'}</span>{activeTab === id && <span className="workflow-step-status hidden xl:inline">Actual</span>}
            </button>
          ))}
        </div>
        {activeTab !== 'mixed' && activeTab !== 'products' && <WorkflowHint activeTab={activeTab} />}

        <details className="shipping-context mb-5 rounded-2xl border border-slate-200 bg-white shadow-sm">
          <summary className="flex cursor-pointer list-none flex-wrap items-center justify-between gap-4 p-4"><div><p className="technical-stage-kicker">Etapa 00 / Destino y operación</p><h2 className="mt-1 font-poppins text-lg font-bold text-slate-900">Define el envío antes de paletizar</h2></div><div className="flex items-center gap-3"><span className="font-mono text-xs font-semibold text-slate-700">{destinationProfile.label} · {destinationProfile.maxTotalHeight.toLocaleString()} mm</span><ChevronDown className="operational-chevron h-5 w-5 text-slate-500" /></div></summary>
          <div className="grid gap-4 border-t border-slate-200 p-4 pt-4 lg:grid-cols-[minmax(0,1fr)_auto_auto] lg:items-center">
            <div><p className="text-sm text-slate-600">El destino fija la altura máxima y el espacio de base que puede recomendar el optimizador.</p></div>
            <label className="block text-sm font-semibold text-slate-700"><span className="mb-1 block font-mono text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">Destino final</span><select value={finalTransport} onChange={(event) => handleFinalTransportChange(event.target.value)} className="min-w-56 rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100">{shippingProfiles.map((profile) => <option key={profile.id} value={profile.id}>{profile.isCustom ? `Personalizado · ${profile.label}` : profile.label}</option>)}</select></label>
            <div className="flex items-center gap-3 rounded-lg border border-blue-200 bg-blue-50/70 px-4 py-3"><div><p className="font-mono text-[10px] font-bold uppercase tracking-[0.14em] text-blue-700">Altura máxima aplicada</p><p className="mt-1 font-mono text-xl font-bold text-slate-950">{destinationProfile.maxTotalHeight.toLocaleString()} mm</p></div><button type="button" onClick={() => setPalletHeight(destinationProfile.maxTotalHeight)} className="rounded-md border border-blue-300 bg-white px-2.5 py-1.5 text-xs font-bold text-blue-800 transition hover:bg-blue-100">Usar máximo</button></div>
            <p className="lg:col-span-3 text-xs leading-5 text-slate-500">{destinationProfile.note} La base de la paleta se descuenta de esta altura antes de calcular niveles.</p>
            <div className="lg:col-span-3 flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 pt-3"><div><p className="technical-stage-kicker">Maniobrabilidad / Operación interna</p><p className="mt-1 text-xs leading-5 text-slate-600">Perfil predeterminado para montacargas pequeño y transpaleta: recomienda bases de hasta <strong className="font-mono text-slate-800">{MANEUVERABLE_PALLET_MAX_SIDE.toLocaleString()} × {MANEUVERABLE_PALLET_MAX_SIDE.toLocaleString()} mm</strong>.</p></div><label className="flex cursor-pointer items-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700"><input type="checkbox" checked={allowOversizePallets} onChange={(event) => setAllowOversizePallets(event.target.checked)} className="h-4 w-4 accent-blue-700" /><span>Permitir bases ampliadas</span></label><p className="w-full font-mono text-[11px] text-slate-500">{allowOversizePallets ? 'Se mostrarán alternativas mayores marcadas como base ampliada.' : 'Las alternativas que exceden este tamaño se excluyen de la recomendación.'}</p></div>
            <details className="lg:col-span-3 operational-panel border-t border-slate-200 pt-3"><summary className="flex cursor-pointer list-none items-center justify-between gap-3"><div><p className="technical-stage-kicker">Perfiles de envío / Configuración</p><p className="mt-1 text-xs text-slate-600">Añade vehículos, rutas o equipos con su caja útil y restricciones de carga.</p></div><div className="flex items-center gap-2"><span className="font-mono text-[11px] text-slate-500">{customShippingProfiles.length} personalizado(s)</span><ChevronDown className="operational-chevron h-5 w-5 text-slate-500" /></div></summary><div className="mt-3 space-y-3 border-t border-slate-200 pt-3"><button type="button" onClick={handleAddShippingProfile} className="inline-flex items-center gap-2 rounded-md border border-blue-700 bg-blue-700 px-3 py-2 text-xs font-bold uppercase tracking-[0.08em] text-white transition hover:bg-blue-800"><Plus className="h-4 w-4" /> Añadir tipo de envío</button>{customShippingProfiles.length === 0 ? <p className="rounded-md border border-dashed border-slate-300 bg-slate-50 px-3 py-3 text-xs leading-5 text-slate-600">Crea un perfil para una furgoneta, camión especial, plataforma u otro destino con dimensiones internas propias.</p> : customShippingProfiles.map((profile) => <div key={profile.id} className="rounded-lg border border-slate-300 bg-slate-50 p-3"><div className="mb-3 flex items-center gap-3"><input value={profile.label} onChange={(event) => handleUpdateShippingProfile(profile.id, { label: event.target.value })} className="min-w-0 flex-1 border-b border-slate-300 bg-transparent px-1 py-1 font-semibold text-slate-900 outline-none focus:border-blue-600" aria-label="Nombre del tipo de envío" /><button type="button" onClick={() => handleRemoveShippingProfile(profile.id)} className="rounded-md p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600" title="Eliminar perfil de envío"><Trash2 className="h-4 w-4" /></button></div><div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{renderNumberField('Largo interno (mm)', profile.maxLength, (value) => handleUpdateShippingProfile(profile.id, { maxLength: value }))}{renderNumberField('Ancho interno (mm)', profile.maxWidth, (value) => handleUpdateShippingProfile(profile.id, { maxWidth: value }))}{renderNumberField('Altura máxima (mm)', profile.maxTotalHeight, (value) => handleUpdateShippingProfile(profile.id, { maxTotalHeight: value }))}{renderNumberField('Peso máximo (kg)', profile.maxWeight, (value) => handleUpdateShippingProfile(profile.id, { maxWeight: value }))}</div><label className="mt-3 block text-xs font-semibold text-slate-700"><span className="mb-1 block font-mono text-[10px] uppercase tracking-[0.12em] text-slate-500">Nota operativa</span><input value={profile.note} onChange={(event) => handleUpdateShippingProfile(profile.id, { note: event.target.value })} className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100" /></label></div>)}</div></details>
          </div>
        </details>

        {customShippingProfiles.length > 0 && <section className="mb-5 rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm"><div className="flex flex-wrap items-center justify-between gap-3"><div><p className="technical-stage-kicker">Acceso rápido / perfiles guardados</p><p className="mt-1 text-xs text-slate-500">Marca una estrella para que el perfil aparezca primero en los selectores de destino y transporte.</p></div><span className="rounded-full bg-amber-50 px-2.5 py-1 text-[10px] font-bold text-amber-700">{favoriteShippingProfiles.length} favorito(s)</span></div><div className="mt-3 flex flex-wrap gap-2">{customShippingProfiles.map((profile) => <div key={profile.id} className={`flex items-center gap-1 rounded-lg border px-1 py-1 ${profile.isFavorite ? 'border-amber-200 bg-amber-50' : 'border-slate-200 bg-slate-50'}`}><button type="button" onClick={() => handleFinalTransportChange(profile.id)} className="rounded-md px-2 py-1.5 text-xs font-bold text-slate-700 transition hover:bg-white">{profile.isFavorite && '★ '}{profile.label}</button><button type="button" onClick={() => handleToggleShippingFavorite(profile.id)} className={`rounded-md p-1.5 transition ${profile.isFavorite ? 'text-amber-600 hover:bg-amber-100' : 'text-slate-400 hover:bg-white hover:text-amber-600'}`} title={profile.isFavorite ? 'Quitar de favoritos' : 'Marcar como favorito'} aria-label={profile.isFavorite ? `Quitar ${profile.label} de favoritos` : `Marcar ${profile.label} como favorito`}><Star className={`h-4 w-4 ${profile.isFavorite ? 'fill-current' : ''}`} /></button></div>)}</div></section>}
        {activeTab === 'products' && <ProductListPanel items={productItems} importResult={productImportResult} onItemsChange={setProductItems} onImport={handleImportProducts} onDownloadTemplate={downloadProductTemplate} onApplyToMix={handleApplyProductList} onApplyToSimple={handleApplyProductToSimple} onApplyToContainers={handleApplyListToContainers} onClearItems={handleClearProductList} />}

        {activeTab === 'simple' && (
          <div className="simple-flow space-y-4">
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
              <div className="space-y-3">
                <details className="operational-panel technical-stage relative overflow-hidden rounded-2xl border border-l-4 bg-white shadow-sm" open>
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-3 p-4"><div><p className="technical-stage-kicker">Entrada 01 / Producto</p><h2 className="mt-1 font-poppins text-lg font-bold">Dimensiones de la caja</h2></div><div className="flex items-center gap-3"><span className="hidden font-mono text-xs text-slate-600 sm:inline">{boxLength} × {boxWidth} × {boxHeight} mm · {totalBoxes} cajas</span><Box className="h-4 w-4 text-blue-700" /><ChevronDown className="operational-chevron h-4 w-4 text-slate-500" /></div></summary>
                  <div className="space-y-3 border-t border-slate-100 p-4 pt-3">
                    <label className="block text-sm font-medium text-slate-700">
                      <span className="mb-1 block">Etiqueta / SKU</span>
                      <input value={simpleBoxName} onChange={(event) => setSimpleBoxName(event.target.value)} className="w-full rounded-lg border border-slate-300 px-3 py-2 outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100" placeholder="Ej. SKU-A" />
                    </label>
                    <div className="simple-product-fields grid grid-cols-2 gap-2 md:grid-cols-3">{renderNumberField('Largo (mm)', boxLength, setBoxLength)}{renderNumberField('Ancho (mm)', boxWidth, setBoxWidth)}{renderNumberField('Alto (mm)', boxHeight, setBoxHeight)}{renderNumberField('Peso (kg)', boxWeight, setBoxWeight)}{renderNumberField('Cantidad total de cajas', totalBoxes, setTotalBoxes)}</div>
                    <div className="border-t border-slate-200 pt-3"><p className="mb-1.5 text-[10px] font-bold uppercase tracking-[0.15em] text-slate-500">Restricciones de manejo</p><div className="grid gap-1.5 sm:grid-cols-3">{renderCheckboxField('Se puede apilar', simpleHandling.canStack, (checked) => setSimpleHandling((current) => ({ ...current, canStack: checked })))}{renderCheckboxField('Rotación horizontal', simpleHandling.allowHorizontalRotation, (checked) => setSimpleHandling((current) => ({ ...current, allowHorizontalRotation: checked })))}{renderCheckboxField('Rotación vertical', simpleHandling.allowVerticalRotation, (checked) => setSimpleHandling((current) => ({ ...current, allowVerticalRotation: checked })))}</div></div>
                  </div>
                </details>

                <details className="operational-panel technical-stage relative overflow-hidden rounded-2xl border border-l-4 bg-white shadow-sm" open>
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-3 p-4"><div><p className="technical-stage-kicker">Entrada 02 / Base de carga</p><h2 className="mt-1 font-poppins text-lg font-bold">Dimensiones de la paleta</h2></div><div className="flex items-center gap-3"><span className="hidden font-mono text-xs text-slate-600 sm:inline">{palletLength} × {palletWidth} mm · base {palletBaseHeight} mm</span><ChevronDown className="operational-chevron h-4 w-4 text-slate-500" /></div></summary>
                  <div className="border-t border-slate-100 p-4 pt-3"><div className="grid grid-cols-2 gap-2">
                    {renderNumberField('Largo (mm)', palletLength, setPalletLength)}
                    {renderNumberField('Ancho (mm)', palletWidth, setPalletWidth)}
                    {renderNumberField('Altura total (mm)', palletHeight, setPalletHeight)}
                    {renderNumberField('Altura de base (mm)', palletBaseHeight, setPalletBaseHeight, 0)}
                    {renderNumberField('Peso máximo (kg)', maxWeight, setMaxWeight)}
                  </div><p className="mt-3 text-xs leading-5 text-slate-500">Altura útil de cajas: <strong>{Math.max(0, effectivePalletHeight - palletBaseHeight).toLocaleString()} mm</strong> de un máximo de {destinationProfile.maxTotalHeight.toLocaleString()} mm para {destinationProfile.label}.</p><PalletRecommendationPanel recommendations={simplePalletRecommendations} destinationLabel={destinationProfile.label} onApply={handleApplyPalletRecommendation} /></div>
                </details>

                <button onClick={handleCalculateSimple} className="calculation-cta flex w-full items-center justify-center gap-2 rounded-xl bg-sky-500 px-4 py-3 text-sm font-bold text-white shadow-sm shadow-sky-200 transition hover:bg-sky-600 active:scale-[0.99]"><span>Calcular disposición</span><ArrowRight className="h-4 w-4" /></button>
              </div>

              <section className={`rounded-2xl border border-slate-200 bg-white shadow-sm ${simpleResult ? 'p-4' : 'min-h-[320px] p-6'}`}>
                {!simpleResult && <TechnicalEmptyState />}
                {simpleResult && ('error' in simpleResult) && <div><div className="mb-4 flex items-center gap-3 text-red-700"><AlertTriangle className="h-5 w-5" /><h2 className="font-poppins text-xl font-bold">No es posible acomodar las cajas</h2></div><p className="mb-4 text-sm text-slate-500">Prueba una de estas dimensiones recomendadas:</p><div className="space-y-2">{simpleResult.recommendations.map((recommendation, index) => <div key={index} className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm font-semibold">{recommendation.length} × {recommendation.width} × {recommendation.height} mm</div>)}</div></div>}
                {simpleResult && !('error' in simpleResult) && <div className="space-y-3"><div className="flex flex-wrap items-end justify-between gap-2"><div><p className="text-[10px] font-bold uppercase tracking-[0.16em] text-sky-600">Resultado optimizado</p><h2 className="mt-1 font-poppins text-xl font-bold">{simpleBoxName || 'Caja simple'}</h2></div><span className="rounded-full bg-sky-50 px-2.5 py-1 text-xs font-bold text-sky-700">{simpleResult.orientation.description}</span></div><div className="grid grid-cols-2 gap-2 xl:grid-cols-4"><div className="rounded-lg border border-sky-100 bg-sky-50/70 p-3"><p className="text-[10px] font-bold uppercase tracking-[0.1em] text-sky-700">Cajas / paleta</p><p className="mt-1 text-xl font-bold text-sky-950">{simpleResult.totalBoxes}</p></div><div className="rounded-lg border border-emerald-100 bg-emerald-50/70 p-3"><p className="text-[10px] font-bold uppercase tracking-[0.1em] text-emerald-700">Paletas</p><p className="mt-1 text-xl font-bold text-emerald-950">{simpleResult.palletsNeeded}</p></div><div className="rounded-lg border border-violet-100 bg-violet-50/70 p-3"><p className="text-[10px] font-bold uppercase tracking-[0.1em] text-violet-700">Peso</p><p className="mt-1 text-xl font-bold text-violet-950">{simpleResult.totalWeight.toFixed(0)} kg</p></div><div className="rounded-lg border border-amber-100 bg-amber-50/70 p-3"><p className="text-[10px] font-bold uppercase tracking-[0.1em] text-amber-700">Uso</p><p className="mt-1 text-xl font-bold text-amber-950">{simpleResult.utilizationPercentage.toFixed(1)}%</p></div></div><div className="grid gap-x-4 gap-y-1 border-t border-slate-100 pt-3 text-xs leading-5 text-slate-600 sm:grid-cols-2"><p><strong>Paleta:</strong> {pallet.length} × {pallet.width} mm · base {palletBaseHeight} mm</p><p><strong>Destino:</strong> {destinationProfile.label} · {destinationProfile.maxTotalHeight.toLocaleString()} mm</p><p><strong>Niveles:</strong> {simpleResult.arrangement.totalLevels}</p><p><strong>Solicitadas:</strong> {simpleResult.totalBoxesNeeded} cajas</p></div></div>}
              </section>
            </div>

                {simpleResult && !('error' in simpleResult) && <PalletVisualization3D boxes={generateSimpleBoxes3D(simpleResult)} selectedBoxId={selectedSimpleBoxId} onBoxSelect={setSelectedSimpleBoxId} palletWidth={pallet.length} palletDepth={pallet.width} palletHeight={pallet.height} palletBaseHeight={palletBaseHeight} />}
          </div>
        )}

        {activeTab === 'mixed' && (
          <div className="guided-workspace space-y-6">
            <section className="mixed-hero rounded-2xl border border-slate-200 bg-white px-5 py-4 shadow-sm sm:px-6"><div className="flex flex-col justify-between gap-3 lg:flex-row lg:items-end"><div><p className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-400">Paso 2 de 4</p><h2 className="mt-1 text-xl font-bold tracking-tight text-slate-900">Añadir cajas para paletizar</h2><p className="mt-1 max-w-2xl text-sm leading-5 text-slate-500">Define medidas, peso, cantidad y restricciones de cada SKU.</p></div><div className="flex items-center gap-2"><span className="rounded-full bg-sky-50 px-3 py-1.5 text-xs font-bold text-sky-700">{mixedBoxes.reduce((sum, box) => sum + box.quantity, 0)} cajas</span><span className="rounded-full bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-600">{mixedBoxes.length} tipos</span></div></div><div className="guided-entry-cards compact-entry-cards mt-4 grid gap-3 md:grid-cols-3"><button type="button" onClick={() => setActiveTab('products')} className="text-left"><span className="entry-icon text-sky-600"><FileSpreadsheet className="h-4 w-4" /></span><strong>Importar Excel o CSV</strong><span>Gestiona una lista de SKU y aplícala a esta mezcla.</span></button><div><span className="entry-icon text-emerald-600"><Layers3 className="h-4 w-4" /></span><strong>Edición directa</strong><span>Ajusta los SKU de abajo sin salir del plan actual.</span></div><button type="button" onClick={handleAddMixedBox} className="text-left"><span className="entry-icon text-sky-600"><Plus className="h-4 w-4" /></span><strong>Añadir otro tipo</strong><span>Crea una fila con dimensiones y reglas de manejo.</span></button></div></section>

            <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
              <section className="mixed-sku-editor compact-sku-editor overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"><div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-4 py-3"><div className="flex items-center gap-3"><h3 className="font-bold text-slate-900">Grupo de cajas</h3><span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs text-slate-500">{mixedBoxes.length} SKU · {mixedBoxes.reduce((sum, box) => sum + box.quantity, 0)} cajas</span></div><button onClick={handleAddMixedBox} className="inline-flex items-center gap-2 rounded-lg border border-sky-200 bg-sky-50 px-3 py-1.5 text-xs font-bold text-sky-700 transition hover:bg-sky-100"><Plus className="h-4 w-4" /> Añadir caja</button></div><div className="sku-column-headings hidden grid-cols-[130px_minmax(350px,1fr)_235px] gap-3 border-b border-slate-100 px-4 py-2 text-[10px] font-bold uppercase tracking-[0.13em] text-slate-400 xl:grid"><span>SKU / etiqueta</span><span>Medidas y cantidad</span><span>Reglas de manejo</span></div><div className="divide-y divide-slate-100">{mixedBoxes.map((box, index) => <div key={box.id} className="rounded-none border-0 bg-white p-3"><div className="flex items-center gap-2"><span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: BOX_COLORS[index % BOX_COLORS.length] }} /><input value={box.name} onChange={(event) => handleUpdateMixedBox(box.id, { name: event.target.value })} className="min-w-0 flex-1 border-b border-transparent bg-transparent px-0 py-1 text-sm font-semibold text-slate-900 outline-none transition focus:border-sky-500" aria-label={`Nombre del tipo de caja ${index + 1}`} /><button onClick={() => handleRemoveMixedBox(box.id)} disabled={mixedBoxes.length === 1} className="rounded-lg p-1.5 text-slate-300 transition hover:bg-red-50 hover:text-red-500 disabled:cursor-not-allowed disabled:opacity-30" title="Eliminar tipo de caja" aria-label={`Eliminar ${box.name}`}><Trash2 className="h-3.5 w-3.5" /></button></div><div className="grid grid-cols-2 gap-2 sm:grid-cols-5">{renderNumberField('Largo', box.boxDimensions.length, (value) => handleUpdateMixedDimensions(box.id, { length: value }))}{renderNumberField('Ancho', box.boxDimensions.width, (value) => handleUpdateMixedDimensions(box.id, { width: value }))}{renderNumberField('Alto', box.boxDimensions.height, (value) => handleUpdateMixedDimensions(box.id, { height: value }))}{renderNumberField('Peso kg', box.boxDimensions.weight, (value) => handleUpdateMixedDimensions(box.id, { weight: value }))}{renderNumberField('Cantidad', box.quantity, (value) => handleUpdateMixedBox(box.id, { quantity: value }))}</div><div className="mixed-constraints mt-2 flex flex-wrap items-center gap-1.5">{renderCheckboxField('Apilar', box.canStack, (checked) => handleUpdateMixedBox(box.id, { canStack: checked }))}{renderCheckboxField('Giro H', box.allowHorizontalRotation, (checked) => handleUpdateMixedBox(box.id, { canStack: box.canStack, allowHorizontalRotation: checked }))}{renderCheckboxField('Giro V', box.allowVerticalRotation, (checked) => handleUpdateMixedBox(box.id, { allowVerticalRotation: checked }))}</div></div>)}</div></section>

              <aside className="mixed-sidebar space-y-3"><section className="mixed-settings rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"><div className="flex items-start justify-between gap-3"><div><p className="text-[11px] font-bold uppercase tracking-[0.14em] text-slate-400">Configuración</p><h3 className="mt-1 text-lg font-bold text-slate-900">Paleta a medida</h3></div><span className="rounded-full bg-slate-100 px-2.5 py-1 font-mono text-[10px] font-bold text-slate-600">{palletLength} × {palletWidth}</span></div><div className="mt-3 grid grid-cols-2 gap-2">{renderNumberField('Largo (mm)', palletLength, setPalletLength)}{renderNumberField('Ancho (mm)', palletWidth, setPalletWidth)}{renderNumberField('Altura total (mm)', palletHeight, setPalletHeight)}{renderNumberField('Base (mm)', palletBaseHeight, setPalletBaseHeight, 0)}{renderNumberField('Peso máximo (kg)', maxWeight, setMaxWeight)}</div><p className="mt-3 text-xs leading-5 text-slate-500">Destino: <strong className="text-slate-700">{destinationProfile.label}</strong> · altura útil {Math.max(0, effectivePalletHeight - palletBaseHeight).toLocaleString()} mm.</p></section><PalletRecommendationPanel recommendations={mixedPalletRecommendations} destinationLabel={destinationProfile.label} onApply={handleApplyPalletRecommendation} /><button onClick={handleCalculateMixed} className="calculation-cta flex w-full items-center justify-center gap-2 rounded-xl bg-sky-500 px-4 py-3 text-sm font-bold text-white shadow-sm shadow-sky-200 transition hover:bg-sky-600 active:scale-[0.99]"><span>Calcular mezcla</span><ArrowRight className="h-4 w-4" /></button></aside>
            </div>

            {mixedResult && <div className="grid grid-cols-2 gap-3 sm:grid-cols-5"><Metric label="Total de cajas" value={mixedResult.totalBoxes} tone="blue" /><Metric label="Paletas necesarias" value={mixedResult.palletsNeeded} tone="green" /><Metric label="Peso total" value={`${mixedResult.totalWeight.toFixed(0)} kg`} tone="violet" /><Metric label="Utilización global" value={`${mixedResult.utilizationPercentage.toFixed(1)}%`} tone="orange" /><Metric label="Cajas ubicadas" value={`${mixedResult.totalBoxes - mixedResult.unplacedBoxes}/${mixedResult.totalBoxes}`} tone="blue" /></div>}
            {mixedResult && <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><div className="mb-5 flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-blue-700">Plan de carga</p><h2 className="mt-1 font-poppins text-xl font-bold">Distribución por paleta</h2><p className="mt-1 text-sm text-slate-500">Cada paleta se fabrica con la menor base que conserva exactamente su acomodo, dejando 50 mm de holgura técnica por lado cuando hay reducción.</p></div><span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">{mixedResult.stackingMode}</span></div>{mixedResult.warnings.length > 0 && <div className="mb-5 space-y-2">{mixedResult.warnings.map((warning) => <div key={warning} className="flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800"><AlertTriangle className="h-4 w-4 shrink-0" /> {warning}</div>)}</div>}<div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">{mixedResult.pallets.map((palletPlan, index) => <button type="button" key={palletPlan.palletIndex} onClick={() => { setSelectedMixedPallet(index); setSelectedBoxPlacementId(null) }} className={`rounded-xl border p-4 text-left transition ${index === selectedMixedPallet ? 'border-blue-600 bg-blue-50 shadow-sm' : 'border-slate-200 bg-slate-50 hover:border-blue-300 hover:bg-blue-50/50'}`}><div className="flex items-center justify-between gap-2"><span className="text-xs font-bold uppercase tracking-[0.12em] text-blue-700">Paleta {index + 1}</span><span className="rounded-full bg-white px-2 py-1 text-[11px] font-semibold text-slate-600">Ver 3D</span></div><p className="mt-3 font-mono text-sm font-bold text-slate-900">Base fabricada: {palletPlan.fabricatedPallet.length.toLocaleString()} × {palletPlan.fabricatedPallet.width.toLocaleString()} mm</p><div className="mt-3 grid grid-cols-3 gap-2 text-sm"><span><strong className="block text-lg text-slate-900">{palletPlan.totalBoxes}</strong><small className="text-slate-500">cajas</small></span><span><strong className="block text-lg text-slate-900">{palletPlan.totalWeight.toFixed(0)}</strong><small className="text-slate-500">kg</small></span><span><strong className="block text-lg text-slate-900">{palletPlan.utilizationPercentage.toFixed(1)}%</strong><small className="text-slate-500">uso real</small></span></div><p className={`mt-3 text-xs font-medium ${palletPlan.fabricatedPallet.isReduced ? 'text-emerald-700' : 'text-slate-500'}`}>{palletPlan.fabricatedPallet.isReduced ? `Ahorro de base: ${palletPlan.fabricatedPallet.materialSavingsPercentage.toFixed(1)}% · huella ocupada ${palletPlan.fabricatedPallet.occupiedLength.toLocaleString()} × ${palletPlan.fabricatedPallet.occupiedWidth.toLocaleString()} mm` : 'Base completa: esta huella aprovecha la superficie disponible.'}</p>{palletPlan.warnings.length > 0 && <p className="mt-3 text-xs font-medium text-amber-700">{palletPlan.warnings[0]}</p>}</button>)}</div></section>}

            {mixedResult && <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><div className="mb-5 flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-blue-700">Lectura de la carga completa</p><h2 className="mt-1 font-poppins text-xl font-bold">Distribución por tipo de caja</h2></div><span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">Todas las paletas</span></div><div className="overflow-x-auto"><table className="w-full min-w-[560px] text-left text-sm"><thead className="border-b border-slate-200 text-xs uppercase tracking-[0.1em] text-slate-500"><tr><th className="pb-3 pr-4">Tipo / etiqueta</th><th className="pb-3 pr-4">Cantidad ubicada</th><th className="pb-3 pr-4">Peso</th><th className="pb-3">Participación</th></tr></thead><tbody>{mixedResult.boxDistribution.map((distribution, index) => <tr key={distribution.boxId} className="border-b border-slate-100 last:border-0"><td className="py-3 pr-4"><span className="mr-2 inline-block h-3 w-3 rounded-sm align-middle" style={{ backgroundColor: BOX_COLORS[index % BOX_COLORS.length] }} />{distribution.boxName}</td><td className="py-3 pr-4 font-semibold">{distribution.quantity}</td><td className="py-3 pr-4">{distribution.weight.toFixed(1)} kg</td><td className="py-3">{distribution.percentage.toFixed(1)}%</td></tr>)}</tbody></table></div></section>}

            {activeMixedPallet && <div><div className="mb-3 flex flex-wrap items-center justify-between gap-2"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-blue-700">Vista seleccionada</p><h2 className="font-poppins text-xl font-bold">Paleta {activeMixedPallet.palletIndex + 1} de {mixedResult?.palletsNeeded}</h2></div><p className="text-sm text-slate-500">{activeMixedPallet.totalBoxes} cajas · {activeMixedPallet.totalWeight.toFixed(0)} kg · base {activeMixedPallet.fabricatedPallet.length.toLocaleString()} × {activeMixedPallet.fabricatedPallet.width.toLocaleString()} mm</p></div><PalletVisualization3D boxes={generateMixedBoxes3D(activeMixedPallet.boxPlacements)} selectedBoxId={selectedBoxPlacementId} onBoxSelect={setSelectedBoxPlacementId} palletWidth={activeMixedPallet.fabricatedPallet.length} palletDepth={activeMixedPallet.fabricatedPallet.width} palletHeight={activeMixedPallet.fabricatedPallet.height} palletBaseHeight={activeMixedPallet.fabricatedPallet.baseHeight ?? palletBaseHeight} /></div>}
          </div>
        )}

        {activeTab === 'containers' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 gap-8 lg:grid-cols-[minmax(0,0.95fr)_minmax(0,1.05fr)]">
              <section className="rounded-2xl border border-slate-200 border-l-4 border-l-blue-700 bg-white p-6 shadow-sm">
                <div className="mb-5 flex items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-blue-700">Carga secundaria / 03</p><h2 className="mt-1 font-poppins text-xl font-bold">Carga dentro del contenedor</h2><p className="mt-1 text-sm text-slate-500">Las paletas siguen como unidades logísticas; las listas se cargan como cajas sueltas individuales.</p></div><Truck className="h-6 w-6 text-blue-700" /></div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-y border-slate-200 py-2 text-[10px] font-bold uppercase tracking-[0.16em] text-slate-500"><span>Unidad de planificación</span><span className="font-mono text-blue-700">{containerSource === 'list' ? 'BOX → CONTENEDOR' : 'PALLET → CONTENEDOR'}</span></div>
                  <label className="block text-sm font-medium text-slate-700"><span className="mb-1 block">Fuente de carga</span><select value={containerSource} onChange={(event) => handleSelectContainerSource(event.target.value as 'mixed' | 'simple' | 'list')} className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100"><option value="list">{productListLabel} ({productListTotalBoxes} cajas, {productItems.length} SKU) · carga suelta</option><option value="mixed">Mezcla de cajas ({mixedBoxes.reduce((s, b) => s + b.quantity, 0)} cajas) · {mixedResult ? `${mixedResult.pallets.length} paletas` : 'pendiente'}</option><option value="simple">Cálculo simple · {simpleResult && !('error' in simpleResult) ? `${simpleResult.palletsNeeded} paletas` : 'pendiente'}</option></select></label>
                  <label className="block text-sm font-medium text-slate-700"><span className="mb-1 block">Tipo de transporte / contenedor</span><select value={containerSpecId} onChange={(event) => handleContainerSpecChange(event.target.value)} className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100">{allContainerSpecs.map((spec) => <option key={spec.id} value={spec.id}>{shippingContainerSpecs.some((profile) => profile.id === spec.id) ? `Personalizado · ${spec.name}` : spec.name}</option>)}</select></label>
                  <div className="grid grid-cols-3 gap-2"><Metric label="Piezas / Cajas" value={containerSource === 'list' ? productListTotalBoxes : containerSource === 'mixed' ? mixedBoxes.reduce((s, b) => s + b.quantity, 0) : (simpleResult && !('error' in simpleResult) ? simpleResult.totalBoxesNeeded : 0)} tone="blue" /><Metric label={containerSource === 'list' ? 'Tipos SKU' : 'Paletas'} value={containerSource === 'list' ? productItems.length : availableContainerPallets.length} tone="green" /><Metric label="Peso estimado" value={`${(containerSource === 'list' ? productListTotalWeight : availableContainerPallets.reduce((sum, pallet) => sum + pallet.weight, 0)).toFixed(0)} kg`} tone="violet" /></div>
                  <div className="rounded-xl border border-blue-100 bg-blue-50/60 p-4 text-sm text-slate-600"><p className="font-semibold text-blue-900">Dimensiones internas de referencia</p><p className="mt-2">{selectedContainer.length.toLocaleString()} × {selectedContainer.width.toLocaleString()} × {selectedContainer.height.toLocaleString()} mm · máximo {selectedContainer.maxWeight.toLocaleString()} kg</p><p className="mt-2 text-xs leading-5 text-slate-500">{selectedContainer.note}</p></div>
                  <button onClick={handleCalculateContainer} disabled={containerSource === 'list' ? availableLooseBoxes.length === 0 : availableContainerPallets.length === 0} className="w-full rounded-xl bg-blue-700 px-4 py-3 text-sm font-bold uppercase tracking-[0.12em] text-white shadow-lg shadow-blue-900/15 transition hover:bg-blue-800 active:scale-[0.99] disabled:cursor-not-allowed disabled:bg-slate-300 disabled:shadow-none">Generar plan de contenedor</button>
                  {(containerSource === 'list' ? availableLooseBoxes.length === 0 : availableContainerPallets.length === 0) && <p className="text-xs leading-5 text-amber-700">{containerSource === 'list' ? 'Carga o edita una lista con cajas y cantidades válidas para generar el plan suelto.' : 'Primero calcula una disposición en Cálculo Simple o Mezcla de Cajas para generar las paletas de origen.'}</p>}
                </div>
              </section>

              <section className="min-h-[360px] rounded-2xl border border-slate-200 border-t-4 border-t-blue-700 bg-white p-6 shadow-sm">
                {!containerResult && !looseContainerResult && <ContainerEmptyState />}
                {containerResult && <div className="space-y-5"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-emerald-700">Resultado de carga paletizada</p><h2 className="mt-1 font-poppins text-2xl font-bold">{containerResult.container.name}</h2><p className="mt-1 text-sm text-slate-500">Plan de carga por paletas completas dentro del espacio interior.</p></div><div className="grid grid-cols-2 gap-3 xl:grid-cols-3"><Metric label="Contenedores necesarios" value={containerResult.containersNeeded} tone="green" /><Metric label="Paletas ubicadas" value={`${containerResult.placedPallets}/${containerResult.totalPallets}`} tone="blue" /><Metric label="Peso total" value={`${containerResult.totalWeight.toFixed(0)} kg`} tone="violet" /><Metric label="Paletas pendientes" value={containerResult.unplacedPallets} tone="orange" /><Metric label="m³ usados" value={formatVolumeM3(containerVolumeSummary?.usedM3 ?? 0)} tone="blue" /><Metric label="m³ libres" value={formatVolumeM3(containerVolumeSummary?.freeM3 ?? 0)} tone="green" /></div><div className="border-t border-slate-200 pt-4 text-sm leading-7 text-slate-600"><p><strong>Distribución:</strong> {containerResult.plans.map((plan) => `${plan.pallets.length} paleta(s) en contenedor ${plan.containerIndex + 1}`).join(' · ')}</p><p><strong>Uso de piso del contenedor 1:</strong> {containerResult.plans[0]?.floorUtilizationPercentage.toFixed(1) ?? '0.0'}%</p></div></div>}
                {looseContainerResult && <div className="space-y-5"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-emerald-700">Resultado de carga suelta</p><h2 className="mt-1 font-poppins text-2xl font-bold">{looseContainerResult.container.name}</h2><p className="mt-1 text-sm text-slate-500">Cada fila de la lista se expande a sus unidades físicas; no se convierte en paletas intermedias.</p></div><div className="grid grid-cols-2 gap-3 xl:grid-cols-3"><Metric label="Contenedores necesarios" value={looseContainerResult.containersNeeded} tone="green" /><Metric label="Cajas ubicadas" value={`${looseContainerResult.placedBoxes}/${looseContainerResult.totalBoxes}`} tone="blue" /><Metric label="Peso total" value={`${looseContainerResult.totalWeight.toFixed(0)} kg`} tone="violet" /><Metric label="Cajas pendientes" value={looseContainerResult.unplacedBoxes} tone="orange" /><Metric label="m³ usados" value={formatVolumeM3(containerVolumeSummary?.usedM3 ?? 0)} tone="blue" /><Metric label="m³ libres" value={formatVolumeM3(containerVolumeSummary?.freeM3 ?? 0)} tone="green" /></div><div className="border-t border-slate-200 pt-4 text-sm leading-7 text-slate-600"><p><strong>Distribución:</strong> {looseContainerResult.plans.map((plan) => `${plan.boxes.length} caja(s) sueltas en contenedor ${plan.containerIndex + 1}`).join(' · ')}</p><p><strong>Tipos de SKU:</strong> {looseContainerResult.totalBoxTypes} · <strong>Uso de piso del contenedor 1:</strong> {looseContainerResult.plans[0]?.floorUtilizationPercentage.toFixed(1) ?? '0.0'}%</p></div></div>}
              </section>
            </div>

            {containerResult && containerResult.warnings.length > 0 && <div className="space-y-2">{containerResult.warnings.map((warning) => <div key={warning} className="flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800"><AlertTriangle className="h-4 w-4 shrink-0" /> {warning}</div>)}</div>}
            {looseContainerResult && looseContainerResult.warnings.length > 0 && <div className="space-y-2">{looseContainerResult.warnings.map((warning) => <div key={warning} className="flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800"><AlertTriangle className="h-4 w-4 shrink-0" /> {warning}</div>)}</div>}

            {selectedLoadMetrics && <ContainerOperationalMetrics metrics={selectedLoadMetrics} container={containerResult?.container ?? looseContainerResult?.container ?? selectedContainer} />}

            {containerResult && <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><div className="mb-5 flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-blue-700">Plan de carga / 04</p><h2 className="mt-1 font-poppins text-xl font-bold">Contenedores generados</h2><p className="mt-1 text-sm text-slate-500">Selecciona un contenedor para inspeccionar sus paletas en la vista 3D.</p></div><span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">{containerResult.containersNeeded} unidad(es)</span></div><div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">{containerResult.plans.map((plan, index) => <button type="button" key={plan.containerIndex} onClick={() => { setSelectedContainerPlan(index); setSelectedContainerPalletId(null); setSelectedContainerBoxId(null) }} className={`rounded-xl border p-4 text-left transition ${index === selectedContainerPlan ? 'border-blue-600 bg-blue-50 shadow-sm' : 'border-slate-200 bg-slate-50 hover:border-blue-300 hover:bg-blue-50/50'}`}><div className="flex items-center justify-between gap-2"><span className="text-xs font-bold uppercase tracking-[0.12em] text-blue-700">Contenedor {index + 1}</span><span className="rounded-full bg-white px-2 py-1 text-[11px] font-semibold text-slate-600">Ver 3D</span></div><div className="mt-3 grid grid-cols-3 gap-2 text-sm"><span><strong className="block text-lg text-slate-900">{plan.pallets.length}</strong><small className="text-slate-500">paletas</small></span><span><strong className="block text-lg text-slate-900">{plan.totalWeight.toFixed(0)}</strong><small className="text-slate-500">kg</small></span><span><strong className="block text-lg text-slate-900">{plan.floorUtilizationPercentage.toFixed(1)}%</strong><small className="text-slate-500">piso</small></span></div>{plan.warnings.length > 0 && <p className="mt-3 text-xs font-medium text-amber-700">{plan.warnings[0]}</p>}</button>)}</div></section>}
            {looseContainerResult && <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><div className="mb-5 flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-blue-700">Plan de carga / 04</p><h2 className="mt-1 font-poppins text-xl font-bold">Contenedores con cajas sueltas</h2><p className="mt-1 text-sm text-slate-500">Selecciona una unidad para inspeccionar el acomodo individual y su etiqueta SKU en 3D.</p></div><span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">{looseContainerResult.containersNeeded} unidad(es)</span></div><div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">{looseContainerResult.plans.map((plan, index) => <button type="button" key={plan.containerIndex} onClick={() => { setSelectedContainerPlan(index); setSelectedContainerBoxId(null); setSelectedContainerPalletId(null) }} className={`rounded-xl border p-4 text-left transition ${index === selectedContainerPlan ? 'border-blue-600 bg-blue-50 shadow-sm' : 'border-slate-200 bg-slate-50 hover:border-blue-300 hover:bg-blue-50/50'}`}><div className="flex items-center justify-between gap-2"><span className="text-xs font-bold uppercase tracking-[0.12em] text-blue-700">Contenedor {index + 1}</span><span className="rounded-full bg-white px-2 py-1 text-[11px] font-semibold text-slate-600">Ver 3D</span></div><div className="mt-3 grid grid-cols-3 gap-2 text-sm"><span><strong className="block text-lg text-slate-900">{plan.boxes.length}</strong><small className="text-slate-500">cajas</small></span><span><strong className="block text-lg text-slate-900">{plan.totalWeight.toFixed(0)}</strong><small className="text-slate-500">kg</small></span><span><strong className="block text-lg text-slate-900">{plan.floorUtilizationPercentage.toFixed(1)}%</strong><small className="text-slate-500">piso</small></span></div>{plan.warnings.length > 0 && <p className="mt-3 text-xs font-medium text-amber-700">{plan.warnings[0]}</p>}</button>)}</div></section>}

            {activeContainerPlan && <ContainerVisualization3D container={containerResult?.container ?? selectedContainer} pallets={adjustedContainerPallets} originalPallets={activeContainerPlan.pallets} loadMetrics={activeContainerPlan.loadMetrics} selectedPalletId={selectedContainerPalletId} onPalletSelect={(id) => { setSelectedContainerPalletId(id); setSelectedContainerBoxId(null) }} onCargoAdjust={(id, adjustment) => handleManualCargoAdjust('container', id, adjustment)} />}
            {activeLooseContainerPlan && <ContainerVisualization3D container={looseContainerResult?.container ?? selectedContainer} pallets={[]} boxes={adjustedLooseBoxes} originalBoxes={activeLooseContainerPlan.boxes} loadMetrics={activeLooseContainerPlan.loadMetrics} selectedBoxId={selectedContainerBoxId} onBoxSelect={(id) => { setSelectedContainerBoxId(id); setSelectedContainerPalletId(null) }} onCargoAdjust={(id, adjustment) => handleManualCargoAdjust('loose', id, adjustment)} />}
          </div>
        )}

        {activeTab === 'compare' && reportAvailable && <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-5"><div className="flex items-start gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-md bg-slate-900 text-white"><BarChart3 className="h-5 w-5" /></span><div><p className="technical-stage-kicker">Salida operativa / 05</p><h2 className="mt-1 font-poppins text-2xl font-bold text-slate-900">Comparar y exportar plan</h2><p className="mt-1 max-w-2xl text-sm text-slate-600">El informe se habilita para el cálculo disponible, con o sin mezcla de SKU o plan de contenedor.</p></div></div><span className="rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 font-mono text-xs font-bold text-emerald-800">PLAN DISPONIBLE · {reportScope.toUpperCase()}</span></div><div className="mt-6 export-center grid gap-4 rounded-lg border border-slate-300 bg-slate-50 p-5 lg:grid-cols-[1fr_auto]"><div><p className="font-mono text-xs font-bold uppercase tracking-[0.14em] text-slate-700">Paquete de salida</p><p className="mt-2 text-sm leading-6 text-slate-600">{hasDetailedMixedReport ? 'El PDF y Excel incluyen el detalle completo de SKU, paletas fabricadas, posiciones físicas y el envío calculado.' : 'El PDF y Excel incluyen el resumen operativo del cálculo disponible, destino, medidas, peso, utilización y plan de envío cuando ya existe.'}</p>{!containerResult && !looseContainerResult && <p className="mt-2 text-xs font-medium text-amber-800">Puedes descargar ahora el resultado de paletización y añadir el plan de contenedor más adelante.</p>}</div><div className="flex flex-col gap-2 sm:flex-row lg:flex-col"><button type="button" onClick={handleDownloadLogisticsExcel} className="inline-flex items-center justify-center gap-2 rounded-md border border-emerald-700 bg-white px-4 py-3 text-xs font-bold uppercase tracking-[0.1em] text-emerald-800 transition hover:bg-emerald-50 active:scale-[0.98]"><FileSpreadsheet className="h-4 w-4" /> Descargar Excel</button><button type="button" onClick={handleDownloadLogisticsPdf} className="inline-flex items-center justify-center gap-2 rounded-md bg-blue-700 px-4 py-3 text-xs font-bold uppercase tracking-[0.1em] text-white transition hover:bg-blue-800 active:scale-[0.98]"><FileDown className="h-4 w-4" /> Descargar PDF</button></div></div></section>}
        {activeTab === 'compare' && !reportAvailable && <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-5"><div className="flex items-start gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-md bg-slate-900 text-white"><BarChart3 className="h-5 w-5" /></span><div><p className="technical-stage-kicker">Salida operativa / 05</p><h2 className="mt-1 font-poppins text-2xl font-bold text-slate-900">Comparar y exportar plan</h2><p className="mt-1 max-w-2xl text-sm text-slate-600">Calcula una paleta, mezcla o carga para habilitar el informe operativo.</p></div></div></div><div className="mt-6 rounded-lg border border-dashed border-slate-300 bg-slate-50 p-8 text-center"><p className="technical-stage-kicker">Plan pendiente</p><h3 className="mt-2 font-poppins text-xl font-bold text-slate-800">Realiza un cálculo antes de exportar</h3><p className="mx-auto mt-2 max-w-lg text-sm leading-6 text-slate-600">Las descargas se activarán al obtener un resultado válido de paleta simple, mezcla de cajas, carga paletizada o carga suelta.</p><div className="mt-5 flex flex-wrap justify-center gap-2"><button type="button" disabled className="inline-flex items-center gap-2 rounded-md border border-slate-300 bg-white px-4 py-3 text-xs font-bold uppercase tracking-[0.1em] text-slate-400"><FileSpreadsheet className="h-4 w-4" /> Excel no disponible</button><button type="button" disabled className="inline-flex items-center gap-2 rounded-md bg-slate-300 px-4 py-3 text-xs font-bold uppercase tracking-[0.1em] text-white"><FileDown className="h-4 w-4" /> PDF no disponible</button></div></div></section>}
      </main>
    </div>
  )
}

function ContainerEmptyState() {
  return <div className="relative flex h-full min-h-[300px] flex-col items-center justify-center overflow-hidden rounded-xl border border-slate-200 bg-slate-50/70 p-6 text-center"><div className="absolute inset-0 opacity-60" style={{ backgroundImage: 'linear-gradient(rgba(37,99,235,0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(37,99,235,0.07) 1px, transparent 1px)', backgroundSize: '28px 28px' }} /><div className="relative"><div className="mx-auto mb-5 flex h-24 w-48 items-end justify-center gap-2 rounded-xl border border-blue-200 bg-white/80 p-4 shadow-sm"><span className="h-12 w-12 rounded-md border-2 border-blue-300 bg-blue-100" /><span className="h-16 w-12 rounded-md border-2 border-cyan-300 bg-cyan-100" /><span className="h-10 w-12 rounded-md border-2 border-emerald-300 bg-emerald-100" /></div><p className="text-[10px] font-bold uppercase tracking-[0.22em] text-blue-700">Siguiente paso</p><h2 className="mt-2 font-poppins text-xl font-bold text-slate-800">Prepara la carga antes de enviarla</h2><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-slate-500">Calcula una paleta o selecciona una lista de productos. Después podrás ver la distribución interior del contenedor.</p><div className="mt-4 inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50 px-3 py-2 text-xs font-semibold text-blue-800"><ArrowRight className="h-4 w-4" /> Elige una fuente de carga a la izquierda</div></div></div>
}

function TechnicalEmptyState() {
  return <div className="empty-pallet-blueprint relative flex h-full min-h-[480px] flex-col items-center justify-center overflow-hidden rounded-xl border border-slate-300 p-8 text-left"><div className="absolute inset-x-8 top-9 border-t border-dashed border-slate-400"><span className="blueprint-axis-label absolute -top-4 left-0 bg-slate-50 px-1 text-slate-500">Eje X / Largo</span></div><div className="absolute bottom-10 left-8 top-10 border-l border-dashed border-slate-400"><span className="blueprint-axis-label absolute -left-1 top-2 -translate-x-full text-slate-500 [writing-mode:vertical-rl]">Eje Y / Ancho</span></div><div className="blueprint-reference absolute left-11 top-16">REFERENCIA / ORIGEN 0,0</div><div className="blueprint-reference absolute bottom-20 right-11">ZONA DE CARGA / A DEFINIR</div><div className="blueprint-scale-rail absolute bottom-9 right-9 flex items-center gap-2 border-t border-slate-400 pt-1 text-slate-500"><Ruler className="h-3.5 w-3.5" /> límite maniobrable / lado ≤ 1.70 m</div><div className="relative w-full max-w-md"><div className="relative mx-auto mb-9 grid h-40 w-72 grid-cols-8 gap-2 border-2 border-slate-500 bg-white/90 p-4 shadow-sm"><span className="blueprint-dimension absolute -top-5 left-1/2 -translate-x-1/2 whitespace-nowrap text-slate-600">Huella de paleta / plano base</span>{Array.from({ length: 32 }, (_, index) => <span key={index} className={`border ${index % 7 === 0 ? 'border-blue-500 bg-blue-100' : 'border-slate-300 bg-slate-50'}`} />)}</div><div className="blueprint-status border-l-2 border-slate-500 pl-3"><p className="technical-stage-kicker">Plano operativo / sin carga</p><p className="mt-1 font-mono text-sm font-bold text-slate-800">EJECUTAR CÁLCULO PARA GENERAR ACOMODO</p><p className="mt-1 max-w-sm text-xs leading-5 text-slate-600">La retícula conserva escala, ejes y límite de maniobra mientras se definen producto y base.</p></div></div></div>
}

function WorkflowHint({ activeTab }: { activeTab: 'products' | 'simple' | 'mixed' | 'containers' | 'compare' }) {
  const guidance = {
    products: { step: 'Paso 1 de 4', title: 'Definir productos', text: 'Importa o ajusta cajas antes de planificar la carga.', next: 'Aplicar a paletización o carga suelta.' },
    simple: { step: 'Paso 2 de 4', title: 'Definir paleta tipo', text: 'Medir caja y base para calcular capacidad por unidad.', next: 'Calcular disposición y enviar a contenedor.' },
    mixed: { step: 'Paso 2 de 4', title: 'Definir mezcla de SKU', text: 'Medir SKU, cantidades y restricciones para formar paletas mixtas.', next: 'Calcular, revisar paletas y preparar envío.' },
    containers: { step: 'Paso 3 de 4', title: 'Ubicar carga en envío', text: 'Seleccionar fuente y equipo para medir ocupación y estabilidad.', next: 'Inspeccionar métricas y exportar informe.' },
    compare: { step: 'Paso 4 de 4', title: 'Descarga informe', text: 'Revisar el plan consolidado y exportar los archivos operativos.', next: 'Descargar PDF o Excel, o regresar a cálculo.' },
  }[activeTab]
  return <section className="workflow-hint mb-5 flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white px-5 py-4 shadow-sm sm:flex-row sm:items-center sm:justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">{guidance.step}</p><h2 className="mt-1 text-lg font-bold text-slate-900">{guidance.title}</h2><p className="mt-1 text-sm text-slate-500">{guidance.text}</p></div><p className="max-w-sm rounded-xl bg-slate-50 px-3 py-2 text-xs leading-5 text-slate-500 sm:text-right"><strong className="text-slate-700">Siguiente:</strong> {guidance.next}</p></section>
}

function ContainerOperationalMetrics({ metrics, container }: { metrics: ContainerLoadMetrics; container: ContainerSpec }) {
  const longitudinalOffset = Math.abs(metrics.centerOfGravityPercentage.longitudinal - 50)
  const transversalOffset = Math.abs(metrics.centerOfGravityPercentage.transversal - 50)
  const balanceStatus = Math.max(longitudinalOffset, transversalOffset) <= 10 ? 'centrado' : 'desplazado'
  const balanceTone = balanceStatus === 'centrado' ? 'text-emerald-700' : 'text-amber-700'
  const meter = (millimeters: number) => `${(millimeters / 1000).toFixed(2)} m`

  return <section className="rounded-2xl border border-cyan-200 bg-gradient-to-br from-cyan-50 to-slate-50 p-5 shadow-sm"><div className="mb-4 flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-cyan-800">Estabilidad de carga / 05</p><h2 className="mt-1 font-poppins text-xl font-bold text-slate-900">Altura acumulada y centro de gravedad</h2><p className="mt-1 text-sm text-slate-600">Estimación geométrica por unidad ubicada dentro del contenedor seleccionado.</p></div><span className={`rounded-full border border-current bg-white/70 px-3 py-1 text-xs font-bold uppercase tracking-[0.1em] ${balanceTone}`}>CG {balanceStatus}</span></div><div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"><Metric label="Altura acumulada" value={`${meter(metrics.maxOccupiedHeight)}`} tone="blue" /><Metric label="Uso vertical" value={`${metrics.heightUtilizationPercentage.toFixed(1)}%`} tone="green" /><Metric label="CG longitudinal" value={meter(metrics.centerOfGravity.longitudinal)} tone="violet" /><Metric label="CG transversal" value={meter(metrics.centerOfGravity.transversal)} tone="orange" /></div><div className="mt-4 grid gap-3 border-t border-cyan-100 pt-4 text-sm text-slate-700 md:grid-cols-3"><p><strong>Altura libre:</strong> {meter(Math.max(0, container.height - metrics.maxOccupiedHeight))}</p><p><strong>CG vertical:</strong> {meter(metrics.centerOfGravity.vertical)} · {metrics.centerOfGravityPercentage.vertical.toFixed(1)}%</p><p><strong>Desvío del centro:</strong> X {longitudinalOffset.toFixed(1)}% · Z {transversalOffset.toFixed(1)}%</p></div>{metrics.usesUnitWeightFallback && <p className="mt-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs leading-5 text-amber-800">No se registraron pesos positivos; el centro de gravedad se estimó asignando la misma masa a cada unidad.</p>}</section>
}

function Metric({ label, value, tone }: { label: string; value: string | number; tone: 'blue' | 'green' | 'violet' | 'orange' }) {
  const tones = { blue: 'border-blue-200 bg-blue-50 text-blue-700', green: 'border-emerald-200 bg-emerald-50 text-emerald-700', violet: 'border-violet-200 bg-violet-50 text-violet-700', orange: 'border-orange-200 bg-orange-50 text-orange-700' }
  return <div className={`rounded-lg border p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${tones[tone]}`}><p className="font-mono text-[10px] font-bold uppercase tracking-[0.14em] opacity-75">{label}</p><p className="mt-2 font-mono text-[1.7rem] font-bold leading-none tabular-nums">{value}</p></div>
}

function PalletRecommendationPanel({ recommendations, destinationLabel, onApply }: { recommendations: PalletOptimizationRecommendation[]; destinationLabel: string; onApply: (recommendation: PalletOptimizationRecommendation) => void }) {
  const [selectedKey, setSelectedKey] = useState<string | null>(null)
  if (recommendations.length === 0) return <p className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs leading-5 text-amber-800">No se encontró una base maniobrable dentro del límite de {destinationLabel}. Activa “Permitir bases ampliadas” si la capacidad justifica superar 1,700 mm por lado.</p>

  return <section className="pallet-recommendation-chooser rounded-xl border border-slate-200 bg-white p-3"><div className="flex items-start justify-between gap-3"><div><p className="technical-stage-kicker">Optimización de base</p><p className="mt-1 text-[11px] leading-4 text-slate-500">Elige una alternativa para aplicarla a la paleta.</p></div><Ruler className="h-4 w-4 shrink-0 text-sky-600" /></div><div className="mt-3 space-y-1.5">{recommendations.map((recommendation, index) => { const key = `${recommendation.length}-${recommendation.width}-${index}`; const isSelected = key === selectedKey; return <button type="button" key={key} onClick={() => { setSelectedKey(key); onApply(recommendation) }} aria-pressed={isSelected} className={`recommendation-option w-full rounded-lg border px-3 py-2 text-left transition ${isSelected ? 'border-sky-400 bg-sky-50' : recommendation.isWithinManeuverabilityLimit ? 'border-slate-200 bg-white hover:border-sky-300 hover:bg-sky-50/50' : 'border-amber-300 bg-amber-50/70 hover:border-amber-400'}`}><div className="flex items-center justify-between gap-2"><div className="min-w-0"><p className="text-[9px] font-bold uppercase tracking-[0.12em] text-slate-400">{recommendation.isWithinManeuverabilityLimit ? (index === 0 ? 'Recomendada' : `Alternativa ${index + 1}`) : 'Base ampliada'}</p><p className="mt-0.5 font-mono text-sm font-bold text-slate-900">{recommendation.length.toLocaleString()} × {recommendation.width.toLocaleString()} mm</p></div><span className={`shrink-0 rounded-full px-2 py-1 text-[10px] font-bold ${isSelected ? 'bg-sky-500 text-white' : 'bg-slate-100 text-slate-600'}`}>{isSelected ? 'Aplicada' : 'Elegir'}</span></div><div className="mt-1.5 flex items-center gap-3 text-[10px] text-slate-500"><span><strong className="text-slate-800">{recommendation.boxesPerLevel}</strong> / nivel</span><span><strong className="text-slate-800">{recommendation.maxLevels}</strong> niveles</span><span><strong className="text-slate-800">{recommendation.surfaceUtilizationPercentage.toFixed(0)}%</strong> uso</span></div>{!recommendation.isWithinManeuverabilityLimit && <p className="mt-1 text-[10px] font-medium text-amber-800">Revisar equipo de movimiento.</p>}</button> })}</div></section>
}
