// Estilo: Modernismo Industrial Funcional; cálculo determinista, restricciones explícitas y métricas reutilizables por la vista 3D.

/* Estilo: Plano de Carga Guiado; las recomendaciones convierten dimensiones de producto y destino en una base de paleta justificable. */
export interface BoxDimensions {
  length: number
  width: number
  height: number
  weight: number
}

export interface PalletDimensions {
  length: number
  width: number
  height: number
  baseHeight?: number
  maxWeight: number
}

export interface BoxHandlingOptions {
  canStack: boolean
  allowHorizontalRotation: boolean
  allowVerticalRotation: boolean
}

export interface Arrangement {
  boxesAlongLength: number
  boxesAlongWidth: number
  totalLevels: number
}

export interface CalculationResult {
  totalBoxes: number
  totalWeight: number
  utilizationPercentage: number
  usedVolume: number
  palletVolume: number
  arrangement: Arrangement
  orientation: {
    description: string
    dimensions: BoxDimensions
  }
  warnings: string[]
}

export interface MixedBoxItem {
  id: string
  name: string
  boxDimensions: BoxDimensions
  quantity: number
  canStack: boolean
  allowHorizontalRotation: boolean
  allowVerticalRotation: boolean
}

export interface MixedBoxPlacement {
  placementId: string
  boxId: string
  boxName: string
  x: number
  y: number
  z: number
  width: number
  height: number
  depth: number
  canStack: boolean
}

export interface MixedPalletResult {
  palletIndex: number
  totalBoxes: number
  totalWeight: number
  utilizationPercentage: number
  fabricatedPallet: FabricatedPalletDimensions
  boxDistribution: Array<{
    boxId: string
    boxName: string
    quantity: number
    weight: number
    percentage: number
  }>
  boxPlacements: MixedBoxPlacement[]
  warnings: string[]
}

export interface FabricatedPalletDimensions extends PalletDimensions {
  originalLength: number
  originalWidth: number
  occupiedLength: number
  occupiedWidth: number
  materialSavingsPercentage: number
  isReduced: boolean
}

export interface MixedBoxResult {
  totalBoxes: number
  totalWeight: number
  utilizationPercentage: number
  usedVolume: number
  palletVolume: number
  palletsNeeded: number
  boxDistribution: Array<{
    boxId: string
    boxName: string
    quantity: number
    weight: number
    percentage: number
  }>
  boxPlacements: MixedBoxPlacement[]
  pallets: MixedPalletResult[]
  unplacedBoxes: number
  stackingMode: string
  warnings: string[]
}

export interface PalletOptimizationConstraints {
  maxTotalHeight: number
  baseHeight: number
  maxWeight: number
  maxLength: number
  maxWidth: number
  preferredMaxSide?: number
  allowOversize?: boolean
}

export interface PalletOptimizationRecommendation {
  length: number
  width: number
  totalHeight: number
  baseHeight: number
  maxWeight: number
  boxesPerLevel: number
  maxLevels: number
  boxesPerPallet: number
  surfaceUtilizationPercentage: number
  volumeUtilizationPercentage: number
  orientationDescription: string
  isWithinManeuverabilityLimit: boolean
  estimatedPalletsNeeded?: number
  placedBoxes?: number
}

export function calculatePalletArrangement(
  box: BoxDimensions,
  pallet: PalletDimensions,
  options: BoxHandlingOptions = { canStack: true, allowHorizontalRotation: true, allowVerticalRotation: false },
): CalculationResult | null {
  const orientations = [
    { l: box.length, w: box.width, h: box.height, name: 'Horizontal (Altura mínima)' },
    ...(options.allowHorizontalRotation ? [{ l: box.width, w: box.length, h: box.height, name: 'Rotación horizontal' }] : []),
    ...(options.allowVerticalRotation ? [
      { l: box.length, w: box.height, h: box.width, name: 'Rotación vertical 1' },
      { l: box.width, w: box.height, h: box.length, name: 'Rotación vertical 2' },
      { l: box.height, w: box.length, h: box.width, name: 'Rotación vertical 3' },
      { l: box.height, w: box.width, h: box.length, name: 'Rotación vertical 4' },
    ] : []),
  ]

  let bestResult: CalculationResult | null = null
  let maxBoxes = 0

  for (const orientation of orientations) {
    const boxesAlongLength = Math.floor(pallet.length / orientation.l)
    const boxesAlongWidth = Math.floor(pallet.width / orientation.w)
    if (boxesAlongLength === 0 || boxesAlongWidth === 0) continue

    const maxHeight = pallet.height - Math.max(0, pallet.baseHeight ?? 50)
    const totalLevels = options.canStack ? Math.floor(maxHeight / orientation.h) : Math.min(1, Math.floor(maxHeight / orientation.h))
    if (totalLevels === 0) continue

    const totalBoxes = boxesAlongLength * boxesAlongWidth * totalLevels
    const totalWeight = totalBoxes * box.weight
    if (totalWeight > pallet.maxWeight) continue

    if (totalBoxes > maxBoxes) {
      maxBoxes = totalBoxes
      const usedVolume = totalBoxes * (orientation.l * orientation.w * orientation.h)
      const palletVolume = pallet.length * pallet.width * pallet.height
      const utilizationPercentage = (usedVolume / palletVolume) * 100

      bestResult = {
        totalBoxes,
        totalWeight,
        utilizationPercentage,
        usedVolume,
        palletVolume,
        arrangement: { boxesAlongLength, boxesAlongWidth, totalLevels },
        orientation: {
          description: orientation.name,
          dimensions: { length: orientation.l, width: orientation.w, height: orientation.h, weight: box.weight },
        },
        warnings: [],
      }
    }
  }

  return bestResult
}

type ExpandedBox = MixedBoxItem & { instanceId: string }

type PlacementPlan = {
  placements: MixedBoxPlacement[]
  unplacedItems: ExpandedBox[]
  loadWeight: number
}

type Orientation = { length: number; width: number; height: number }

type MixedPlacementCandidate = {
  x: number
  y: number
  z: number
  orientation: Orientation
}

const PALLET_BASE_HEIGHT = 50
const MAX_GENERATED_PALLETS = 100
const PALLET_MANUFACTURING_MARGIN = 50
const PALLET_MANUFACTURING_INCREMENT = 50

function roundUpToManufacturingIncrement(value: number) {
  return Math.ceil(value / PALLET_MANUFACTURING_INCREMENT) * PALLET_MANUFACTURING_INCREMENT
}

function createFabricatedPallet(placements: MixedBoxPlacement[], pallet: PalletDimensions) {
  const occupiedLength = Math.max(...placements.map((placement) => placement.x + placement.width), 0)
  const occupiedWidth = Math.max(...placements.map((placement) => placement.z + placement.depth), 0)
  const length = Math.min(pallet.length, roundUpToManufacturingIncrement(occupiedLength + PALLET_MANUFACTURING_MARGIN * 2))
  const width = Math.min(pallet.width, roundUpToManufacturingIncrement(occupiedWidth + PALLET_MANUFACTURING_MARGIN * 2))
  const offsetX = length < pallet.length ? PALLET_MANUFACTURING_MARGIN : 0
  const offsetZ = width < pallet.width ? PALLET_MANUFACTURING_MARGIN : 0
  const originalArea = pallet.length * pallet.width
  const fabricatedArea = length * width
  const fabricatedPallet: FabricatedPalletDimensions = {
    length,
    width,
    height: pallet.height,
    baseHeight: pallet.baseHeight,
    maxWeight: pallet.maxWeight,
    originalLength: pallet.length,
    originalWidth: pallet.width,
    occupiedLength,
    occupiedWidth,
    materialSavingsPercentage: originalArea > 0 ? ((originalArea - fabricatedArea) / originalArea) * 100 : 0,
    isReduced: length < pallet.length || width < pallet.width,
  }

  return {
    fabricatedPallet,
    placements: placements.map((placement) => ({ ...placement, x: placement.x + offsetX, z: placement.z + offsetZ })),
  }
}

function getCompactBaseCandidates(items: ExpandedBox[], pallet: PalletDimensions) {
  const lengths = new Set<number>([pallet.length])
  const widths = new Set<number>([pallet.width])
  const copies = Math.min(12, items.length)

  for (const item of items) {
    for (const orientation of findOrientations(item)) {
      for (let count = 1; count <= copies; count += 1) {
        const length = roundUpToManufacturingIncrement(orientation.length * count)
        const width = roundUpToManufacturingIncrement(orientation.width * count)
        if (length <= pallet.length) lengths.add(length)
        if (width <= pallet.width) widths.add(width)
      }
    }
  }

  return Array.from(lengths).flatMap((length) => Array.from(widths)
    .filter((width) => length <= pallet.length && width <= pallet.width)
    .map((width) => ({ length, width })))
    .sort((left, right) => left.length * left.width - right.length * right.width || left.length - right.length)
}

function compactPlacementPlan(placements: MixedBoxPlacement[], mixedBoxes: MixedBoxItem[], pallet: PalletDimensions) {
  const items = placements.map((placement) => {
    const source = mixedBoxes.find((item) => item.id === placement.boxId)
    if (!source) return null
    return { ...source, instanceId: placement.placementId }
  }).filter((item): item is ExpandedBox => item !== null)

  let best = createFabricatedPallet(placements, pallet)
  let bestArea = best.fabricatedPallet.length * best.fabricatedPallet.width

  for (const candidate of getCompactBaseCandidates(items, pallet)) {
    const candidatePlan = createPlacementPlan(items, { ...pallet, ...candidate })
    if (candidatePlan.unplacedItems.length > 0 || candidatePlan.placements.length !== items.length) continue

    const manufactured = createFabricatedPallet(candidatePlan.placements, pallet)
    const area = manufactured.fabricatedPallet.length * manufactured.fabricatedPallet.width
    if (area < bestArea || (area === bestArea && manufactured.fabricatedPallet.length + manufactured.fabricatedPallet.width < best.fabricatedPallet.length + best.fabricatedPallet.width)) {
      best = manufactured
      bestArea = area
    }
  }

  return best
}

function mixedFitsAt(
  dimensions: Orientation,
  item: ExpandedBox,
  candidate: MixedPlacementCandidate,
  pallet: PalletDimensions,
  loadWeight: number,
) {
  const palletBaseHeight = Math.max(0, pallet.baseHeight ?? PALLET_BASE_HEIGHT)
  const canUseUpperLevel = item.canStack || candidate.y === palletBaseHeight
  return (
    canUseUpperLevel &&
    candidate.x >= 0 &&
    candidate.y >= palletBaseHeight &&
    candidate.z >= 0 &&
    candidate.x + dimensions.length <= pallet.length &&
    candidate.z + dimensions.width <= pallet.width &&
    candidate.y + dimensions.height <= pallet.height &&
    loadWeight + item.boxDimensions.weight <= pallet.maxWeight
  )
}

function uniqueOrientations(options: Orientation[]) {
  const seen = new Set<string>()
  return options.filter((option) => {
    const key = `${option.length}-${option.width}-${option.height}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })
}

function findOrientations(item: ExpandedBox): Orientation[] {
  const { length, width, height } = item.boxDimensions
  const options: Orientation[] = [{ length, width, height }]

  if (item.allowHorizontalRotation) {
    options.push({ length: width, width: length, height })
  }

  if (item.allowVerticalRotation) {
    options.push(
      { length, width: height, height: width },
      { length: height, width, height: length },
      { length: width, width: height, height: length },
      { length: height, width: length, height: width },
    )
  }

  return uniqueOrientations(options)
}

function expandMixedBoxes(mixedBoxes: MixedBoxItem[]): ExpandedBox[] {
  return mixedBoxes.flatMap((item) => Array.from({ length: Math.max(0, Math.floor(item.quantity)) }, (_, index) => ({
    ...item,
    instanceId: `${item.id}-${index}`,
  })))
}

function intervalsOverlap(startA: number, sizeA: number, startB: number, sizeB: number) {
  return startA < startB + sizeB && startA + sizeA > startB
}

function uniqueSorted(values: number[]) {
  return [...new Set(values.map((value) => Math.round(value * 1000) / 1000))].sort((a, b) => a - b)
}

function overlapsMixedPlacement(candidate: MixedPlacementCandidate, placement: MixedBoxPlacement) {
  return intervalsOverlap(candidate.x, candidate.orientation.length, placement.x, placement.width) &&
    intervalsOverlap(candidate.y, candidate.orientation.height, placement.y, placement.height) &&
    intervalsOverlap(candidate.z, candidate.orientation.width, placement.z, placement.depth)
}

function hasContinuousSupport(candidate: MixedPlacementCandidate, placements: MixedBoxPlacement[], palletBaseHeight: number) {
  if (candidate.y === palletBaseHeight) return true

  const candidateEndX = candidate.x + candidate.orientation.length
  const candidateEndZ = candidate.z + candidate.orientation.width
  const supporters = placements.filter((placement) => {
    const top = placement.y + placement.height
    return placement.canStack && top === candidate.y &&
      intervalsOverlap(candidate.x, candidate.orientation.length, placement.x, placement.width) &&
      intervalsOverlap(candidate.z, candidate.orientation.width, placement.z, placement.depth)
  })
  if (supporters.length === 0) return false

  const xBoundaries = uniqueSorted([candidate.x, candidateEndX, ...supporters.flatMap((placement) => [Math.max(candidate.x, placement.x), Math.min(candidateEndX, placement.x + placement.width)])])
  const zBoundaries = uniqueSorted([candidate.z, candidateEndZ, ...supporters.flatMap((placement) => [Math.max(candidate.z, placement.z), Math.min(candidateEndZ, placement.z + placement.depth)])])

  for (let xIndex = 0; xIndex < xBoundaries.length - 1; xIndex += 1) {
    for (let zIndex = 0; zIndex < zBoundaries.length - 1; zIndex += 1) {
      const left = xBoundaries[xIndex]
      const right = xBoundaries[xIndex + 1]
      const front = zBoundaries[zIndex]
      const back = zBoundaries[zIndex + 1]
      if (right <= left || back <= front) continue
      const covered = supporters.some((support) => left >= support.x && right <= support.x + support.width && front >= support.z && back <= support.z + support.depth)
      if (!covered) return false
    }
  }

  return true
}

function findMixedPlacement(item: ExpandedBox, placements: MixedBoxPlacement[], pallet: PalletDimensions, loadWeight: number) {
  const palletBaseHeight = Math.max(0, pallet.baseHeight ?? PALLET_BASE_HEIGHT)
  const xPositions = uniqueSorted([0, ...placements.flatMap((placement) => [placement.x, placement.x + placement.width])])
  const zPositions = uniqueSorted([0, ...placements.flatMap((placement) => [placement.z, placement.z + placement.depth])])
  const yPositions = uniqueSorted([palletBaseHeight, ...placements.filter((placement) => placement.canStack).map((placement) => placement.y + placement.height)])

  for (const y of yPositions) {
    for (const z of zPositions) {
      for (const x of xPositions) {
        for (const orientation of findOrientations(item)) {
          const candidate: MixedPlacementCandidate = { x, y, z, orientation }
          if (!mixedFitsAt(orientation, item, candidate, pallet, loadWeight)) continue
          if (!hasContinuousSupport(candidate, placements, palletBaseHeight)) continue
          if (placements.some((placement) => overlapsMixedPlacement(candidate, placement))) continue
          return candidate
        }
      }
    }
  }

  return null
}

export function findUnsupportedMixedPlacements(placements: MixedBoxPlacement[], pallet: PalletDimensions) {
  const palletBaseHeight = Math.max(0, pallet.baseHeight ?? PALLET_BASE_HEIGHT)
  const accepted: MixedBoxPlacement[] = []
  const unsupported: string[] = []

  for (const placement of [...placements].sort((left, right) => left.y - right.y)) {
    const candidate: MixedPlacementCandidate = { x: placement.x, y: placement.y, z: placement.z, orientation: { length: placement.width, width: placement.depth, height: placement.height } }
    if (!hasContinuousSupport(candidate, accepted, palletBaseHeight)) unsupported.push(placement.placementId)
    else accepted.push(placement)
  }

  return unsupported
}

function createPlacementPlan(expanded: ExpandedBox[], pallet: PalletDimensions): PlacementPlan {
  const ordered = [...expanded].sort((a, b) => {
    const stackOrder = Number(a.canStack) - Number(b.canStack)
    const areaA = a.boxDimensions.length * a.boxDimensions.width
    const areaB = b.boxDimensions.length * b.boxDimensions.width
    return stackOrder || areaB - areaA || b.boxDimensions.height - a.boxDimensions.height
  })
  const placements: MixedBoxPlacement[] = []
  const unplacedItems: ExpandedBox[] = []
  let loadWeight = 0

  for (const item of ordered) {
    const candidate = findMixedPlacement(item, placements, pallet, loadWeight)
    if (!candidate) {
      unplacedItems.push(item)
      continue
    }

    placements.push({
      placementId: item.instanceId,
      boxId: item.id,
      boxName: item.name,
      x: candidate.x,
      y: candidate.y,
      z: candidate.z,
      width: candidate.orientation.length,
      height: candidate.orientation.height,
      depth: candidate.orientation.width,
      canStack: item.canStack,
    })
    loadWeight += item.boxDimensions.weight
  }

  const unsupportedIds = new Set(findUnsupportedMixedPlacements(placements, pallet))
  if (unsupportedIds.size > 0) {
    const rejected = placements.filter((placement) => unsupportedIds.has(placement.placementId))
    const rejectedItems = rejected.map((placement) => expanded.find((item) => item.instanceId === placement.placementId)).filter((item): item is ExpandedBox => Boolean(item))
    return {
      placements: placements.filter((placement) => !unsupportedIds.has(placement.placementId)),
      unplacedItems: [...unplacedItems, ...rejectedItems],
      loadWeight: loadWeight - rejectedItems.reduce((sum, item) => sum + item.boxDimensions.weight, 0),
    }
  }

  return { placements, unplacedItems, loadWeight }
}

function aggregateDistribution(items: ExpandedBox[], totalWeight: number) {
  const grouped = new Map<string, { boxId: string; boxName: string; quantity: number; weight: number; percentage: number }>()
  for (const item of items) {
    const current = grouped.get(item.id) ?? { boxId: item.id, boxName: item.name, quantity: 0, weight: 0, percentage: 0 }
    current.quantity += 1
    current.weight += item.boxDimensions.weight
    grouped.set(item.id, current)
  }
  return Array.from(grouped.values()).map((item) => ({ ...item, percentage: totalWeight > 0 ? (item.weight / totalWeight) * 100 : 0 }))
}

function aggregatePlacedDistribution(placements: MixedBoxPlacement[], mixedBoxes: MixedBoxItem[], palletWeight: number) {
  const grouped = new Map<string, { boxId: string; boxName: string; quantity: number; weight: number; percentage: number }>()
  for (const placement of placements) {
    const source = mixedBoxes.find((item) => item.id === placement.boxId)
    const current = grouped.get(placement.boxId) ?? { boxId: placement.boxId, boxName: placement.boxName, quantity: 0, weight: 0, percentage: 0 }
    current.quantity += 1
    current.weight += source?.boxDimensions.weight ?? 0
    grouped.set(placement.boxId, current)
  }
  return Array.from(grouped.values()).map((item) => ({ ...item, percentage: palletWeight > 0 ? (item.weight / palletWeight) * 100 : 0 }))
}

export function createMixedBoxPlacements(
  mixedBoxes: MixedBoxItem[],
  pallet: PalletDimensions,
): { placements: MixedBoxPlacement[]; unplacedBoxes: number } {
  const plan = createPlacementPlan(expandMixedBoxes(mixedBoxes), pallet)
  return { placements: plan.placements, unplacedBoxes: plan.unplacedItems.length }
}

export function calculateMixedBoxArrangement(
  mixedBoxes: MixedBoxItem[],
  pallet: PalletDimensions,
): MixedBoxResult | null {
  if (mixedBoxes.length === 0) return null

  const expanded = expandMixedBoxes(mixedBoxes)
  const totalBoxes = expanded.length
  const totalWeight = expanded.reduce((sum, item) => sum + item.boxDimensions.weight, 0)
  const totalVolume = expanded.reduce((sum, item) => sum + item.boxDimensions.length * item.boxDimensions.width * item.boxDimensions.height, 0)
  const palletVolume = pallet.length * pallet.width * pallet.height
  const pallets: MixedPalletResult[] = []
  let remaining = expanded

  while (remaining.length > 0 && pallets.length < MAX_GENERATED_PALLETS) {
    const plan = createPlacementPlan(remaining, pallet)
    if (plan.placements.length === 0) break

    const manufacturingPlan = compactPlacementPlan(plan.placements, mixedBoxes, pallet)
    const palletWeight = manufacturingPlan.placements.reduce((sum, placement) => {
      const source = mixedBoxes.find((item) => item.id === placement.boxId)
      return sum + (source?.boxDimensions.weight ?? 0)
    }, 0)
    const palletVolumeUsed = manufacturingPlan.placements.reduce((sum, placement) => sum + placement.width * placement.height * placement.depth, 0)
    const fabricatedVolume = manufacturingPlan.fabricatedPallet.length * manufacturingPlan.fabricatedPallet.width * manufacturingPlan.fabricatedPallet.height

    pallets.push({
      palletIndex: pallets.length,
      totalBoxes: plan.placements.length,
      totalWeight: palletWeight,
      utilizationPercentage: fabricatedVolume > 0 ? (palletVolumeUsed / fabricatedVolume) * 100 : 0,
      fabricatedPallet: manufacturingPlan.fabricatedPallet,
      boxDistribution: aggregatePlacedDistribution(manufacturingPlan.placements, mixedBoxes, palletWeight),
      boxPlacements: manufacturingPlan.placements,
      warnings: plan.unplacedItems.length > 0 ? [`${plan.unplacedItems.length} caja(s) no pudieron ubicarse en esta paleta`] : [],
    })
    remaining = plan.unplacedItems
  }

  const unplacedBoxes = remaining.length
  const palletsNeeded = pallets.length
  const remainingWeight = remaining.reduce((sum, item) => sum + item.boxDimensions.weight, 0)
  const placedItems = expanded.filter((item) => !remaining.some((left) => left.instanceId === item.instanceId))
  const overallDistribution = aggregateDistribution(placedItems, totalWeight - remainingWeight)
  const warnings: string[] = []

  if (totalWeight > pallet.maxWeight) {
    warnings.push(`La carga total (${totalWeight.toFixed(2)} kg) requiere distribuirse en varias paletas`)
  }

  if (totalVolume > palletVolume) {
    warnings.push('El volumen total de las cajas supera el volumen de la paleta')
  }

  if (palletsNeeded > 1) {
    warnings.push(`La carga supera la capacidad de una sola paleta; se generaron ${palletsNeeded} paletas para distribuir el excedente`)
  }

  if (unplacedBoxes > 0) {
    warnings.push(`${unplacedBoxes} caja(s) no pudieron ubicarse en ninguna paleta por dimensiones, peso o restricciones de apilamiento/rotación`)
  }

  const placedVolume = totalVolume - remaining.reduce((sum, item) => sum + item.boxDimensions.length * item.boxDimensions.width * item.boxDimensions.height, 0)
  const totalFabricatedVolume = pallets.reduce((sum, palletPlan) => sum + palletPlan.fabricatedPallet.length * palletPlan.fabricatedPallet.width * palletPlan.fabricatedPallet.height, 0)
  const utilizationPercentage = totalFabricatedVolume > 0 ? (placedVolume / totalFabricatedVolume) * 100 : 0

  return {
    totalBoxes,
    totalWeight,
    utilizationPercentage,
    usedVolume: totalVolume,
    palletVolume,
    palletsNeeded,
    boxDistribution: overallDistribution,
    boxPlacements: pallets[0]?.boxPlacements ?? [],
    pallets,
    unplacedBoxes,
    stackingMode: palletsNeeded > 1 ? 'Distribución automática en varias paletas con apoyo físico validado' : 'Distribución por superficies físicas con apoyo completo y restricciones por SKU',
    warnings,
  }
}

export function calculatePalletsNeeded(totalBoxes: number, boxesPerPallet: number): number {
  return Math.ceil(totalBoxes / boxesPerPallet)
}

export function recommendPalletDimensions(_box: BoxDimensions, maxHeight: number = 2400): PalletDimensions[] {
  return [
    { length: 1200, width: 800, height: maxHeight, baseHeight: 50, maxWeight: 1000 },
    { length: 1200, width: 1000, height: maxHeight, baseHeight: 50, maxWeight: 1000 },
    { length: 1400, width: 1200, height: maxHeight, baseHeight: 50, maxWeight: 1500 },
  ]
}

type RecommendationOrientation = Orientation & { description: string }

function getRecommendationOrientations(box: BoxDimensions, options: BoxHandlingOptions): RecommendationOrientation[] {
  const orientations: RecommendationOrientation[] = [{ length: box.length, width: box.width, height: box.height, description: 'Orientación original' }]
  if (options.allowHorizontalRotation) orientations.push({ length: box.width, width: box.length, height: box.height, description: 'Rotación horizontal' })
  if (options.allowVerticalRotation) {
    orientations.push(
      { length: box.length, width: box.height, height: box.width, description: 'Rotación vertical' },
      { length: box.width, width: box.height, height: box.length, description: 'Rotación vertical' },
      { length: box.height, width: box.length, height: box.width, description: 'Rotación vertical' },
      { length: box.height, width: box.width, height: box.length, description: 'Rotación vertical' },
    )
  }
  const seen = new Set<string>()
  return orientations.filter((orientation) => {
    const key = `${orientation.length}-${orientation.width}-${orientation.height}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })
}

function rankRecommendations(recommendations: PalletOptimizationRecommendation[]) {
  return [...recommendations].sort((left, right) => {
    const maneuverabilityDifference = Number(right.isWithinManeuverabilityLimit) - Number(left.isWithinManeuverabilityLimit)
    if (maneuverabilityDifference !== 0) return maneuverabilityDifference
    const densityDifference = right.volumeUtilizationPercentage - left.volumeUtilizationPercentage
    if (Math.abs(densityDifference) > 0.01) return densityDifference
    const capacityDifference = right.boxesPerPallet - left.boxesPerPallet
    if (capacityDifference !== 0) return capacityDifference
    return left.length * left.width - right.length * right.width
  })
}

export function recommendOptimizedPalletDimensions(
  box: BoxDimensions,
  options: BoxHandlingOptions,
  constraints: PalletOptimizationConstraints,
): PalletOptimizationRecommendation[] {
  const availableLoadHeight = Math.max(0, constraints.maxTotalHeight - constraints.baseHeight)
  const preferredMaxSide = constraints.preferredMaxSide ?? Number.POSITIVE_INFINITY
  const candidates = new Map<string, PalletOptimizationRecommendation>()

  for (const orientation of getRecommendationOrientations(box, options)) {
    const maxAlongLength = Math.min(5, Math.floor(constraints.maxLength / orientation.length))
    const maxAlongWidth = Math.min(5, Math.floor(constraints.maxWidth / orientation.width))
    if (maxAlongLength < 1 || maxAlongWidth < 1 || availableLoadHeight < orientation.height) continue

    for (let alongLength = 1; alongLength <= maxAlongLength; alongLength += 1) {
      for (let alongWidth = 1; alongWidth <= maxAlongWidth; alongWidth += 1) {
        const length = alongLength * orientation.length
        const width = alongWidth * orientation.width
        const isWithinManeuverabilityLimit = length <= preferredMaxSide && width <= preferredMaxSide
        if (!constraints.allowOversize && !isWithinManeuverabilityLimit) continue
        const boxesPerLevel = alongLength * alongWidth
        const levelsByHeight = options.canStack ? Math.floor(availableLoadHeight / orientation.height) : 1
        const levelsByWeight = box.weight > 0 ? Math.floor(constraints.maxWeight / (box.weight * boxesPerLevel)) : levelsByHeight
        const maxLevels = Math.max(0, Math.min(levelsByHeight, levelsByWeight))
        if (maxLevels < 1) continue

        const boxesPerPallet = boxesPerLevel * maxLevels
        const usedVolume = boxesPerPallet * orientation.length * orientation.width * orientation.height
        const palletVolume = length * width * constraints.maxTotalHeight
        const recommendation: PalletOptimizationRecommendation = {
          length,
          width,
          totalHeight: constraints.maxTotalHeight,
          baseHeight: constraints.baseHeight,
          maxWeight: constraints.maxWeight,
          boxesPerLevel,
          maxLevels,
          boxesPerPallet,
          surfaceUtilizationPercentage: (boxesPerLevel * orientation.length * orientation.width / (length * width)) * 100,
          volumeUtilizationPercentage: palletVolume > 0 ? (usedVolume / palletVolume) * 100 : 0,
          orientationDescription: orientation.description,
          isWithinManeuverabilityLimit,
        }
        const key = `${length}-${width}`
        const current = candidates.get(key)
        if (!current || rankRecommendations([recommendation, current])[0] === recommendation) candidates.set(key, recommendation)
      }
    }
  }

  const ranked = rankRecommendations(Array.from(candidates.values()))
  if (!constraints.allowOversize) return ranked.slice(0, 3)

  const maneuverable = ranked.filter((recommendation) => recommendation.isWithinManeuverabilityLimit)
  const oversize = ranked.filter((recommendation) => !recommendation.isWithinManeuverabilityLimit)
  return [...maneuverable.slice(0, 2), ...oversize.slice(0, 1)].slice(0, 3)
}

export function recommendMixedPalletDimensions(
  mixedBoxes: MixedBoxItem[],
  constraints: PalletOptimizationConstraints,
): PalletOptimizationRecommendation[] {
  const representativeBoxes = [...mixedBoxes]
    .filter((item) => item.quantity > 0)
    .sort((left, right) => right.boxDimensions.length * right.boxDimensions.width - left.boxDimensions.length * left.boxDimensions.width)
    .slice(0, 8)
  const candidateBases = new Map<string, PalletOptimizationRecommendation>()

  representativeBoxes.forEach((item) => {
    recommendOptimizedPalletDimensions(item.boxDimensions, item, constraints).forEach((recommendation) => {
      candidateBases.set(`${recommendation.length}-${recommendation.width}`, recommendation)
    })
  })

  return Array.from(candidateBases.values())
    .map((candidate) => {
      const result = calculateMixedBoxArrangement(mixedBoxes, {
        length: candidate.length,
        width: candidate.width,
        height: candidate.totalHeight,
        baseHeight: candidate.baseHeight,
        maxWeight: candidate.maxWeight,
      })
      const placedBoxes = result ? result.totalBoxes - result.unplacedBoxes : 0
      return {
        ...candidate,
        estimatedPalletsNeeded: result?.palletsNeeded ?? Number.MAX_SAFE_INTEGER,
        placedBoxes,
        boxesPerPallet: result?.palletsNeeded ? Math.ceil(placedBoxes / result.palletsNeeded) : 0,
        volumeUtilizationPercentage: result?.utilizationPercentage ?? 0,
      }
    })
    .sort((left, right) => (right.placedBoxes ?? 0) - (left.placedBoxes ?? 0) || (left.estimatedPalletsNeeded ?? 0) - (right.estimatedPalletsNeeded ?? 0) || right.volumeUtilizationPercentage - left.volumeUtilizationPercentage || left.length * left.width - right.length * right.width)
    .slice(0, 3)
}
