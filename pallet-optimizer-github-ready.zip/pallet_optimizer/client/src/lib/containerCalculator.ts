// Estilo: Modernismo Industrial Funcional; el plan de contenedores prioriza restricciones explícitas, trazabilidad de cada paleta y métricas operativas.

export interface ContainerSpec {
  id: string
  name: string
  length: number
  width: number
  height: number
  maxWeight: number
  note: string
}

export interface ContainerPalletInput {
  id: string
  label: string
  length: number
  width: number
  height: number
  weight: number
  color: string
  sourceIndex: number
}

export interface ContainerPalletPlacement extends ContainerPalletInput {
  x: number
  y: number
  z: number
  placedLength: number
  placedWidth: number
}

export interface ContainerLoadMetrics {
  maxOccupiedHeight: number
  heightUtilizationPercentage: number
  centerOfGravity: {
    longitudinal: number
    transversal: number
    vertical: number
  }
  centerOfGravityPercentage: {
    longitudinal: number
    transversal: number
    vertical: number
  }
  usesUnitWeightFallback: boolean
}

export interface ContainerPlan {
  containerIndex: number
  pallets: ContainerPalletPlacement[]
  totalWeight: number
  floorUtilizationPercentage: number
  volumeUtilizationPercentage: number
  loadMetrics: ContainerLoadMetrics
  warnings: string[]
}

export interface ContainerLoadResult {
  container: ContainerSpec
  totalPallets: number
  totalWeight: number
  placedPallets: number
  unplacedPallets: number
  containersNeeded: number
  plans: ContainerPlan[]
  warnings: string[]
}

type PlacementState = {
  x: number
  z: number
  rowDepth: number
  totalWeight: number
}

type Orientation = {
  length: number
  width: number
}

type MetricPlacement = {
  x: number
  y: number
  z: number
  placedLength: number
  placedWidth: number
  height?: number
  placedHeight?: number
  weight: number
}

const MAX_GENERATED_CONTAINERS = 100

function calculateLoadMetrics(placements: MetricPlacement[], container: ContainerSpec): ContainerLoadMetrics {
  const maxOccupiedHeight = placements.reduce((maximum, item) => Math.max(maximum, item.y + (item.placedHeight ?? item.height ?? 0)), 0)
  const hasMeasuredWeight = placements.some((item) => item.weight > 0)
  const totalMass = placements.reduce((sum, item) => sum + (hasMeasuredWeight ? Math.max(0, item.weight) : 1), 0)
  const weightedCenter = placements.reduce((sum, item) => {
    const mass = hasMeasuredWeight ? Math.max(0, item.weight) : 1
    const itemHeight = item.placedHeight ?? item.height ?? 0
    return {
      longitudinal: sum.longitudinal + (item.x + item.placedLength / 2) * mass,
      transversal: sum.transversal + (item.z + item.placedWidth / 2) * mass,
      vertical: sum.vertical + (item.y + itemHeight / 2) * mass,
    }
  }, { longitudinal: 0, transversal: 0, vertical: 0 })
  const centerOfGravity = totalMass > 0
    ? { longitudinal: weightedCenter.longitudinal / totalMass, transversal: weightedCenter.transversal / totalMass, vertical: weightedCenter.vertical / totalMass }
    : { longitudinal: 0, transversal: 0, vertical: 0 }

  return {
    maxOccupiedHeight,
    heightUtilizationPercentage: container.height > 0 ? (maxOccupiedHeight / container.height) * 100 : 0,
    centerOfGravity,
    centerOfGravityPercentage: {
      longitudinal: container.length > 0 ? (centerOfGravity.longitudinal / container.length) * 100 : 0,
      transversal: container.width > 0 ? (centerOfGravity.transversal / container.width) * 100 : 0,
      vertical: container.height > 0 ? (centerOfGravity.vertical / container.height) * 100 : 0,
    },
    usesUnitWeightFallback: !hasMeasuredWeight && placements.length > 0,
  }
}

function orientationsFor(pallet: ContainerPalletInput): Orientation[] {
  const candidates = [
    { length: pallet.length, width: pallet.width },
    { length: pallet.width, width: pallet.length },
  ]
  const seen = new Set<string>()
  return candidates.filter((candidate) => {
    const key = `${candidate.length}-${candidate.width}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })
}

function fitsAt(pallet: ContainerPalletInput, orientation: Orientation, state: PlacementState, container: ContainerSpec) {
  return (
    orientation.length > 0 &&
    orientation.width > 0 &&
    pallet.height <= container.height &&
    state.totalWeight + pallet.weight <= container.maxWeight &&
    state.x + orientation.length <= container.length &&
    state.z + orientation.width <= container.width
  )
}

function createContainerPlan(pallets: ContainerPalletInput[], container: ContainerSpec, containerIndex: number) {
  const state: PlacementState = { x: 0, z: 0, rowDepth: 0, totalWeight: 0 }
  const placed: ContainerPalletPlacement[] = []
  const remaining: ContainerPalletInput[] = []

  for (const pallet of pallets) {
    let orientation = orientationsFor(pallet).find((candidate) => fitsAt(pallet, candidate, state, container))

    if (!orientation && state.x > 0) {
      state.x = 0
      state.z += state.rowDepth
      state.rowDepth = 0
      orientation = orientationsFor(pallet).find((candidate) => fitsAt(pallet, candidate, state, container))
    }

    if (!orientation) {
      remaining.push(pallet)
      continue
    }

    placed.push({
      ...pallet,
      x: state.x,
      y: 0,
      z: state.z,
      placedLength: orientation.length,
      placedWidth: orientation.width,
    })
    state.x += orientation.length
    state.rowDepth = Math.max(state.rowDepth, orientation.width)
    state.totalWeight += pallet.weight
  }

  const floorArea = container.length * container.width
  const volume = container.length * container.width * container.height
  const usedFloorArea = placed.reduce((sum, pallet) => sum + pallet.placedLength * pallet.placedWidth, 0)
  const usedVolume = placed.reduce((sum, pallet) => sum + pallet.placedLength * pallet.placedWidth * pallet.height, 0)

  const plan: ContainerPlan = {
    containerIndex,
    pallets: placed,
    totalWeight: state.totalWeight,
    floorUtilizationPercentage: floorArea > 0 ? (usedFloorArea / floorArea) * 100 : 0,
    volumeUtilizationPercentage: volume > 0 ? (usedVolume / volume) * 100 : 0,
    loadMetrics: calculateLoadMetrics(placed, container),
    warnings: [],
  }

  if (remaining.length > 0) {
    plan.warnings.push(`${remaining.length} paleta(s) no pudieron ubicarse en este contenedor`)
  }

  return { plan, remaining }
}

export function calculateContainerLoad(pallets: ContainerPalletInput[], container: ContainerSpec): ContainerLoadResult {
  const orderedPallets = [...pallets].sort((a, b) => b.weight - a.weight || b.length * b.width - a.length * a.width)
  const plans: ContainerPlan[] = []
  let remaining = orderedPallets

  while (remaining.length > 0 && plans.length < MAX_GENERATED_CONTAINERS) {
    const result = createContainerPlan(remaining, container, plans.length)
    if (result.plan.pallets.length === 0) {
      break
    }
    plans.push(result.plan)
    remaining = result.remaining
  }

  const placedPallets = plans.reduce((sum, plan) => sum + plan.pallets.length, 0)
  const totalWeight = orderedPallets.reduce((sum, pallet) => sum + pallet.weight, 0)
  const warnings: string[] = []

  if (plans.length > 1) {
    warnings.push(`La carga requiere ${plans.length} contenedor(es) para ubicar las ${orderedPallets.length} paletas`)
  }

  if (remaining.length > 0) {
    warnings.push(`${remaining.length} paleta(s) no pudieron ubicarse por dimensiones o peso máximo del contenedor`)
  }

  const hasDimensionMismatch = orderedPallets.some((pallet) => {
    const fitsNormal = pallet.length <= container.length && pallet.width <= container.width
    const fitsRotated = pallet.width <= container.length && pallet.length <= container.width
    return (!fitsNormal && !fitsRotated) || pallet.height > container.height
  })

  if (hasDimensionMismatch) {
    warnings.push('Al menos una paleta supera las dimensiones internas del contenedor seleccionado')
  }

  return {
    container,
    totalPallets: orderedPallets.length,
    totalWeight,
    placedPallets,
    unplacedPallets: remaining.length,
    containersNeeded: plans.length,
    plans,
    warnings,
  }
}


export interface ContainerLooseBoxInput {
  id: string
  label: string
  length: number
  width: number
  height: number
  weight: number
  color: string
  sourceIndex: number
  canStack: boolean
}

export interface ContainerLooseBoxPlacement extends ContainerLooseBoxInput {
  containerIndex: number
  x: number
  y: number
  z: number
  placedLength: number
  placedWidth: number
  placedHeight: number
}

export interface LooseContainerPlan {
  containerIndex: number
  boxes: ContainerLooseBoxPlacement[]
  totalWeight: number
  floorUtilizationPercentage: number
  volumeUtilizationPercentage: number
  loadMetrics: ContainerLoadMetrics
  warnings: string[]
}

export interface LooseContainerLoadResult {
  container: ContainerSpec
  totalBoxes: number
  totalBoxTypes: number
  totalWeight: number
  placedBoxes: number
  unplacedBoxes: number
  containersNeeded: number
  plans: LooseContainerPlan[]
  warnings: string[]
}

type LoosePlacementCandidate = {
  x: number
  y: number
  z: number
  orientation: Orientation
}

type LoosePackingStrategy = {
  prioritizeHigherSupports: boolean
  preferRotatedOrientation: boolean
  orderByFootprint: boolean
}

const LOOSE_PACKING_STRATEGIES: LoosePackingStrategy[] = [
  { prioritizeHigherSupports: false, preferRotatedOrientation: false, orderByFootprint: false },
  { prioritizeHigherSupports: true, preferRotatedOrientation: false, orderByFootprint: false },
  { prioritizeHigherSupports: true, preferRotatedOrientation: true, orderByFootprint: false },
  { prioritizeHigherSupports: true, preferRotatedOrientation: true, orderByFootprint: true },
]

function looseOrientations(box: ContainerLooseBoxInput): Orientation[] {
  const candidates = [
    { length: box.length, width: box.width },
    { length: box.width, width: box.length },
  ]
  const seen = new Set<string>()
  return candidates.filter((candidate) => {
    const key = `${candidate.length}-${candidate.width}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })
}

function looseFits(box: ContainerLooseBoxInput, orientation: Orientation, x: number, y: number, z: number, container: ContainerSpec, totalWeight: number) {
  return orientation.length > 0 && orientation.width > 0 && box.height > 0 &&
    x >= 0 && y >= 0 && z >= 0 &&
    y + box.height <= container.height &&
    x + orientation.length <= container.length &&
    z + orientation.width <= container.width &&
    totalWeight + box.weight <= container.maxWeight
}

function intervalsOverlap(startA: number, sizeA: number, startB: number, sizeB: number) {
  return startA < startB + sizeB && startA + sizeA > startB
}

function overlapsPlacedBox(candidate: LoosePlacementCandidate, box: ContainerLooseBoxInput, placed: ContainerLooseBoxPlacement) {
  return intervalsOverlap(candidate.x, candidate.orientation.length, placed.x, placed.placedLength) &&
    intervalsOverlap(candidate.y, box.height, placed.y, placed.placedHeight) &&
    intervalsOverlap(candidate.z, candidate.orientation.width, placed.z, placed.placedWidth)
}

function hasStackingSupport(candidate: LoosePlacementCandidate, box: ContainerLooseBoxInput, placed: ContainerLooseBoxPlacement[]) {
  if (candidate.y === 0) return true
  return placed.some((support) => {
    const supportTop = support.y + support.placedHeight
    const supportsCandidate = support.canStack && supportTop === candidate.y &&
      candidate.x >= support.x && candidate.x + candidate.orientation.length <= support.x + support.placedLength &&
      candidate.z >= support.z && candidate.z + candidate.orientation.width <= support.z + support.placedWidth
    return supportsCandidate && candidate.y + box.height > candidate.y
  })
}

function uniqueSorted(values: number[]) {
  return [...new Set(values)].sort((a, b) => a - b)
}

function findLoosePlacement(box: ContainerLooseBoxInput, placed: ContainerLooseBoxPlacement[], container: ContainerSpec, totalWeight: number, strategy: LoosePackingStrategy): LoosePlacementCandidate | null {
  const xPositions = uniqueSorted([0, ...placed.flatMap((item) => [item.x, item.x + item.placedLength])])
  const zPositions = uniqueSorted([0, ...placed.flatMap((item) => [item.z, item.z + item.placedWidth])])
  const yPositions = uniqueSorted([0, ...placed.filter((item) => item.canStack).map((item) => item.y + item.placedHeight)])
  const orderedYPositions = strategy.prioritizeHigherSupports ? [...yPositions].reverse() : yPositions
  const orientations = looseOrientations(box)
  const orderedOrientations = strategy.preferRotatedOrientation ? [...orientations].reverse() : orientations

  for (const y of orderedYPositions) {
    for (const z of zPositions) {
      for (const x of xPositions) {
        for (const orientation of orderedOrientations) {
          const candidate: LoosePlacementCandidate = { x, y, z, orientation }
          if (!looseFits(box, orientation, x, y, z, container, totalWeight)) continue
          if (!hasStackingSupport(candidate, box, placed)) continue
          if (placed.some((item) => overlapsPlacedBox(candidate, box, item))) continue
          return candidate
        }
      }
    }
  }

  return null
}

function createLooseContainerPlan(boxes: ContainerLooseBoxInput[], container: ContainerSpec, containerIndex: number, strategy: LoosePackingStrategy) {
  const placed: ContainerLooseBoxPlacement[] = []
  const remaining: ContainerLooseBoxInput[] = []
  let totalWeight = 0

  for (const box of boxes) {
    const placement = findLoosePlacement(box, placed, container, totalWeight, strategy)
    if (!placement) {
      remaining.push(box)
      continue
    }

    placed.push({
      ...box,
      containerIndex,
      x: placement.x,
      y: placement.y,
      z: placement.z,
      placedLength: placement.orientation.length,
      placedWidth: placement.orientation.width,
      placedHeight: box.height,
    })
    totalWeight += box.weight
  }

  const floorArea = container.length * container.width
  const volume = container.length * container.width * container.height
  const usedFloorArea = placed.filter((box) => box.y === 0).reduce((sum, box) => sum + box.placedLength * box.placedWidth, 0)
  const usedVolume = placed.reduce((sum, box) => sum + box.placedLength * box.placedWidth * box.placedHeight, 0)
  const plan: LooseContainerPlan = {
    containerIndex,
    boxes: placed,
    totalWeight,
    floorUtilizationPercentage: floorArea > 0 ? (usedFloorArea / floorArea) * 100 : 0,
    volumeUtilizationPercentage: volume > 0 ? (usedVolume / volume) * 100 : 0,
    loadMetrics: calculateLoadMetrics(placed, container),
    warnings: remaining.length > 0 ? [`${remaining.length} caja(s) no pudieron ubicarse en este contenedor`] : [],
  }
  return { plan, remaining }
}

function orderLooseBoxes(boxes: ContainerLooseBoxInput[], strategy: LoosePackingStrategy) {
  return [...boxes].sort((a, b) => {
    const firstMeasure = strategy.orderByFootprint ? b.length * b.width - a.length * a.width : b.length * b.width * b.height - a.length * a.width * a.height
    if (firstMeasure !== 0) return firstMeasure
    const secondMeasure = strategy.orderByFootprint ? b.length * b.width * b.height - a.length * a.width * a.height : b.length * b.width - a.length * a.width
    return secondMeasure || b.height - a.height || b.weight - a.weight
  })
}

function calculateLooseContainerLoadWithStrategy(boxes: ContainerLooseBoxInput[], container: ContainerSpec, totalBoxTypes: number, strategy: LoosePackingStrategy): LooseContainerLoadResult {
  const orderedBoxes = orderLooseBoxes(boxes, strategy)
  const plans: LooseContainerPlan[] = []
  let remaining = orderedBoxes

  while (remaining.length > 0 && plans.length < MAX_GENERATED_CONTAINERS) {
    const result = createLooseContainerPlan(remaining, container, plans.length, strategy)
    if (result.plan.boxes.length === 0) break
    plans.push(result.plan)
    remaining = result.remaining
  }

  const totalWeight = orderedBoxes.reduce((sum, box) => sum + box.weight, 0)
  const placedBoxes = plans.reduce((sum, plan) => sum + plan.boxes.length, 0)
  const warnings: string[] = []
  if (plans.length > 1) warnings.push(`La carga suelta requiere ${plans.length} contenedor(es) para ubicar las ${orderedBoxes.length} cajas`)
  if (remaining.length > 0) warnings.push(`${remaining.length} caja(s) no pudieron ubicarse por dimensiones, apilamiento o peso máximo del contenedor`)
  if (orderedBoxes.some((box) => {
    const fitsNormal = box.length <= container.length && box.width <= container.width
    const fitsRotated = box.width <= container.length && box.length <= container.width
    return (!fitsNormal && !fitsRotated) || box.height > container.height
  })) warnings.push('Al menos una caja supera las dimensiones internas del contenedor seleccionado')

  return { container, totalBoxes: orderedBoxes.length, totalBoxTypes, totalWeight, placedBoxes, unplacedBoxes: remaining.length, containersNeeded: plans.length, plans, warnings }
}

function compareLooseLoadResults(first: LooseContainerLoadResult, second: LooseContainerLoadResult) {
  if (first.unplacedBoxes !== second.unplacedBoxes) return first.unplacedBoxes - second.unplacedBoxes
  if (first.containersNeeded !== second.containersNeeded) return first.containersNeeded - second.containersNeeded
  const firstVolumeUtilization = first.plans.reduce((sum, plan) => sum + plan.volumeUtilizationPercentage, 0)
  const secondVolumeUtilization = second.plans.reduce((sum, plan) => sum + plan.volumeUtilizationPercentage, 0)
  return secondVolumeUtilization - firstVolumeUtilization
}

export function calculateLooseContainerLoad(boxes: ContainerLooseBoxInput[], container: ContainerSpec, totalBoxTypes = new Set(boxes.map((box) => box.sourceIndex)).size): LooseContainerLoadResult {
  const candidates = LOOSE_PACKING_STRATEGIES.map((strategy) => calculateLooseContainerLoadWithStrategy(boxes, container, totalBoxTypes, strategy))
  return [...candidates].sort(compareLooseLoadResults)[0]
}
