// Estilo: Modernismo Industrial Funcional; importación trazable, datos tabulares densos y restricciones logísticas explícitas.

import * as XLSX from 'xlsx'
import type { BoxHandlingOptions, BoxDimensions, MixedBoxItem } from './palletCalculator'

export interface ProductListItem extends MixedBoxItem {
  groupId: string
  groupName: string
  expanded: boolean
}

export interface ProductImportResult {
  items: ProductListItem[]
  warnings: string[]
  errors: string[]
  sourceName: string
  sheetName: string
}

const HEADER_ALIASES: Record<string, string[]> = {
  label: ['label', 'sku', 'name', 'nombre', 'producto', 'product', 'item'],
  width: ['width', 'widthmm', 'ancho', 'anchomm'],
  length: ['length', 'lengthmm', 'largo', 'largomm'],
  height: ['height', 'heightmm', 'alto', 'altomm'],
  weight: ['weight', 'weightg', 'peso', 'pesog', 'weightkg', 'pesokg'],
  quantity: ['quantity', 'qty', 'amount', 'cantidad', 'unidades', 'units'],
  groupId: ['groupid', 'group', 'grupo', 'grupoid'],
  allowStacking: ['allowstackingontop', 'allowstacking', 'canstack', 'stack', 'apilar', 'sepuedeapilar'],
  rotations: ['allowedrotations', 'rotations', 'rotation', 'rotacion', 'rotaciones'],
}

function canonicalHeader(value: unknown) {
  return String(value ?? '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '')
}

function parseBoolean(value: unknown, fallback = true) {
  if (typeof value === 'boolean') return value
  const normalized = String(value ?? '').trim().toLowerCase()
  if (!normalized) return fallback
  if (['true', '1', 'yes', 'si', 'sí', 'y', 'x', 'on'].includes(normalized)) return true
  if (['false', '0', 'no', 'n', 'off'].includes(normalized)) return false
  return fallback
}

function parseNumber(value: unknown, fallback = 0) {
  if (typeof value === 'number' && Number.isFinite(value)) return value
  const normalized = String(value ?? '').trim().replace(/\s/g, '').replace(',', '.')
  const parsed = Number(normalized)
  return Number.isFinite(parsed) ? parsed : fallback
}

function findColumn(headers: string[], key: keyof typeof HEADER_ALIASES) {
  const aliases = HEADER_ALIASES[key]
  return headers.findIndex((header) => aliases.includes(canonicalHeader(header)))
}

function readCell(row: unknown[], index: number) {
  return index >= 0 ? row[index] : undefined
}

function parseRotations(value: unknown): Pick<BoxHandlingOptions, 'allowHorizontalRotation' | 'allowVerticalRotation'> {
  const text = String(value ?? '').toUpperCase()
  const tokens = text.split(/[\s,;|/]+/).filter(Boolean)
  const hasZ = tokens.includes('Z') || tokens.includes('VERTICAL')
  const hasX = tokens.includes('X') || tokens.includes('HORIZONTAL')
  return {
    allowHorizontalRotation: hasX || tokens.length === 0,
    allowVerticalRotation: hasZ,
  }
}

function normaliseWeight(rawWeight: unknown, headers: string[], weightIndex: number) {
  const weight = parseNumber(rawWeight)
  const header = canonicalHeader(headers[weightIndex])
  return header.includes('kg') ? weight : weight / 1000
}

function buildItem(row: unknown[], headers: string[], rowNumber: number, warnings: string[]): ProductListItem | null {
  const labelIndex = findColumn(headers, 'label')
  const widthIndex = findColumn(headers, 'width')
  const lengthIndex = findColumn(headers, 'length')
  const heightIndex = findColumn(headers, 'height')
  const weightIndex = findColumn(headers, 'weight')
  const quantityIndex = findColumn(headers, 'quantity')
  const groupIndex = findColumn(headers, 'groupId')
  const stackIndex = findColumn(headers, 'allowStacking')
  const rotationsIndex = findColumn(headers, 'rotations')

  const rawLabel = String(readCell(row, labelIndex) ?? '').trim()
  const label = rawLabel && rawLabel !== 'undefined' ? rawLabel : `SKU-${rowNumber}`
  const dimensions: BoxDimensions = {
    length: parseNumber(readCell(row, lengthIndex)),
    width: parseNumber(readCell(row, widthIndex)),
    height: parseNumber(readCell(row, heightIndex)),
    weight: normaliseWeight(readCell(row, weightIndex), headers, weightIndex),
  }
  const quantity = Math.max(0, Math.floor(parseNumber(readCell(row, quantityIndex), 0)))
  const missing = Object.entries(dimensions).filter(([, value]) => value <= 0).map(([key]) => key)
  if (missing.length > 0 || quantity <= 0) {
    warnings.push(`Fila ${rowNumber}: ${label} se omitió porque requiere dimensiones, peso y cantidad mayores que cero.`)
    return null
  }

  const rotations = parseRotations(readCell(row, rotationsIndex))
  const groupId = String(readCell(row, groupIndex) ?? '0').trim() || '0'
  return {
    id: `import-${rowNumber}-${label.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 30)}`,
    name: label,
    boxDimensions: dimensions,
    quantity,
    canStack: parseBoolean(readCell(row, stackIndex), true),
    ...rotations,
    groupId,
    groupName: `Grupo ${groupId}`,
    expanded: false,
  }
}

export async function parseProductFile(file: File): Promise<ProductImportResult> {
  const sourceName = file.name
  const workbook = XLSX.read(await file.arrayBuffer(), { type: 'array', cellDates: false })
  const preferredSheet = workbook.SheetNames.find((name) => canonicalHeader(name) === 'boxes')
  const sheetName = preferredSheet ?? workbook.SheetNames[0] ?? ''
  const sheet = sheetName ? workbook.Sheets[sheetName] : undefined
  if (!sheet) return { items: [], warnings: [], errors: ['El archivo no contiene hojas legibles.'], sourceName, sheetName }

  const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, defval: '' })
  const headers = (rows.shift() ?? []).map((header) => String(header))
  const required = ['width', 'length', 'height', 'weight', 'quantity']
  const missingColumns = required.filter((key) => findColumn(headers, key) < 0)
  if (missingColumns.length > 0) {
    return { items: [], warnings: [], errors: [`Faltan columnas requeridas: ${missingColumns.join(', ')}.`], sourceName, sheetName }
  }

  const warnings: string[] = []
  const items = rows.map((row, index) => buildItem(row, headers, index + 2, warnings)).filter((item): item is ProductListItem => Boolean(item))
  return { items, warnings, errors: [], sourceName, sheetName }
}

export function downloadProductTemplate() {
  const rows = [
    ['label', 'width (mm)', 'length (mm)', 'height (mm)', 'weight (g)', 'amount', 'groupId', 'allowStackingOnTop', 'allowedRotations'],
    ['Producto ejemplo', 400, 300, 200, 5000, 8, '0', true, 'X,Y,Z'],
  ]
  const sheet = XLSX.utils.aoa_to_sheet(rows)
  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(workbook, sheet, 'Boxes')
  XLSX.writeFile(workbook, 'plantilla_productos_pallet_optimizer.xlsx')
}

export function productItemsToMixedBoxes(items: ProductListItem[]): MixedBoxItem[] {
  return items.map(({ expanded: _expanded, groupId: _groupId, groupName: _groupName, ...item }) => item)
}
