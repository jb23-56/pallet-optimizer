/* Estilo: informe operativo conciso; resume la decisión logística disponible sin exigir una mezcla de SKU. */
import { jsPDF } from 'jspdf'
import autoTable from 'jspdf-autotable'
import * as XLSX from 'xlsx'
import type { ContainerLoadResult, LooseContainerLoadResult } from './containerCalculator'

export type ManualLoadAdjustmentReportRow = {
  containerIndex: number
  kind: 'Paleta' | 'Caja'
  label: string
  cargoId: string
  original: { x: number; y: number; z: number; length: number; width: number }
  adjusted: { x: number; y: number; z: number; length: number; width: number }
}

export type BasicLogisticsReportInput = {
  title: string
  subtitle: string
  destination: string
  summary: Array<{ label: string; value: string | number }>
  warnings?: string[]
  containerResult?: ContainerLoadResult | LooseContainerLoadResult | null
  manualAdjustments?: ManualLoadAdjustmentReportRow[]
  generatedAt?: Date
}

const PAGE_WIDTH = 210
const MARGIN = 14

function formatM3(value: number) {
  return `${value.toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} m³`
}

function formatTransportRows(result: ContainerLoadResult | LooseContainerLoadResult) {
  const volumePerUnit = (result.container.length * result.container.width * result.container.height) / 1_000_000_000
  return result.plans.map((plan) => {
    const used = volumePerUnit * (plan.volumeUtilizationPercentage / 100)
    const isLoose = 'boxes' in plan
    return [
      `Unidad ${plan.containerIndex + 1}`,
      isLoose ? `${plan.boxes.length} cajas` : `${plan.pallets.length} paletas`,
      `${plan.totalWeight.toLocaleString('es-ES', { maximumFractionDigits: 1 })} kg`,
      `${plan.floorUtilizationPercentage.toFixed(1)}%`,
      formatM3(used),
      formatM3(Math.max(0, volumePerUnit - used)),
    ]
  })
}

function formatManualAdjustmentRows(adjustments: ManualLoadAdjustmentReportRow[]) {
  return adjustments.map((adjustment) => [
    `C${adjustment.containerIndex + 1} · ${adjustment.kind}`,
    adjustment.label,
    `${Math.round(adjustment.original.x).toLocaleString('es-ES')} / ${Math.round(adjustment.original.z).toLocaleString('es-ES')} mm`,
    `${Math.round(adjustment.adjusted.x).toLocaleString('es-ES')} / ${Math.round(adjustment.adjusted.z).toLocaleString('es-ES')} mm`,
    `${Math.round(adjustment.original.length).toLocaleString('es-ES')} × ${Math.round(adjustment.original.width).toLocaleString('es-ES')} a ${Math.round(adjustment.adjusted.length).toLocaleString('es-ES')} × ${Math.round(adjustment.adjusted.width).toLocaleString('es-ES')} mm`,
  ])
}

export function downloadBasicLogisticsPdf(input: BasicLogisticsReportInput) {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' })
  const createdAt = input.generatedAt ?? new Date()
  const generatedDate = createdAt.toLocaleString('es-ES', { dateStyle: 'medium', timeStyle: 'short' })
  doc.setFillColor(15, 23, 42)
  doc.rect(0, 0, PAGE_WIDTH, 28, 'F')
  doc.setFillColor(37, 99, 235)
  doc.roundedRect(MARGIN, 7, 12, 12, 2, 2, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(18)
  doc.text('PalletOptimizer', MARGIN + 16, 13)
  doc.setFontSize(7.5)
  doc.setFont('helvetica', 'normal')
  doc.text('INFORME OPERATIVO DE CÁLCULO', MARGIN + 16, 18)
  doc.text(generatedDate, PAGE_WIDTH - MARGIN, 18, { align: 'right' })

  doc.setTextColor(15, 23, 42)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(14)
  doc.text(input.title, MARGIN, 38)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9)
  doc.setTextColor(71, 85, 105)
  doc.text(input.subtitle, MARGIN, 44)

  autoTable(doc, {
    startY: 51,
    theme: 'grid',
    head: [['Resumen', 'Valor']],
    body: [...input.summary.map((item) => [item.label, String(item.value)]), ['Destino / método de envío', input.destination]],
    styles: { font: 'helvetica', fontSize: 8.5, cellPadding: 2.6 },
    headStyles: { fillColor: [30, 41, 59], textColor: 255, fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    columnStyles: { 0: { cellWidth: 72 }, 1: { cellWidth: 110 } },
  })

  let nextY = ((doc as jsPDF & { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY ?? 51) + 10
  if (input.containerResult) {
    doc.setFillColor(15, 23, 42)
    doc.rect(MARGIN, nextY, PAGE_WIDTH - MARGIN * 2, 7, 'F')
    doc.setTextColor(255, 255, 255)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(8)
    doc.text('PLAN DE ENVÍO', MARGIN + 3, nextY + 4.7)
    nextY += 10
    autoTable(doc, {
      startY: nextY,
      theme: 'grid',
      head: [['Unidad', 'Carga', 'Peso', 'Uso piso', 'm³ usados', 'm³ libres']],
      body: formatTransportRows(input.containerResult),
      styles: { font: 'helvetica', fontSize: 7.5, cellPadding: 2 },
      headStyles: { fillColor: [51, 65, 85], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [248, 250, 252] },
    })
    nextY = ((doc as jsPDF & { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY ?? nextY) + 10
  }

  if ((input.manualAdjustments?.length ?? 0) > 0) {
    doc.setFillColor(91, 33, 182)
    doc.rect(MARGIN, nextY, PAGE_WIDTH - MARGIN * 2, 7, 'F')
    doc.setTextColor(255, 255, 255)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(8)
    doc.text('AJUSTES MANUALES DE CARGA', MARGIN + 3, nextY + 4.7)
    nextY += 10
    autoTable(doc, {
      startY: nextY,
      theme: 'grid',
      head: [['Unidad', 'Elemento', 'Original X / Z', 'Ajustado X / Z', 'Huella L × A']],
      body: formatManualAdjustmentRows(input.manualAdjustments!),
      styles: { font: 'helvetica', fontSize: 7, cellPadding: 1.7 },
      headStyles: { fillColor: [91, 33, 182], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [250, 245, 255] },
    })
    nextY = ((doc as jsPDF & { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY ?? nextY) + 10
  }

  if ((input.warnings?.length ?? 0) > 0) {
    doc.setFillColor(146, 64, 14)
    doc.rect(MARGIN, nextY, PAGE_WIDTH - MARGIN * 2, 7, 'F')
    doc.setTextColor(255, 255, 255)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(8)
    doc.text('ADVERTENCIAS', MARGIN + 3, nextY + 4.7)
    nextY += 10
    autoTable(doc, {
      startY: nextY,
      theme: 'grid',
      head: [['Observación']],
      body: input.warnings!.map((warning) => [warning]),
      styles: { font: 'helvetica', fontSize: 8, cellPadding: 2.3, textColor: [120, 53, 15] },
      headStyles: { fillColor: [146, 64, 14], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [255, 251, 235] },
    })
  }

  const pages = doc.getNumberOfPages()
  for (let page = 1; page <= pages; page += 1) {
    doc.setPage(page)
    doc.setDrawColor(203, 213, 225)
    doc.line(MARGIN, 287, PAGE_WIDTH - MARGIN, 287)
    doc.setTextColor(71, 85, 105)
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(7)
    doc.text('PalletOptimizer · Informe de planificación logística', MARGIN, 291)
    doc.text(`Página ${page} de ${pages}`, PAGE_WIDTH - MARGIN, 291, { align: 'right' })
  }
  doc.save(`informe-operativo-palletoptimizer-${createdAt.toISOString().slice(0, 10)}.pdf`)
}

export function downloadBasicLogisticsExcel(input: BasicLogisticsReportInput) {
  const workbook = XLSX.utils.book_new()
  const createdAt = input.generatedAt ?? new Date()
  const rows = [
    ['Informe', input.title],
    ['Descripción', input.subtitle],
    ...input.summary.map((item) => [item.label, item.value]),
    ['Destino / método de envío', input.destination],
  ]
  const summary = XLSX.utils.aoa_to_sheet(rows)
  summary['!cols'] = [{ wch: 34 }, { wch: 52 }]
  XLSX.utils.book_append_sheet(workbook, summary, 'Resumen')

  if (input.containerResult) {
    const shippingRows = [['Unidad', 'Carga', 'Peso', 'Uso piso', 'm³ usados', 'm³ libres'], ...formatTransportRows(input.containerResult)]
    const shipping = XLSX.utils.aoa_to_sheet(shippingRows)
    shipping['!cols'] = [14, 18, 14, 14, 14, 14].map((wch) => ({ wch }))
    XLSX.utils.book_append_sheet(workbook, shipping, 'Envío')
  }
  if ((input.manualAdjustments?.length ?? 0) > 0) {
    const adjustments = XLSX.utils.aoa_to_sheet([
      ['Contenedor', 'Tipo', 'Elemento', 'ID', 'X original (mm)', 'Z original (mm)', 'X ajustado (mm)', 'Z ajustado (mm)', 'L original (mm)', 'A original (mm)', 'L ajustado (mm)', 'A ajustado (mm)'],
      ...input.manualAdjustments!.map((adjustment) => [
        adjustment.containerIndex + 1, adjustment.kind, adjustment.label, adjustment.cargoId,
        Math.round(adjustment.original.x), Math.round(adjustment.original.z), Math.round(adjustment.adjusted.x), Math.round(adjustment.adjusted.z),
        Math.round(adjustment.original.length), Math.round(adjustment.original.width), Math.round(adjustment.adjusted.length), Math.round(adjustment.adjusted.width),
      ]),
    ])
    adjustments['!cols'] = [12, 12, 20, 24, 16, 16, 16, 16, 16, 16, 16, 16].map((wch) => ({ wch }))
    XLSX.utils.book_append_sheet(workbook, adjustments, 'Ajustes manuales')
  }
  if ((input.warnings?.length ?? 0) > 0) {
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([['Advertencia'], ...input.warnings!.map((warning) => [warning])]), 'Alertas')
  }
  XLSX.writeFile(workbook, `informe-operativo-palletoptimizer-${createdAt.toISOString().slice(0, 10)}.xlsx`)
}
