/* Libro Excel: plan logístico con resumen, paletas, posiciones físicas, SKU, envío y alertas. */
import * as XLSX from 'xlsx'
import type { ContainerLoadResult } from './containerCalculator'
import type { MixedBoxItem, MixedBoxResult, PalletDimensions } from './palletCalculator'
import type { ManualLoadAdjustmentReportRow } from './basicLogisticsReport'

type DestinationProfile = {
  label: string
  maxTotalHeight: number
  maxLength?: number
  maxWidth?: number
  maxWeight?: number
  note: string
}

export type LogisticsExcelInput = {
  destination: DestinationProfile
  maneuverability: {
    preferredMaxSide: number
    allowOversize: boolean
  }
  configuredPallet: PalletDimensions
  mixedBoxes: MixedBoxItem[]
  mixedResult: MixedBoxResult
  containerResult?: ContainerLoadResult | null
  manualAdjustments?: ManualLoadAdjustmentReportRow[]
  generatedAt?: Date
}

type Row = Array<string | number | boolean | null>

function mm(value: number) {
  return Math.round(value)
}

function percent(value: number) {
  return Number((value / 100).toFixed(4))
}

function columnLabel(column: number) {
  return XLSX.utils.encode_col(column)
}

function applySheetStyle(sheet: XLSX.WorkSheet, title: string, subtitle: string, headers: string[], rows: Row[], widths: number[]) {
  const content = [
    [] as Row,
    ['', title] as Row,
    ['', subtitle] as Row,
    [] as Row,
    ['', ...headers] as Row,
    ...rows.map((row) => ['', ...row]),
  ]
  const populated = XLSX.utils.aoa_to_sheet(content)
  Object.assign(sheet, populated)
  const lastColumn = columnLabel(headers.length)
  const lastRow = 5 + Math.max(rows.length, 1)
  sheet['!merges'] = [{ s: { r: 1, c: 1 }, e: { r: 1, c: headers.length } }, { s: { r: 2, c: 1 }, e: { r: 2, c: headers.length } }]
  sheet['!cols'] = [{ wch: 3 }, ...widths.map((width) => ({ wch: width }))]
  sheet['!autofilter'] = { ref: `B5:${lastColumn}${lastRow}` }
  sheet['!freeze'] = { xSplit: 0, ySplit: 5 }
  sheet['B2'] = { t: 's', v: title, s: { font: { bold: true, color: { rgb: 'FFFFFF' }, sz: 16 }, fill: { fgColor: { rgb: '0F172A' } }, alignment: { horizontal: 'left' } } }
  sheet['B3'] = { t: 's', v: subtitle, s: { font: { italic: true, color: { rgb: '475569' } } } }
  for (let column = 1; column <= headers.length; column += 1) {
    const address = `${columnLabel(column)}5`
    const value = headers[column - 1]
    sheet[address] = { t: 's', v: value, s: { font: { bold: true, color: { rgb: 'FFFFFF' } }, fill: { fgColor: { rgb: '1E3A5F' } }, alignment: { horizontal: 'center', vertical: 'center', wrapText: true } } }
  }
  return sheet
}

function applyFormats(sheet: XLSX.WorkSheet, startRow: number, endRow: number, columnIndexes: number[], format: string) {
  for (let row = startRow; row <= endRow; row += 1) {
    for (const index of columnIndexes) {
      const cell = sheet[`${columnLabel(index)}${row}`]
      if (cell && typeof cell.v === 'number') cell.z = format
    }
  }
}

export function buildLogisticsWorkbook(input: LogisticsExcelInput) {
  const workbook = XLSX.utils.book_new()
  const createdAt = input.generatedAt ?? new Date()
  const generatedDate = createdAt.toLocaleString('es-ES', { dateStyle: 'medium', timeStyle: 'short' })
  const container = input.containerResult
  const totalPlaced = input.mixedResult.totalBoxes - input.mixedResult.unplacedBoxes
  const destinationSubtitle = `${input.destination.label} · generado ${generatedDate}`

  const summaryRows: Row[] = [
    ['Cajas totales', input.mixedResult.totalBoxes],
    ['Cajas ubicadas', totalPlaced],
    ['Paletas necesarias', input.mixedResult.palletsNeeded],
    ['Peso total (kg)', input.mixedResult.totalWeight],
    ['Utilización global', percent(input.mixedResult.utilizationPercentage)],
    ['Destino final', input.destination.label],
    ['Caja útil destino (mm)', input.destination.maxLength && input.destination.maxWidth ? `${mm(input.destination.maxLength)} × ${mm(input.destination.maxWidth)} × ${mm(input.destination.maxTotalHeight)}` : 'No especificada'],
    ['Peso máximo destino (kg)', input.destination.maxWeight ?? 'No especificado'],
    ['Altura máxima (mm)', mm(input.destination.maxTotalHeight)],
    ['Perfil maniobrable (mm)', mm(input.maneuverability.preferredMaxSide)],
    ['Bases ampliadas', input.maneuverability.allowOversize ? 'Permitidas' : 'No permitidas'],
    ['Base configurada (mm)', `${mm(input.configuredPallet.length)} × ${mm(input.configuredPallet.width)}`],
    ['Plan de envío', container ? `${container.containersNeeded} ${container.container.name}` : 'Pendiente de calcular'],
  ]
  const summary = applySheetStyle(XLSX.utils.aoa_to_sheet([]), 'RESUMEN DEL PLAN LOGÍSTICO', destinationSubtitle, ['Métrica', 'Valor'], summaryRows, [34, 48])
  applyFormats(summary, 6, 6 + summaryRows.length, [2], '#,##0.0')
  summary['C10'] = { t: 'n', v: percent(input.mixedResult.utilizationPercentage), z: '0.0%' }
  XLSX.utils.book_append_sheet(workbook, summary, 'Resumen')

  const palletRows: Row[] = input.mixedResult.pallets.map((plan) => [
    `P${plan.palletIndex + 1}`,
    plan.totalBoxes,
    plan.totalWeight,
    mm(plan.fabricatedPallet.originalLength),
    mm(plan.fabricatedPallet.originalWidth),
    mm(plan.fabricatedPallet.length),
    mm(plan.fabricatedPallet.width),
    mm(plan.fabricatedPallet.height),
    mm(plan.fabricatedPallet.occupiedLength),
    mm(plan.fabricatedPallet.occupiedWidth),
    percent(plan.fabricatedPallet.materialSavingsPercentage),
    percent(plan.utilizationPercentage),
    plan.fabricatedPallet.isReduced ? 'Base reducida' : 'Base completa',
  ])
  const pallets = applySheetStyle(XLSX.utils.aoa_to_sheet([]), 'PALETAS FABRICADAS', 'Dimensiones finales por unidad para fabricación y expedición.', ['Paleta', 'Cajas', 'Peso (kg)', 'Base L (mm)', 'Base A (mm)', 'Fabricada L (mm)', 'Fabricada A (mm)', 'Altura (mm)', 'Huella L (mm)', 'Huella A (mm)', 'Ahorro', 'Uso real', 'Estado'], palletRows, [11, 10, 13, 14, 14, 18, 18, 14, 15, 15, 12, 12, 18])
  applyFormats(pallets, 6, 5 + palletRows.length, [3], '#,##0.0')
  applyFormats(pallets, 6, 5 + palletRows.length, [11, 12], '0.0%')
  XLSX.utils.book_append_sheet(workbook, pallets, 'Paletas')

  const placementRows: Row[] = input.mixedResult.pallets.flatMap((plan) => plan.boxPlacements.map((placement) => [
    `P${plan.palletIndex + 1}`,
    placement.placementId,
    placement.boxName,
    mm(placement.x),
    mm(placement.y),
    mm(placement.z),
    mm(placement.width),
    mm(placement.height),
    mm(placement.depth),
    placement.canStack ? 'Sí' : 'No',
  ]))
  const placements = applySheetStyle(XLSX.utils.aoa_to_sheet([]), 'DISTRIBUCIÓN DE CAJAS', 'Posición física de cada caja dentro de la paleta fabricada. Coordenadas y dimensiones en milímetros.', ['Paleta', 'ID posición', 'SKU / etiqueta', 'X (mm)', 'Y (mm)', 'Z (mm)', 'Largo (mm)', 'Alto (mm)', 'Ancho (mm)', 'Apilable'], placementRows, [11, 22, 30, 12, 12, 12, 14, 13, 14, 12])
  XLSX.utils.book_append_sheet(workbook, placements, 'Cajas')

  const skuRows: Row[] = input.mixedBoxes.map((item) => {
    const distribution = input.mixedResult.boxDistribution.find((entry) => entry.boxId === item.id)
    return [
      item.name,
      mm(item.boxDimensions.length),
      mm(item.boxDimensions.width),
      mm(item.boxDimensions.height),
      item.boxDimensions.weight,
      item.quantity,
      distribution?.quantity ?? 0,
      distribution?.weight ?? 0,
      percent(distribution?.percentage ?? 0),
      item.canStack ? 'Sí' : 'No',
      item.allowHorizontalRotation ? 'Sí' : 'No',
      item.allowVerticalRotation ? 'Sí' : 'No',
    ]
  })
  const sku = applySheetStyle(XLSX.utils.aoa_to_sheet([]), 'ESPECIFICACIONES SKU', 'Dimensiones, cantidad y restricciones de manejo de cada tipo de caja.', ['SKU / etiqueta', 'Largo (mm)', 'Ancho (mm)', 'Alto (mm)', 'Peso (kg)', 'Cantidad', 'Ubicada', 'Peso ubicado (kg)', 'Participación', 'Apila', 'Giro H', 'Giro V'], skuRows, [32, 14, 14, 14, 14, 12, 12, 18, 14, 10, 10, 10])
  applyFormats(sku, 6, 5 + skuRows.length, [5, 8], '#,##0.0')
  applyFormats(sku, 6, 5 + skuRows.length, [9], '0.0%')
  XLSX.utils.book_append_sheet(workbook, sku, 'SKU')

  const shippingRows: Row[] = container
    ? container.plans.map((plan) => [
      `C${plan.containerIndex + 1}`,
      container.container.name,
      plan.pallets.length,
      plan.totalWeight,
      percent(plan.floorUtilizationPercentage),
      percent(plan.volumeUtilizationPercentage),
      mm(plan.loadMetrics.maxOccupiedHeight),
      mm(plan.loadMetrics.centerOfGravity.longitudinal),
      mm(plan.loadMetrics.centerOfGravity.transversal),
      mm(plan.loadMetrics.centerOfGravity.vertical),
      `${mm(container.container.length)} × ${mm(container.container.width)} × ${mm(container.container.height)}`,
    ])
    : [[
      'Pendiente', input.destination.label, 0, 0, 0, 0, 0, 0, 0, 0,
      input.destination.maxLength && input.destination.maxWidth ? `${mm(input.destination.maxLength)} × ${mm(input.destination.maxWidth)} × ${mm(input.destination.maxTotalHeight)} · máximo ${input.destination.maxWeight ?? 'N/D'} kg` : `Límite de altura destino: ${mm(input.destination.maxTotalHeight)}`,
    ]]
  const shipping = applySheetStyle(XLSX.utils.aoa_to_sheet([]), 'ENVÍO Y DESTINO FINAL', container ? `Plan calculado para ${container.container.name}.` : 'Destino definido; el plan de contenedor aún no se ha calculado.', ['Unidad envío', 'Equipo / destino', 'Paletas', 'Peso (kg)', 'Uso piso', 'Uso volumen', 'Altura (mm)', 'CG L (mm)', 'CG T (mm)', 'CG V (mm)', 'Dimensiones internas / referencia'], shippingRows, [15, 30, 12, 14, 13, 15, 16, 15, 15, 15, 35])
  applyFormats(shipping, 6, 5 + shippingRows.length, [4], '#,##0.0')
  applyFormats(shipping, 6, 5 + shippingRows.length, [5, 6], '0.0%')
  XLSX.utils.book_append_sheet(workbook, shipping, 'Envío')

  if ((input.manualAdjustments?.length ?? 0) > 0) {
    const adjustmentRows: Row[] = input.manualAdjustments!.map((adjustment) => [
      `C${adjustment.containerIndex + 1}`,
      adjustment.kind,
      adjustment.label,
      adjustment.cargoId,
      mm(adjustment.original.x),
      mm(adjustment.original.y),
      mm(adjustment.original.z),
      mm(adjustment.adjusted.x),
      mm(adjustment.adjusted.y),
      mm(adjustment.adjusted.z),
      mm(adjustment.original.length),
      mm(adjustment.original.width),
      mm(adjustment.adjusted.length),
      mm(adjustment.adjusted.width),
    ])
    const adjustments = applySheetStyle(XLSX.utils.aoa_to_sheet([]), 'AJUSTES MANUALES DE CARGA', 'Cambios manuales aprobados dentro del contenedor: posición original, posición ajustada y huella en planta.', ['Contenedor', 'Tipo', 'Elemento', 'ID', 'X original', 'Y original', 'Z original', 'X ajustado', 'Y ajustado', 'Z ajustado', 'L original', 'A original', 'L ajustado', 'A ajustado'], adjustmentRows, [14, 12, 24, 26, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14])
    XLSX.utils.book_append_sheet(workbook, adjustments, 'Ajustes manuales')
  }

  const warningRows: Row[] = [...input.mixedResult.warnings, ...(container?.warnings ?? [])]
    .map((warning, index) => [index + 1, warning])
  if (warningRows.length === 0) warningRows.push([1, 'Sin advertencias operativas.'])
  const warnings = applySheetStyle(XLSX.utils.aoa_to_sheet([]), 'ALERTAS OPERATIVAS', 'Observaciones del cálculo de paletizado y del plan de envío.', ['N.º', 'Observación'], warningRows, [10, 100])
  XLSX.utils.book_append_sheet(workbook, warnings, 'Alertas')

  return workbook
}

export function downloadLogisticsExcel(input: LogisticsExcelInput) {
  const createdAt = input.generatedAt ?? new Date()
  const safeDate = createdAt.toISOString().slice(0, 10)
  XLSX.writeFile(buildLogisticsWorkbook({ ...input, generatedAt: createdAt }), `plan-logistico-palletoptimizer-${safeDate}.xlsx`)
}
