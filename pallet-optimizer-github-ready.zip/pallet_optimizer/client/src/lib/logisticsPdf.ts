/* Informe técnico: jerarquía de estación logística, métricas tabulares y lectura operativa del destino. */
import { jsPDF } from 'jspdf'
import autoTable from 'jspdf-autotable'
import type { ContainerLoadResult } from './containerCalculator'
import type { MixedBoxItem, MixedBoxResult, PalletDimensions } from './palletCalculator'
import type { ManualLoadAdjustmentReportRow } from './basicLogisticsReport'

type DestinationProfile = {
  label: string
  maxTotalHeight: number
  maxLength?: number
  maxWidth?: number
  maxWeight?: number
  note: string
}

export type LogisticsPdfInput = {
  destination: DestinationProfile
  maneuverability: {
    preferredMaxSide: number
    allowOversize: boolean
  }
  configuredPallet: PalletDimensions
  mixedBoxes: MixedBoxItem[]
  mixedResult: MixedBoxResult
  containerResult?: ContainerLoadResult | null
  manualAdjustments?: ManualLoadAdjustmentReportRow[]
  generatedAt?: Date
}

const pageWidth = 210
const margin = 14

function mm(value: number) {
  return `${Math.round(value).toLocaleString('es-ES')} mm`
}

function kg(value: number) {
  return `${value.toLocaleString('es-ES', { maximumFractionDigits: 1 })} kg`
}

function percentage(value: number) {
  return `${value.toLocaleString('es-ES', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}%`
}

function nextTableY(doc: jsPDF) {
  return ((doc as jsPDF & { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY ?? 0) + 8
}

function sectionTitle(doc: jsPDF, title: string, y: number, minimumSpace = 14) {
  if (y + minimumSpace > 281) {
    doc.addPage()
    y = 15
  }
  doc.setFillColor(15, 23, 42)
  doc.rect(margin, y, pageWidth - margin * 2, 7, 'F')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(8)
  doc.setTextColor(255, 255, 255)
  doc.text(title.toUpperCase(), margin + 3, y + 4.7)
  doc.setTextColor(15, 23, 42)
  return y + 10
}

function printFooter(doc: jsPDF) {
  const pages = doc.getNumberOfPages()
  for (let page = 1; page <= pages; page += 1) {
    doc.setPage(page)
    doc.setDrawColor(203, 213, 225)
    doc.line(margin, 287, pageWidth - margin, 287)
    doc.setTextColor(71, 85, 105)
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(7)
    doc.text('PalletOptimizer · Informe de planificación logística', margin, 291)
    doc.text(`Página ${page} de ${pages}`, pageWidth - margin, 291, { align: 'right' })
  }
}

export function downloadLogisticsPdf(input: LogisticsPdfInput) {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' })
  const createdAt = input.generatedAt ?? new Date()
  const generatedDate = createdAt.toLocaleString('es-ES', { dateStyle: 'medium', timeStyle: 'short' })

  doc.setFillColor(15, 23, 42)
  doc.rect(0, 0, pageWidth, 28, 'F')
  doc.setFillColor(37, 99, 235)
  doc.roundedRect(margin, 7, 12, 12, 2, 2, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(18)
  doc.text('PalletOptimizer', margin + 16, 13)
  doc.setFontSize(7.5)
  doc.setFont('helvetica', 'normal')
  doc.text('INFORME DE PLANIFICACIÓN LOGÍSTICA', margin + 16, 18)
  doc.text(generatedDate, pageWidth - margin, 18, { align: 'right' })

  let cursorY = 35
  cursorY = sectionTitle(doc, 'Resumen ejecutivo', cursorY)
  autoTable(doc, {
    startY: cursorY,
    theme: 'grid',
    head: [['Cajas', 'Paletas', 'Peso total', 'Utilización real', 'Cajas ubicadas']],
    body: [[
      input.mixedResult.totalBoxes.toLocaleString('es-ES'),
      input.mixedResult.palletsNeeded.toLocaleString('es-ES'),
      kg(input.mixedResult.totalWeight),
      percentage(input.mixedResult.utilizationPercentage),
      `${input.mixedResult.totalBoxes - input.mixedResult.unplacedBoxes}/${input.mixedResult.totalBoxes}`,
    ]],
    styles: { font: 'helvetica', fontSize: 8, cellPadding: 2.4, halign: 'center' },
    headStyles: { fillColor: [30, 41, 59], textColor: 255, fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [248, 250, 252] },
  })

  cursorY = sectionTitle(doc, 'Destino final y operación', nextTableY(doc))
  autoTable(doc, {
    startY: cursorY,
    theme: 'grid',
    head: [['Destino final', 'Altura máxima', 'Perfil de maniobra', 'Base configurada']],
    body: [[
      input.destination.label,
      mm(input.destination.maxTotalHeight),
      input.maneuverability.allowOversize
        ? `Bases ampliadas permitidas · preferente ≤ ${mm(input.maneuverability.preferredMaxSide)}`
        : `Preferente ≤ ${mm(input.maneuverability.preferredMaxSide)} por lado`,
      `${mm(input.configuredPallet.length)} × ${mm(input.configuredPallet.width)} · base ${mm(input.configuredPallet.baseHeight ?? 0)}`,
    ]],
    styles: { font: 'helvetica', fontSize: 7.5, cellPadding: 2.2 },
    headStyles: { fillColor: [51, 65, 85], textColor: 255, fontStyle: 'bold' },
    columnStyles: { 0: { cellWidth: 37 }, 1: { cellWidth: 29 }, 2: { cellWidth: 59 }, 3: { cellWidth: 57 } },
  })
  doc.setTextColor(71, 85, 105)
  doc.setFontSize(7.5)
  const physicalReference = input.destination.maxLength && input.destination.maxWidth
    ? `Caja útil: ${mm(input.destination.maxLength)} × ${mm(input.destination.maxWidth)} × ${mm(input.destination.maxTotalHeight)}${input.destination.maxWeight ? ` · máximo ${kg(input.destination.maxWeight)}` : ''}.`
    : ''
  const destinationDetailY = nextTableY(doc)
  const destinationDetailLines = doc.splitTextToSize([input.destination.note, physicalReference].filter(Boolean).join('\n'), pageWidth - margin * 2)
  doc.text(destinationDetailLines, margin, destinationDetailY)
  cursorY = destinationDetailY + destinationDetailLines.length * 3.2 + 4

  cursorY = sectionTitle(doc, 'Fabricación por paleta', cursorY)
  autoTable(doc, {
    startY: cursorY,
    theme: 'grid',
    head: [['Paleta', 'Cajas', 'Peso', 'Base configurada', 'Base fabricada', 'Ahorro', 'Uso']],
    body: input.mixedResult.pallets.map((plan) => [
      `P${plan.palletIndex + 1}`,
      plan.totalBoxes.toLocaleString('es-ES'),
      kg(plan.totalWeight),
      `${mm(plan.fabricatedPallet.originalLength)} × ${mm(plan.fabricatedPallet.originalWidth)}`,
      `${mm(plan.fabricatedPallet.length)} × ${mm(plan.fabricatedPallet.width)}`,
      plan.fabricatedPallet.isReduced ? percentage(plan.fabricatedPallet.materialSavingsPercentage) : 'Base completa',
      percentage(plan.utilizationPercentage),
    ]),
    styles: { font: 'helvetica', fontSize: 7.1, cellPadding: 1.8 },
    headStyles: { fillColor: [30, 41, 59], textColor: 255, fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [248, 250, 252] },
  })

  cursorY = sectionTitle(doc, 'Distribución por tipo de caja', nextTableY(doc))
  autoTable(doc, {
    startY: cursorY,
    theme: 'grid',
    head: [['SKU / etiqueta', 'Cantidad ubicada', 'Peso', 'Participación']],
    body: input.mixedResult.boxDistribution.map((item) => [
      item.boxName,
      item.quantity.toLocaleString('es-ES'),
      kg(item.weight),
      percentage(item.percentage),
    ]),
    styles: { font: 'helvetica', fontSize: 7.5, cellPadding: 2 },
    headStyles: { fillColor: [51, 65, 85], textColor: 255, fontStyle: 'bold' },
    columnStyles: { 0: { cellWidth: 82 } },
    alternateRowStyles: { fillColor: [248, 250, 252] },
  })

  cursorY = sectionTitle(doc, 'Especificación y manejo de SKU', nextTableY(doc))
  autoTable(doc, {
    startY: cursorY,
    theme: 'grid',
    head: [['SKU / etiqueta', 'Medidas L × A × H', 'Peso', 'Cantidad', 'Manejo']],
    body: input.mixedBoxes.map((item) => [
      item.name,
      `${mm(item.boxDimensions.length)} × ${mm(item.boxDimensions.width)} × ${mm(item.boxDimensions.height)}`,
      kg(item.boxDimensions.weight),
      item.quantity.toLocaleString('es-ES'),
      [item.canStack ? 'Apilable' : 'No apilable', item.allowHorizontalRotation ? 'giro H' : '', item.allowVerticalRotation ? 'giro V' : ''].filter(Boolean).join(' · '),
    ]),
    styles: { font: 'helvetica', fontSize: 7.1, cellPadding: 1.8 },
    headStyles: { fillColor: [51, 65, 85], textColor: 255, fontStyle: 'bold' },
    columnStyles: { 0: { cellWidth: 45 }, 1: { cellWidth: 52 }, 4: { cellWidth: 45 } },
    alternateRowStyles: { fillColor: [248, 250, 252] },
  })

  if (input.containerResult) {
    cursorY = sectionTitle(doc, 'Plan de contenedor generado', nextTableY(doc))
    autoTable(doc, {
      startY: cursorY,
      theme: 'grid',
      head: [['Equipo', 'Unidades', 'Paletas ubicadas', 'Peso total', 'Piso usado']],
      body: [[
        input.containerResult.container.name,
        input.containerResult.containersNeeded.toLocaleString('es-ES'),
        `${input.containerResult.placedPallets}/${input.containerResult.totalPallets}`,
        kg(input.containerResult.totalWeight),
        percentage(input.containerResult.plans[0]?.floorUtilizationPercentage ?? 0),
      ]],
      styles: { font: 'helvetica', fontSize: 7.5, cellPadding: 2 },
      headStyles: { fillColor: [30, 41, 59], textColor: 255, fontStyle: 'bold' },
    })

    cursorY = sectionTitle(doc, 'Detalle de carga por contenedor', nextTableY(doc))
    autoTable(doc, {
      startY: cursorY,
      theme: 'grid',
      head: [['Contenedor', 'Paletas', 'Peso', 'Piso', 'Volumen', 'Altura', 'CG L / T / V']],
      body: input.containerResult.plans.map((plan) => [
        `C${plan.containerIndex + 1}`,
        plan.pallets.length.toLocaleString('es-ES'),
        kg(plan.totalWeight),
        percentage(plan.floorUtilizationPercentage),
        percentage(plan.volumeUtilizationPercentage),
        mm(plan.loadMetrics.maxOccupiedHeight),
        `${mm(plan.loadMetrics.centerOfGravity.longitudinal)} / ${mm(plan.loadMetrics.centerOfGravity.transversal)} / ${mm(plan.loadMetrics.centerOfGravity.vertical)}`,
      ]),
      styles: { font: 'helvetica', fontSize: 7, cellPadding: 1.8 },
      headStyles: { fillColor: [51, 65, 85], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [248, 250, 252] },
    })
  }

  if ((input.manualAdjustments?.length ?? 0) > 0) {
    cursorY = sectionTitle(doc, 'Ajustes manuales de carga', nextTableY(doc), 34)
    autoTable(doc, {
      startY: cursorY,
      theme: 'grid',
      head: [['Unidad', 'Elemento', 'Original X / Z', 'Ajustado X / Z', 'Huella original a ajustada']],
      body: input.manualAdjustments!.map((adjustment) => [
        `C${adjustment.containerIndex + 1} · ${adjustment.kind}`,
        adjustment.label,
        `${mm(adjustment.original.x)} / ${mm(adjustment.original.z)}`,
        `${mm(adjustment.adjusted.x)} / ${mm(adjustment.adjusted.z)}`,
        `${mm(adjustment.original.length)} × ${mm(adjustment.original.width)} a ${mm(adjustment.adjusted.length)} × ${mm(adjustment.adjusted.width)}`,
      ]),
      styles: { font: 'helvetica', fontSize: 7, cellPadding: 1.7 },
      headStyles: { fillColor: [91, 33, 182], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [250, 245, 255] },
    })
  }

  const warnings = [...input.mixedResult.warnings, ...(input.containerResult?.warnings ?? [])]
  if (warnings.length > 0) {
    cursorY = sectionTitle(doc, 'Advertencias operativas', nextTableY(doc), 30)
    autoTable(doc, {
      startY: cursorY,
      theme: 'grid',
      head: [['Observación']],
      body: warnings.map((warning) => [warning]),
      styles: { font: 'helvetica', fontSize: 7.5, cellPadding: 2.2, textColor: [120, 53, 15] },
      headStyles: { fillColor: [146, 64, 14], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [255, 251, 235] },
    })
  }

  printFooter(doc)
  const safeDate = createdAt.toISOString().slice(0, 10)
  doc.save(`plan-logistico-palletoptimizer-${safeDate}.pdf`)
}
