# QA — etiquetas bajo selección y restricciones por SKU

Fecha: 2026-08-13

La pestaña `Mezcla de Cajas` muestra en cada SKU los controles activables `Se puede apilar`, `Rotación horizontal` y `Rotación vertical`. El cálculo utiliza esos valores para generar orientaciones permitidas y para impedir que una caja marcada como no apilable se coloque sobre otro nivel.

La vista 3D ya no dibuja etiquetas sobre todas las cajas. En el estado inicial de la escena solo se observan cajas semitransparentes diferenciadas por color. Al hacer clic sobre una caja, esta se resalta con un contorno amarillo discontinuo y aparece únicamente su etiqueta truncada. El giro horizontal sigue funcionando porque los movimientos con desplazamiento se distinguen de los clics.

Se verificó que al desactivar `Se puede apilar` y `Rotación horizontal` para el primer SKU, el resultado cambió de 2 a 5 paletas con la misma carga de 40 cajas, confirmando que las restricciones afectan el cálculo. También se verificó que la vista 3D conserva la paleta seleccionada y la interacción de selección.

Validaciones técnicas: `CI=true pnpm check` y `CI=true pnpm build` finalizaron correctamente. El artefacto se generó en `dist/index.html` y `dist/assets/*`.
