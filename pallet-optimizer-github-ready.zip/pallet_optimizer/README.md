# Pallet Optimizer

Aplicación web para planificar la distribución de cajas sobre pallets y contenedores. Incluye cálculo de paletizado, soporte para mezcla de SKU, recomendaciones de altura, comparación de alternativas, visualización 3D y exportación de reportes.

## Requisitos

Se requiere Node.js 22 o una versión compatible y pnpm 10. La aplicación es un frontend estático: los cálculos se ejecutan en el navegador y no necesita una base de datos ni un servidor propio para funcionar.

## Desarrollo local

```bash
pnpm install
pnpm run dev
```

Para comprobar los tipos y generar la versión de producción:

```bash
pnpm run check
pnpm run build
```

El resultado de producción se genera en `dist/`.

## Publicación en GitHub Pages

El repositorio incluye el workflow `.github/workflows/deploy-pages.yml`. Después de crear el repositorio `pallet-optimizer` y subir la rama `main`, se debe abrir **Settings → Pages** y seleccionar **GitHub Actions** como fuente de despliegue. Cada cambio enviado a `main` volverá a compilar y publicar la aplicación automáticamente.

La aplicación utiliza rutas de recursos relativas para funcionar bajo la URL de proyecto de GitHub Pages:

```text
https://TU_USUARIO.github.io/pallet-optimizer/
```

## Aplicación de escritorio

El proyecto conserva la configuración de Electron para crear una versión portable de Windows mediante `pnpm run desktop:dist`. GitHub Pages publica únicamente la versión web; los instaladores de escritorio deben distribuirse mediante GitHub Releases u otro canal de descargas.

## Seguridad

No se deben subir claves API, contraseñas, archivos `.env` ni configuraciones internas de la plataforma de desarrollo. Los archivos internos del entorno Manus quedan excluidos mediante `.gitignore`.

## Licencia

MIT.
