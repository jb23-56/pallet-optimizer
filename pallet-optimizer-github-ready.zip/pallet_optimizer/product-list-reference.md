# Referencia de listas de productos

## Fuente visual

La referencia muestra un flujo de alta de cajas por lote con tres accesos principales: carga de Excel/CSV, asistencia para completar datos y catálogo de SKU guardados. La vista permite alternar entre tarjetas y hoja de cálculo. Cada grupo presenta el total de tipos y cajas, y cada fila puede expandirse para editar etiqueta, ancho, largo, alto, peso, cantidad y restricciones de manejo.

La interacción que se adopta en Pallet Optimizer es la carga Excel/CSV, la plantilla descargable, el alta manual, la vista de tarjetas, la vista tabular, la agrupación por `groupId`, el despliegue por fila y los controles de apilamiento y rotación X/Y/Z. No se incorpora una función de IA ni un catálogo remoto porque no forman parte del alcance confirmado.

## Archivo Excel validado

El archivo `import_example_metric(1)111.xlsx` contiene las hojas `Carriers`, `Boxes` y `Settings`. La hoja `Boxes` usa las columnas `width (mm)`, `length (mm)`, `height (mm)`, `weight (g)`, `amount`, `groupId`, `allowStackingOnTop`, `allowedRotations` y `label`.

La importación real en el navegador cargó tres productos y 25 cajas desde la hoja `Boxes`: `Fragile electronics` (8), `Office supplies` (5) y una fila sin etiqueta que se normalizó como `Producto 4` (12). Los grupos quedaron separados como Grupo 0 y Grupo 1. El peso en gramos se convirtió a kilogramos para coincidir con el modelo interno de Pallet Optimizer.

## Estado

La pestaña Lista de Productos está integrada y la importación XLSX fue validada con el archivo de ejemplo. Falta validar el traspaso de esa lista a Mezcla de Cajas, el CSV y el build final antes del checkpoint.

## Decisiones técnicas

El modelo `ProductListItem` extiende `MixedBoxItem` con `groupId`, `groupName` y `expanded`. `productList.ts` normaliza encabezados, valida dimensiones/peso/cantidad, convierte unidades y conserva advertencias por fila. `ProductListPanel.tsx` ofrece edición por tarjetas o tabla, agrupación, alta manual, eliminación y transferencia a la mezcla.

## Autor

Manus AI


## Validación funcional adicional

El archivo Excel de ejemplo se importó correctamente desde el selector visible del navegador. La aplicación mostró tres tipos y 25 cajas, conservó los grupos y convirtió los pesos a kilogramos. Al pulsar `Usar lista en Mezcla`, se cargaron `Fragile electronics`, `Office supplies` y `Producto 4` como tres SKU editables. El cálculo produjo una paleta con 25 cajas ubicadas, 104 kg de peso total y 45.0% de utilización, con su vista 3D disponible.

El flujo de importación XLSX y transferencia a mezcla quedó validado. La prueba CSV y la validación del build final permanecen pendientes.


La ruta CSV también fue validada con un archivo de prueba: se importó 1 tipo y 3 cajas, con dimensiones 500 × 400 × 250 mm, peso convertido de 6000 g a 6 kg, grupo CSV y rotaciones X/Y habilitadas.
