# Dirección visual — Pallet Optimizer

## Enfoque elegido

**Technical Logistics SaaS / Modernismo Industrial Funcional.** La interfaz debe comunicar precisión de almacén y planeación de carga, con una composición densa pero legible, geometría de pallet, retículas técnicas y señales de medición. La paleta evita adornos decorativos y usa azul operativo sobre neutros industriales fríos.

## Principios

- La información de capacidad, disposición, carga y eficiencia tiene prioridad visual.
- Los paneles de entrada y resultados forman un puesto de trabajo asimétrico, no una landing page centrada.
- Las etiquetas, SKU, colores y métricas deben ayudar a identificar decisiones logísticas rápidamente.
- Los movimientos deben ser directos y previsibles; la escena 3D solo permite giro horizontal.

## Sistema visual

El azul operacional es el color propio del producto para acciones primarias, navegación activa y señales de optimización. Los neutros pizarra y blanco frío forman la base técnica; verde, ámbar y rojo quedan reservados para capacidad, advertencias y estados de carga. La tipografía debe mantener encabezados compactos y métricas con alto contraste.

## Motivos de marca

El cubo/pallet funciona como símbolo principal. Las retículas, líneas de medición y chips de SKU deben reaparecer en resultados y visualización 3D. La interfaz debe sentirse como una estación de planificación de almacén: compacta, precisa y accionable.

## Voz

El copy es conciso, experto y operativo en español: “Capacidad disponible”, “Distribución por tipo de caja”, “Cajas ubicadas” y “Altura total”. Se evita el relleno genérico y se priorizan verbos de operación como calcular, ubicar, comparar y distribuir.

## Hallazgos de revisión visual — 2026-08-13

La revisión confirmó que la estructura de dos columnas, la claridad del español y el símbolo de cubo funcionan. También señaló que la interfaz todavía podía reforzar la identidad logística, la jerarquía de formularios, la presencia de marca, la retícula técnica del resultado y el uso estratégico del azul. Estos puntos se incorporan en el siguiente pase de refinamiento sin alterar la lógica de cálculo ni la interacción horizontal de la vista 3D.

## Style Decisions

### Referencia de reorganización — 2026-08-19

La referencia aportada por el usuario se adopta como especificación de claridad, no como una copia literal. El flujo debe sentirse **blanco, amplio y guiado por pasos**: cabecera ligera, navegación horizontal de etapas, explicación breve del paso activo, tarjetas de entrada discretas y una tabla/filas limpias para SKU. La densidad técnica se conserva únicamente dentro de medidas, restricciones y resultados, no en cada borde o rótulo.

- La mezcla de SKU prioriza una lista editable de filas antes que paneles técnicos apilados.
- El destino y la fabricación de paleta pasan a ser configuración secundaria y resumida; no deben desplazar la tarea principal de ingresar cajas.
- Las acciones principales usan azul cielo, mientras que controles secundarios, detalles y separadores se resuelven en blanco y gris suave.
- Las tarjetas de entrada deben explicar una decisión y tener espacio respirable; nunca repetir una jerarquía de títulos, líneas y etiquetas sin una función operativa clara.
- La precisión tabular se reserva para las mediciones y SKU. Los títulos, explicaciones y el paso activo usan una lectura humana más tranquila para que el flujo no parezca un único panel de instrumentos.
- La etapa activa es la columna vertebral: explicación breve, entrada requerida y acción de cálculo se leen antes que el destino o las opciones auxiliares.

- Adoptar explícitamente el estilo “technical logistics SaaS”: preciso, basado en retícula, denso en datos y orientado a geometría de pallet.
- Usar azul operacional como color de marca y reservar acentos para resultados y advertencias.
- Reforzar el encabezado, los pasos de entrada, los grupos de medición y el estado vacío con señales técnicas y jerarquía más intencional.
- Mantener una guía explícita de flujo: el usuario debe entender qué hace ahora y cuál es la siguiente acción antes de leer el detalle técnico.
- Usar rótulos monoespaciados/tabulares en medidas, pasos y métricas para reforzar la precisión de estación logística.
- Extender una retícula de medición sutil al lienzo principal y compactar radios de módulos para evitar una apariencia de formulario SaaS genérico.
- Reservar el azul para navegación activa, cálculo y optimización; tratar la información secundaria con neutros fríos y líneas técnicas.

### Refinamiento técnico — 2026-08-14

- Los módulos de destino, producto, base y optimización se leen como **etapas numeradas de operación**, con rótulos azules tabulares y superficies frías discretas.
- El azul ya no funciona como borde decorativo: identifica selección, cálculo, optimización y acción primaria; las divisiones pasivas se mantienen en pizarra fría.
- El estado vacío de resultados conserva una retícula, ejes y una huella de pallet con referencias de medida, de modo que sigue leyendo como un plano operativo antes del primer cálculo.
- Los valores, unidades, SKU, botones de aplicación y micro-métricas usan IBM Plex Mono con números tabulares para una lectura de instrumento de almacén.
- Los rótulos pasivos y las divisiones emplean pizarra fría; el azul señala exclusivamente cálculo, selección, optimización y mediciones decisivas.
- Las entradas se agrupan como instrumentos con marcadores laterales, campos compactos y foco de lectura, mientras el plano vacío incorpora cruces y ejes de medición coherentes con la huella del pallet.
- Los iconos decorativos se sustituyen por cubo, regla, capa y carga; el plano mantiene una referencia de escala y límite maniobrable incluso sin cálculo.
- El azul se reserva para navegación activa, cálculo, aplicación y selección; las etapas, rótulos y divisiones pasivas se expresan en pizarra fría.
- La consola se lee en cuatro zonas: contexto de envío, medición de carga, optimización y plano. La retícula del plano combina graduación fina y mayor para parecer una superficie operativa, no decorativa.
- La jerarquía fija es: decisión activa, métrica crítica, acción disponible y detalle secundario. El plano conserva una huella dominante, ejes y límite de maniobra aun sin cálculo; la voz utiliza verbos de operación breves como Definir, Aplicar, Calcular y Ubicar.
- Los campos se comportan como instrumentos de almacén: superficie fría, unidad tabular y rotulado técnico. El azul se reserva para estado activo, cálculo, aplicación y medidas decisivas; las divisiones pasivas se resuelven en pizarra fría.
- La jerarquía refuerza cinco decisiones: paso actual, entrada requerida, base recomendada, acción de cálculo y estado del plan; la instrumentación pasiva no compite con ellas.
- Las recomendaciones trasladan la retícula de pallet a su propia superficie: la primera alternativa recibe una guía azul y presencia de salida operativa; las alternativas secundarias se mantienen en pizarra fría.
- Las mediciones de entrada se agrupan como módulos de instrumento con marcador lateral, etiqueta tabular y valor de alto contraste; la tipografía de lectura usa familias del sistema para que la versión local se mantenga funcional sin conexión.

### Jerarquía de flujo — 2026-08-19

- Las mayúsculas monoespaciadas se reservan para medidas, unidades, SKU, estados técnicos y ejes; los títulos de paso y sus explicaciones mantienen una lectura humana, compacta y directa.
- La navegación de etapas es el eje visual del producto: la etapa activa se diferencia con azul operacional, número, icono y estado; las etapas futuras permanecen neutras y silenciosas.
- El lockup une cubo/pallet, wordmark técnico y descriptor operativo; la señal azul se concentra en la ruta de decisión y no compite con los detalles auxiliares.
- La acción de cálculo se presenta como la consecuencia visible del paso actual. Los paneles de entrada conservan precisión tabular en valores, pero sus explicaciones y divisiones secundarias respiran más.

## Autor

Manus AI
