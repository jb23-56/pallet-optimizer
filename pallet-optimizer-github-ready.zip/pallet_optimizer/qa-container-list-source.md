# QA — Lista de productos como fuente de Contenedores

Fecha: 2026-08-13

## Resultado

La pestaña Contenedores muestra una tercera opción en `Fuente de paletas`: `Lista de productos actual · 2 paletas`, junto a `Mezcla de cajas` y `Cálculo simple`.

Al seleccionar la lista, el módulo actualiza automáticamente las métricas: 2 paletas disponibles, 460 kg de peso estimado, 1 contenedor generado, 2/2 paletas ubicadas, 460 kg y 6.8% de uso de piso.

La visualización 3D del contenedor se activa con las dos paletas de la lista y mantiene la selección contextual de paletas.

## Validación técnica

`CI=true pnpm check` y `CI=true pnpm build` finalizaron correctamente. Vite mostró únicamente el aviso de bundle JavaScript superior a 500 kB.
