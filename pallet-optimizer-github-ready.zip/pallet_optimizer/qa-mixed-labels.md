# QA — multi-SKU, etiquetas y visualización 3D

Fecha: 2026-08-13

La pestaña `Mezcla de Cajas` mostró inicialmente dos SKU, cada uno con nombre editable, dimensiones completas, peso y cantidad. El botón `Añadir tipo` agregó correctamente un tercer SKU (`SKU-C · Nueva caja`) sin limitar la mezcla a un solo tipo.

Al ejecutar el cálculo con dos SKU, la interfaz mostró la tabla de distribución, el modo `Distribución parcial por capas y filas`, advertencias de volumen/cajas no ubicadas y una vista 3D con etiquetas visibles `SKU-A · Caja grande` y `SKU-B · Caja pequeña`. Al recalcular con tres SKU, la tabla incorporó `SKU-C · Nueva caja` y la escena 3D mostró sus etiquetas y color diferenciado.

La pestaña de cálculo simple también fue verificada: el resultado mostró la etiqueta `Caja A` en la tarjeta de resultados y en las cajas de la vista 3D. El canvas mantiene el control `Solo horizontal` y el botón `Restablecer vista`.

La validación técnica final ejecutó `CI=true pnpm check` y `CI=true pnpm build` sin errores. El build generó el artefacto en `dist/index.html` y `dist/assets/*`.
