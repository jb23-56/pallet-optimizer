# QA — distribución automática en varias paletas

Fecha: 2026-08-13

Se probó la pestaña `Mezcla de Cajas` con dos SKU y 60 unidades de cada uno, usando una paleta de 1200 × 800 × 1500 mm y 1000 kg. El cálculo produjo 120 cajas ubicadas en 5 paletas, con tarjetas independientes para cada paleta y métricas de cajas, peso y utilización.

La interfaz mostró las advertencias operativas: `La carga supera la capacidad de una sola paleta; se generaron 5 paletas para distribuir el excedente` y `El volumen total de las cajas supera el volumen de la paleta`. Las tarjetas también mostraron mensajes como `98 caja(s) no pudieron ubicarse en esta paleta`, indicando que el excedente se continuaba en la siguiente paleta.

Al seleccionar `Paleta 2`, el encabezado cambió a `Paleta 2 de 5`, el resumen mostró 22 cajas y 288 kg, y la vista 3D se actualizó para mostrar la carga de esa paleta. La tabla global confirmó las 60 unidades de SKU-A y 60 de SKU-B.

Validaciones técnicas: `CI=true pnpm check` y `CI=true pnpm build` finalizaron sin errores. La salida se generó en `dist/index.html` y `dist/assets/*`.
