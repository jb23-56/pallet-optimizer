import { calculateMixedBoxArrangement, findUnsupportedMixedPlacements, recommendOptimizedPalletDimensions } from '../client/src/lib/palletCalculator.ts'

function assert(condition, message) {
  if (!condition) throw new Error(message)
}

const pallet = { length: 2400, width: 2400, height: 2400, baseHeight: 150, maxWeight: 10000 }
const mixedBoxes = [
  { id: 'base', name: 'Base amplia', boxDimensions: { length: 800, width: 600, height: 400, weight: 18 }, quantity: 18, canStack: true, allowHorizontalRotation: true, allowVerticalRotation: false },
  { id: 'narrow', name: 'Base angosta', boxDimensions: { length: 500, width: 400, height: 500, weight: 12 }, quantity: 12, canStack: false, allowHorizontalRotation: true, allowVerticalRotation: false },
  { id: 'top', name: 'Caja superior', boxDimensions: { length: 800, width: 600, height: 300, weight: 10 }, quantity: 14, canStack: true, allowHorizontalRotation: true, allowVerticalRotation: false },
]

const result = calculateMixedBoxArrangement(mixedBoxes, pallet)
assert(result, 'El caso de prueba debe generar un resultado de mezcla')
assert(result.pallets.length > 0, 'El caso de prueba debe generar al menos una paleta')

for (const plan of result.pallets) {
  const unsupported = findUnsupportedMixedPlacements(plan.boxPlacements, pallet)
  assert(unsupported.length === 0, `La paleta ${plan.palletIndex + 1} contiene cajas sin apoyo: ${unsupported.join(', ')}`)
  const unsupportedOnFabricatedBase = findUnsupportedMixedPlacements(plan.boxPlacements, plan.fabricatedPallet)
  assert(unsupportedOnFabricatedBase.length === 0, `La paleta ${plan.palletIndex + 1} pierde apoyo al fabricar la base: ${unsupportedOnFabricatedBase.join(', ')}`)
  assert(plan.boxPlacements.every((placement) => placement.y >= pallet.baseHeight), `La paleta ${plan.palletIndex + 1} tiene una caja por debajo de la base`) 
  assert(plan.boxPlacements.every((placement) => placement.x + placement.width <= plan.fabricatedPallet.length && placement.z + placement.depth <= plan.fabricatedPallet.width), `La paleta ${plan.palletIndex + 1} no cabe en su base fabricada`)
}

const lowUtilizationResult = calculateMixedBoxArrangement([
  { id: 'single', name: 'Carga reducida', boxDimensions: { length: 600, width: 400, height: 300, weight: 10 }, quantity: 1, canStack: true, allowHorizontalRotation: true, allowVerticalRotation: false },
], { length: 1200, width: 800, height: 1500, baseHeight: 150, maxWeight: 1000 })
assert(lowUtilizationResult?.pallets[0].fabricatedPallet.isReduced, 'Una carga reducida debe disminuir la base fabricada')
assert((lowUtilizationResult?.pallets[0].fabricatedPallet.materialSavingsPercentage ?? 0) > 0, 'La base reducida debe informar ahorro de material')

const fullBaseResult = calculateMixedBoxArrangement([
  { id: 'full', name: 'Carga completa', boxDimensions: { length: 600, width: 400, height: 300, weight: 10 }, quantity: 4, canStack: false, allowHorizontalRotation: false, allowVerticalRotation: false },
], { length: 1200, width: 800, height: 1500, baseHeight: 150, maxWeight: 1000 })
assert(!fullBaseResult?.pallets[0].fabricatedPallet.isReduced, 'Una carga que ocupa toda la base debe conservarla completa')

const maneuverabilityConstraints = { maxTotalHeight: 2393, baseHeight: 150, maxWeight: 10000, maxLength: 2400, maxWidth: 2352, preferredMaxSide: 1700 }
const maneuverableRecommendations = recommendOptimizedPalletDimensions(
  { length: 600, width: 400, height: 300, weight: 15 },
  { canStack: true, allowHorizontalRotation: true, allowVerticalRotation: false },
  { ...maneuverabilityConstraints, allowOversize: false },
)
assert(maneuverableRecommendations.length > 0, 'Debe existir una recomendación maniobrable')
assert(maneuverableRecommendations.every((recommendation) => recommendation.length <= 1700 && recommendation.width <= 1700), 'Las recomendaciones maniobrables no deben exceder 1,700 mm por lado')

const expandedRecommendations = recommendOptimizedPalletDimensions(
  { length: 600, width: 400, height: 300, weight: 15 },
  { canStack: true, allowHorizontalRotation: true, allowVerticalRotation: false },
  { ...maneuverabilityConstraints, allowOversize: true },
)
assert(expandedRecommendations.some((recommendation) => !recommendation.isWithinManeuverabilityLimit), 'La excepción debe mostrar al menos una base ampliada')

console.log(`Validación superada: ${result.pallets.length} paleta(s), ${result.totalBoxes - result.unplacedBoxes}/${result.totalBoxes} cajas apoyadas; límite maniobrable y excepción ampliada disponibles.`)
