import fs from 'node:fs'
import path from 'node:path'
import XLSX from 'xlsx'

const downloadDirectory = '/home/ubuntu/Downloads'
const candidates = fs.readdirSync(downloadDirectory)
  .filter((file) => /^plan-logistico-palletoptimizer-.*\.xlsx$/i.test(file))
  .map((file) => ({ file, modified: fs.statSync(path.join(downloadDirectory, file)).mtimeMs }))
  .sort((left, right) => right.modified - left.modified)

if (candidates.length === 0) throw new Error('No se encontró un informe Excel descargado.')
const filePath = path.join(downloadDirectory, candidates[0].file)
const workbook = XLSX.readFile(filePath)
const expectedSheets = ['Resumen', 'Paletas', 'Cajas', 'SKU', 'Envío', 'Alertas']
if (workbook.SheetNames.join('|') !== expectedSheets.join('|')) throw new Error(`Hojas inesperadas: ${workbook.SheetNames.join(', ')}`)

const shipping = workbook.Sheets.Envío
const placements = workbook.Sheets.Cajas
if (shipping.B6?.v !== 'C1' || shipping.D6?.v !== 2 || shipping.E6?.v !== 460) throw new Error('La hoja Envío no contiene el plan de contenedor esperado.')
if (!placements.B6?.v || XLSX.utils.decode_range(placements['!ref']).e.r < 44) throw new Error('La hoja Cajas no contiene la distribución física completa.')

console.log(`Excel descargado validado: ${candidates[0].file} · ${workbook.SheetNames.length} hojas · ${XLSX.utils.decode_range(placements['!ref']).e.r - 4} cajas exportadas.`)
