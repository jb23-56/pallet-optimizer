import { buildLogisticsWorkbook } from '../client/src/lib/logisticsExcel.ts'
import { calculateMixedBoxArrangement } from '../client/src/lib/palletCalculator.ts'
import { calculateContainerLoad } from '../client/src/lib/containerCalculator.ts'

const mixedBoxes = [
  { id: 'a', name: 'SKU-A', boxDimensions: { length: 600, width: 400, height: 300, weight: 15 }, quantity: 20, canStack: true, allowHorizontalRotation: true, allowVerticalRotation: false },
  { id: 'b', name: 'SKU-B', boxDimensions: { length: 400, width: 300, height: 250, weight: 8 }, quantity: 20, canStack: true, allowHorizontalRotation: true, allowVerticalRotation: false },
]
const pallet = { length: 1200, width: 800, height: 1500, baseHeight: 150, maxWeight: 1000 }
const mixedResult = calculateMixedBoxArrangement(mixedBoxes, pallet)
const container = { id: '40-dry', name: 'Contenedor marítimo 40 ft', length: 12032, width: 2352, height: 2393, maxWeight: 28000, note: 'Referencia de prueba.' }
const containerResult = calculateContainerLoad(mixedResult.pallets.map((plan, index) => ({ id: `p-${index}`, label: `Paleta ${index + 1}`, length: plan.fabricatedPallet.length, width: plan.fabricatedPallet.width, height: plan.fabricatedPallet.height, weight: plan.totalWeight, color: '#2563eb', sourceIndex: index })), container)
const workbook = buildLogisticsWorkbook({
  destination: { label: 'Contenedor estándar', maxTotalHeight: 2393, note: 'Referencia de prueba.' },
  maneuverability: { preferredMaxSide: 1700, allowOversize: false },
  configuredPallet: pallet,
  mixedBoxes,
  mixedResult,
  containerResult,
  generatedAt: new Date('2026-08-14T19:00:00.000Z'),
})
const expectedSheets = ['Resumen', 'Paletas', 'Cajas', 'SKU', 'Envío', 'Alertas']
if (workbook.SheetNames.join('|') !== expectedSheets.join('|')) throw new Error(`Hojas inesperadas: ${workbook.SheetNames.join(', ')}`)
if (!workbook.Sheets.Cajas['B6'] || !workbook.Sheets.Envío['B6'] || !workbook.Sheets.Paletas['B6']) throw new Error('Faltan filas en las hojas operativas.')
if (!workbook.Sheets.Resumen['C10'] || workbook.Sheets.Resumen['C10'].z !== '0.0%') throw new Error('El formato de utilización no se aplicó al resumen.')
console.log(`Validación Excel superada: ${workbook.SheetNames.length} hojas, ${mixedResult.pallets.length} paletas y ${mixedResult.boxPlacements.length} cajas exportadas.`)
